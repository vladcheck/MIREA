#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "../include/stb_image_write.h"
#include "../include/maze_exporter.h"
#include <vector>
#include <algorithm>
std::string PngExporter::exportMaze(const MazeContext& ctx, const std::vector<Point>& path) {
    int width = ctx.getWidth();
    int height = ctx.getHeight();
    const auto& cells = ctx.getCells();
    int cell_size = 10;
    int wall_thickness = 2; 
    int img_w = width * cell_size + 1;
    int img_h = height * cell_size + 1;
    std::vector<uint8_t> pixels(img_w * img_h * 3, 255); 
    auto draw_pixel = [&](int px, int py, uint8_t r, uint8_t g, uint8_t b) {
        if (px >= 0 && px < img_w && py >= 0 && py < img_h) {
            int idx = (py * img_w + px) * 3;
            pixels[idx] = r;
            pixels[idx+1] = g;
            pixels[idx+2] = b;
        }
    };
    auto draw_line = [&](int x1, int y1, int x2, int y2) {
        int start_x = std::min(x1, x2);
        int end_x = std::max(x1, x2);
        int start_y = std::min(y1, y2);
        int end_y = std::max(y1, y2);
        for (int i = start_x; i <= end_x; ++i) {
            for (int j = start_y; j <= end_y; ++j) {
                draw_pixel(i, j, 0, 0, 0); 
            }
        }
    };
    for (const auto& cell : cells) {
        int x_px = cell.x * cell_size;
        int y_px = cell.y * cell_size;
        if (cell.wall_north) {
            draw_line(x_px, y_px, x_px + cell_size, y_px);
        }
        if (cell.wall_south) {
            draw_line(x_px, y_px + cell_size, x_px + cell_size, y_px + cell_size);
        }
        if (cell.wall_west) {
            draw_line(x_px, y_px, x_px, y_px + cell_size);
        }
        if (cell.wall_east) {
            draw_line(x_px + cell_size, y_px, x_px + cell_size, y_px + cell_size);
        }
    }
    for (const auto& p : path) {
        int px = p.x * cell_size + cell_size / 2;
        int py = p.y * cell_size + cell_size / 2;
        for (int dx = -1; dx <= 2; ++dx) {
            for (int dy = -1; dy <= 2; ++dy) {
                draw_pixel(px + dx, py + dy, 255, 0, 0); 
            }
        }
    }
    std::string filename = "maze.png";
    stbi_write_png(filename.c_str(), img_w, img_h, 3, pixels.data(), img_w * 3);
    return "Saved PNG to " + filename;
}