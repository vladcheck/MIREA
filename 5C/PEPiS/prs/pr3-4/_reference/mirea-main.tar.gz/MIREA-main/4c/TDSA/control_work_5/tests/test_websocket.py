import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.room_manager import room_manager

@pytest.fixture
def client():
    return TestClient(app)

def test_connect_with_correct_username(client):
    with client.websocket_connect("/ws/rooms/python?username=alice") as websocket:
        response = client.get("/rooms/python/users")
        assert response.status_code == 200
        assert "alice" in response.json()["users"]

def test_empty_username_closes_connection(client):
    with pytest.raises(Exception):
        with client.websocket_connect("/ws/rooms/python?username=   "):
            pass

def test_send_and_receive_message(client):
    with client.websocket_connect("/ws/rooms/python?username=alice") as websocket:
        websocket.send_json({"type": "message", "text": "Всем привет"})
        data = websocket.receive_json()
        assert data == {
            "type": "message",
            "room_id": "python",
            "username": "alice",
            "text": "Всем привет"
        }

def test_two_clients_in_one_room(client):
    with client.websocket_connect("/ws/rooms/python?username=alice") as ws1:
        with client.websocket_connect("/ws/rooms/python?username=bob") as ws2:
            ws1.send_json({"type": "message", "text": "Привет Боб!"})
            data1 = ws1.receive_json()
            data2 = ws2.receive_json()
            
            assert data1 == data2
            assert data1["text"] == "Привет Боб!"

def test_clients_in_different_rooms(client):
    with client.websocket_connect("/ws/rooms/python?username=alice") as ws1:
        with client.websocket_connect("/ws/rooms/java?username=bob") as ws2:
            # Отправляем сообщение в комнату python
            ws1.send_json({"type": "message", "text": "Я питонист"})
            
            # Отправляем сообщение в комнату java
            ws2.send_json({"type": "message", "text": "Я джавист"})
            
            # Получаем ответ в комнате python
            data1 = ws1.receive_json()
            assert data1["text"] == "Я питонист"
            
            # Получаем ответ в комнате java. Если бы комнаты пересекались, 
            # первым сообщением пришло бы "Я питонист".
            data2 = ws2.receive_json()
            assert data2["text"] == "Я джавист"
                
def test_long_message(client):
    with client.websocket_connect("/ws/rooms/python?username=alice") as websocket:
        websocket.send_json({"type": "message", "text": "a" * 301})
        data = websocket.receive_json()
        assert data["type"] == "error"
        assert data["detail"] == "Message is too long"

def test_disconnect_removes_user(client):
    try:
        with client.websocket_connect("/ws/room1?username=test1"):
            pass
    except Exception:
        pass
    
    # After block exits, the connection is closed and user is removed
    assert "test1" not in room_manager.get_users("room1")

def test_get_users_empty_room(client):
    assert room_manager.get_users("non_existent_room") == []

def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "env": "local"}