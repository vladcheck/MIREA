# Тестирование моего API
![alt text](DeleteById.png)
![alt text](GetAll.png)
![alt text](GetById.png)
# Внешний API
![alt text](<Снимок экрана 2026-02-27 в 14.55.54.png>)
![alt text](<Снимок экрана 2026-02-27 в 14.54.45.png>)
![alt text](<Снимок экрана 2026-02-27 в 14.54.09.png>)
![alt text](<Снимок экрана 2026-02-27 в 14.53.47.png>)
![alt text](<Снимок экрана 2026-02-27 в 14.53.10.png>)
