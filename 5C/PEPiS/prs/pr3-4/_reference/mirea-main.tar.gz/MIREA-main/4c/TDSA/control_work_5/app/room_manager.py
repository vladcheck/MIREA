from collections import defaultdict
from typing import Dict, List
from fastapi import WebSocket, WebSocketDisconnect

class RoomManager:
    def __init__(self):
        self.rooms: Dict[str, Dict[str, WebSocket]] = defaultdict(dict)

    async def connect(self, room_id: str, username: str, websocket: WebSocket):
        await websocket.accept()
        self.rooms[room_id][username] = websocket
        # Notify others
        # Usually it says "Всем пользователям комнаты нужно отправить событие о подключении"
        # However, the task description primarily cares about broadcast logic
        
    def disconnect(self, room_id: str, username: str):
        if room_id in self.rooms and username in self.rooms[room_id]:
            del self.rooms[room_id][username]
            
    async def broadcast(self, room_id: str, payload: dict):
        if room_id in self.rooms:
            for ws in self.rooms[room_id].values():
                await ws.send_json(payload)
                
    def get_users(self, room_id: str) -> List[str]:
        if room_id in self.rooms:
            return list(self.rooms[room_id].keys())
        return []

room_manager = RoomManager()