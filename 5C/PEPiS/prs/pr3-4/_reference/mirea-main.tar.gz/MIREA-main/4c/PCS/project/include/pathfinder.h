#pragma once
#include <vector>
#include "maze_context.h"
struct Point {
    int x, y;
    bool operator==(const Point& other) const {
        return x == other.x && y == other.y;
    }
};
class Pathfinder {
public:
    std::vector<Point> findPath(const MazeContext& ctx, Point start, Point end);
};
