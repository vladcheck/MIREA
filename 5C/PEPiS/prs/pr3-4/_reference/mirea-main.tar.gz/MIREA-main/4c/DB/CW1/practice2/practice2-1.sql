CREATE OR REPLACE FUNCTION get_converted_price_lyapunov(
    exchange_rate NUMERIC,
    property_code INTEGER
)
    RETURNS NUMERIC
    LANGUAGE SQL
AS
$$
SELECT CASE
           WHEN exchange_rate <= 0 THEN NULL
           ELSE ROUND((price::numeric / exchange_rate), 2)
           END
FROM property
WHERE id = property_code;
$$;