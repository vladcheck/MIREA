module.exports = function (allowedRoles) {
    return function (req, res, next) {
        if (!req.user || !req.user.role) {
            return res.status(403).json({ message: "Роль не определена" });
        }
        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({ message: "У вас нет прав доступа к этому ресурсу" });
        }
        next();
    };
};
