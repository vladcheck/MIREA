CREATE OR REPLACE FUNCTION validate_passport_data_lyapunov()
    RETURNS TRIGGER AS
$$
BEGIN
    IF NEW.passport_data IS NOT NULL AND NEW.passport_data !~ '^\d{4} \d{6}$' THEN
        RAISE EXCEPTION 'ОШИБКА: Паспортные данные "%" некорректны. Требуется формат "ХХХХ УУУУУУ" (серия из 4 цифр, пробел, номер из 6 цифр).', NEW.passport_data;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_validate_passport_data ON realtor;
CREATE TRIGGER trg_validate_passport_data
    BEFORE INSERT OR UPDATE
    ON realtor
    FOR EACH ROW
EXECUTE FUNCTION validate_passport_data_lyapunov();