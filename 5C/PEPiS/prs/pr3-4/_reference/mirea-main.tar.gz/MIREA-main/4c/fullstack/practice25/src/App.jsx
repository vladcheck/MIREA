import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';

// Lazy loading компонента About
const About = lazy(() => import('./pages/About'));

function App() {
  return (
    <Router>
      <div>
        <nav style={{ marginBottom: '20px', padding: '10px', background: '#eee' }}>
          <Link to="/" style={{ marginRight: '10px' }}>Главная</Link>
          <Link to="/about">О нас</Link>
        </nav>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route 
            path="/about" 
            element={
              <Suspense fallback={<div>Загрузка компонента...</div>}>
                <About />
              </Suspense>
            } 
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
