import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Products from './components/Products';
import Users from './components/Users';
import api from './api';
import './App.css';

const App = () => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    const fetchUser = async () => {
        const token = localStorage.getItem('accessToken');
        if (!token) {
            setUser(null);
            setLoading(false);
            return;
        }
        try {
            const { data } = await api.get('/auth/me');
            setUser(data);
        } catch (err) {
            console.error('Ошибка получения пользователя:', err);
            setUser(null);
            localStorage.removeItem('accessToken');
            localStorage.removeItem('refreshToken');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchUser();
    }, []);

    const handleLogout = () => {
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        setUser(null);
    };

    if (loading) return <div style={{ textAlign: 'center', marginTop: '50px' }}>Загрузка...</div>;

    return (
        <Router>
            <div className="app-main">
                <nav className="navbar">
                    <div className="nav-links">
                        {user ? (
                            <>
                                <Link to="/" className="nav-link">Товары</Link>
                                {user.role === 'admin' && (
                                    <Link to="/users" className="nav-link">Пользователи</Link>
                                )}
                                <span className="user-email">({user.email} - {user.role})</span>
                                <button onClick={handleLogout} className="btn-logout">Выйти</button>
                            </>
                        ) : (
                            <>
                                <Link to="/login" className="nav-link">Вход</Link>
                                <Link to="/register" className="nav-link">Регистрация</Link>
                            </>
                        )}
                    </div>
                </nav>

                <div className="content">
                    <Routes>
                        <Route 
                            path="/login" 
                            element={!user ? <Login setAuth={fetchUser} /> : <Navigate to="/" />} 
                        />
                        <Route 
                            path="/register" 
                            element={!user ? <Register /> : <Navigate to="/" />} 
                        />
                        <Route 
                            path="/" 
                            element={user ? <Products user={user} setAuth={fetchUser} /> : <Navigate to="/login" />} 
                        />
                        <Route 
                            path="/users" 
                            element={user?.role === 'admin' ? <Users /> : <Navigate to="/" />} 
                        />
                        <Route path="*" element={<Navigate to="/" />} />
                    </Routes>
                </div>
            </div>
        </Router>
    );
};

export default App;
