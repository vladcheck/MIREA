TRUNCATE TABLE property_structure CASCADE;
TRUNCATE TABLE sale CASCADE;
TRUNCATE TABLE property CASCADE;
TRUNCATE TABLE journal CASCADE;
INSERT INTO district (id, name) VALUES (1, 'Test District') ON CONFLICT (id) DO NOTHING;
INSERT INTO type (id, name) VALUES (1, 'Test Type') ON CONFLICT (id) DO NOTHING;
INSERT INTO building_material (id, name) VALUES (1, 'Brick') ON CONFLICT (id) DO NOTHING;
INSERT INTO realtor (id, last_name, first_name, phone_number) VALUES (1, 'Doe', 'John', '123') ON CONFLICT (id) DO NOTHING;
INSERT INTO property (id, district_id, address, floor, room_count, type_id, status, price, building_material_id, area, listing_date) VALUES 
(1, 1, 'Address 1', 1, 2, 1, true, 10000000, 1, 100, '2023-01-01'),
(2, 1, 'Address 2', 2, 1, 1, true, 5000000, 1, 50, '2023-02-01');\n\n