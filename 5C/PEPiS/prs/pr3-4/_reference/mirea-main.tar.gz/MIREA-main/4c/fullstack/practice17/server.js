const express = require('express');
const https = require('https');
const http = require('http');
const fs = require('fs');
const socketIo = require('socket.io');
const webpush = require('web-push');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const DEV_HTTP = process.env.DEV_HTTP === 'true';
const sslOptions = DEV_HTTP ? null : {
    key: fs.readFileSync(path.join(__dirname, 'localhost+2-key.pem')),
    cert: fs.readFileSync(path.join(__dirname, 'localhost+2.pem'))
};
const vapidKeys = {
    publicKey: 'BDqohPmAlopaR4fyICK7kQ4IyCqxoqKy5uPCSr20eL95QjnxKtJIHNld2iwBZmvNe5QNsLDwfM5XQlFX8AQbzjo',
    privateKey: 'KhYZ5EcsCvO2tx1WX7CU5M15i487oXyPMuk1ntdlS_0'
};
webpush.setVapidDetails(
    'mailto:your-email@example.com', 
    vapidKeys.publicKey,
    vapidKeys.privateKey
);
const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, './'))); 
let subscriptions = [];
const reminders = new Map();
const server = DEV_HTTP ? http.createServer(app) : https.createServer(sslOptions, app);
const io = socketIo(server, {
    cors: { origin: "*", methods: ["GET", "POST"] }
});

async function sendPushToAll(payload) {
    const results = await Promise.allSettled(
        subscriptions.map(sub =>
            webpush.sendNotification(sub, payload).catch(err => {
                if (err.statusCode === 410 || err.statusCode === 404) {
                    console.log('Removing expired subscription:', sub.endpoint);
                    subscriptions = subscriptions.filter(s => s.endpoint !== sub.endpoint);
                }
                throw err;
            })
        )
    );
    const failed = results.filter(r => r.status === 'rejected');
    if (failed.length > 0) {
        console.warn(`Push failed for ${failed.length} subscribers`);
    }
}

io.on('connection', (socket) => {
    console.log('Клиент подключён:', socket.id);
    socket.on('newTask', (task) => {
        if (!task || !task.text || !task.text.trim()) {
            console.warn('Invalid task received:', task);
            return;
        }
        io.emit('taskAdded', task);
        const payload = JSON.stringify({
            title: 'Новая задача',
            body: task.text
        });
        sendPushToAll(payload).catch(err => console.error('Push broadcast error:', err));
    });
    socket.on('toggleTask', (data) => {
        if (!data || !data.id) {
            console.warn('Invalid toggleTask data:', data);
            return;
        }
        socket.broadcast.emit('taskToggled', data);
    });
    socket.on('deleteTask', (data) => {
        if (!data || !data.id) {
            console.warn('Invalid deleteTask data:', data);
            return;
        }
        socket.broadcast.emit('taskDeleted', data);
    });
    socket.on('newReminder', (reminder) => {
        if (!reminder || !reminder.id || !reminder.text || !reminder.reminderTime) {
            console.warn('Invalid reminder:', reminder);
            return;
        }
        const { id, text, reminderTime } = reminder;
        const delay = reminderTime - Date.now();
        if (delay <= 0) return;
        const timeoutId = setTimeout(() => {
            const payload = JSON.stringify({
                title: 'Напоминание',
                body: text,
                reminderId: id
            });
            sendPushToAll(payload).catch(err => console.error('Reminder push error:', err));
            reminders.delete(id);
        }, delay);
        reminders.set(id, { timeoutId, text, reminderTime });
    });
    socket.on('disconnect', () => {
        console.log('Клиент отключён:', socket.id);
    });
});

function validateSubscription(sub) {
    return sub && typeof sub.endpoint === 'string' && sub.endpoint.startsWith('https://') &&
           sub.keys && typeof sub.keys.p256dh === 'string' && typeof sub.keys.auth === 'string';
}

app.post('/subscribe', (req, res) => {
    const subscription = req.body;
    if (!validateSubscription(subscription)) {
        return res.status(400).json({ error: 'Invalid subscription data' });
    }
    const exists = subscriptions.find(s => s.endpoint === subscription.endpoint);
    if (!exists) {
        subscriptions.push(subscription);
        console.log('New subscription added:', subscription.endpoint.substring(0, 50) + '...');
    }
    res.status(201).json({ message: 'Подписка сохранена' });
});

app.post('/unsubscribe', (req, res) => {
    const { endpoint } = req.body;
    if (!endpoint || typeof endpoint !== 'string') {
        return res.status(400).json({ error: 'Endpoint required' });
    }
    const before = subscriptions.length;
    subscriptions = subscriptions.filter(sub => sub.endpoint !== endpoint);
    const removed = before - subscriptions.length;
    console.log(`Unsubscribe: removed ${removed} subscription(s)`);
    res.status(200).json({ message: 'Подписка удалена', removed });
});

app.post('/snooze', (req, res) => {
    const reminderId = parseInt(req.query.reminderId, 10);
    if (!reminderId || isNaN(reminderId)) {
        return res.status(400).json({ error: 'Valid reminderId required' });
    }
    if (!reminders.has(reminderId)) {
        return res.status(404).json({ error: 'Reminder not found' });
    }
    const reminder = reminders.get(reminderId);
    clearTimeout(reminder.timeoutId);
    const newDelay = 5 * 60 * 1000;
    const newTimeoutId = setTimeout(() => {
        const payload = JSON.stringify({
            title: 'Напоминание отложено',
            body: reminder.text,
            reminderId: reminderId
        });
        sendPushToAll(payload).catch(err => console.error('Snooze push error:', err));
        reminders.delete(reminderId);
    }, newDelay);
    reminders.set(reminderId, {
        timeoutId: newTimeoutId,
        text: reminder.text,
        reminderTime: Date.now() + newDelay
    });
    res.status(200).json({ message: 'Reminder snoozed for 5 minutes' });
});

const PORT = 3001;
server.listen(PORT, '0.0.0.0', () => {
    const protocol = DEV_HTTP ? 'http' : 'https';
    console.log(`Сервер запущен на ${protocol}://localhost:${PORT}`);
});
