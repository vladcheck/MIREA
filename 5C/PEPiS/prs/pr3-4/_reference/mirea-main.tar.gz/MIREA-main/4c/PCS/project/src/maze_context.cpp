#include "../include/maze_context.h"
#include <utility>
#include <stdexcept>
MazeContext::MazeContext(int width, int height, uint32_t sourceSeed)
    : width(width), height(height), sourceSeed(sourceSeed) {
    if (width <= 0 || height <= 0) {
        throw std::invalid_argument("Maze dimensions must be positive");
    }
}
void MazeContext::addCell(CellData data) {
    cells.push_back(std::move(data));
}
const std::vector<CellData>& MazeContext::getCells() const {
    return cells;
}
int MazeContext::getWidth() const {
    return width;
}
int MazeContext::getHeight() const {
    return height;
}
uint32_t MazeContext::getSourceSeed() const {
    return sourceSeed;
}
