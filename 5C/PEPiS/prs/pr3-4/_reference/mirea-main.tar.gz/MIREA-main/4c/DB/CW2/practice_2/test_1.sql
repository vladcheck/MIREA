BEGIN;
DO $$
BEGIN
    RAISE NOTICE 'Тест 1.1: Проверка работы бонусов (INSERT и DELETE)...';

    -- Создаем тестовые объекты недвижимости с нужной ценой, чтобы не мешали триггеры из Практики 1
    INSERT INTO property (id, district_id, address, floor, room_count, type_id, status, price, building_material_id, area, listing_date) 
    VALUES 
        (101, 1, 'Address 101', 1, 2, 1, true, 1000000, 1, 100, CURRENT_DATE),
        (102, 1, 'Address 102', 1, 2, 1, true, 2000000, 1, 100, CURRENT_DATE)
    ON CONFLICT (id) DO NOTHING;

    RAISE NOTICE 'Шаг 1: Создаем продажу (ожидаем начисление 5 процентов бонуса)...';
    INSERT INTO sale (property_id, sale_date, realtor_id, price) VALUES (101, CURRENT_DATE, 1, 1000000);
    
    RAISE NOTICE 'Шаг 2: Создаем еще одну продажу (ожидаем суммирование бонусов)...';
    INSERT INTO sale (property_id, sale_date, realtor_id, price) VALUES (102, CURRENT_DATE, 1, 2000000);
    
    RAISE NOTICE 'Шаг 3: Удаляем вторую продажу (ожидаем вычитание 5 процентов бонуса)...';
    DELETE FROM sale WHERE price = 2000000 AND realtor_id = 1;

    RAISE NOTICE 'Триггер успешно отработал! Ниже будет выведена таблица realtor_bonus:';
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'ОШИБКА: Тест упал при выполнении операций: %', SQLERRM;
END $$;

SELECT * FROM realtor_bonus WHERE realtor_id = 1;

ROLLBACK;