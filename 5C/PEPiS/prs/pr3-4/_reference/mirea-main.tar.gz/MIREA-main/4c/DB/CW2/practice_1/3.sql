CREATE OR REPLACE FUNCTION check_object_area_lyapunov()
    RETURNS TRIGGER AS
$$
DECLARE
    v_total_area     NUMERIC;
    v_new_rooms_area NUMERIC;
    v_difference     NUMERIC;
BEGIN
    SELECT area INTO v_total_area FROM property WHERE id = NEW.property_id;
    SELECT COALESCE(SUM(room_area), 0) + NEW.room_area
    INTO v_new_rooms_area
    FROM property_structure
    WHERE property_id = NEW.property_id;
    IF v_new_rooms_area > v_total_area THEN
        v_difference := v_new_rooms_area - v_total_area;
        RAISE EXCEPTION 'ОШИБКА: Сумма площадей всех комнат (%) превышает общую площадь объекта (%) на %.', v_new_rooms_area, v_total_area, v_difference;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_check_object_area ON property_structure;
CREATE TRIGGER trg_check_object_area
    BEFORE INSERT
    ON property_structure
    FOR EACH ROW
EXECUTE FUNCTION check_object_area_lyapunov();