CREATE OR REPLACE FUNCTION generate_order_numbers(count INTEGER)
    RETURNS TABLE
            (
                order_number TEXT
            )
AS
$$
SELECT 'ORD-' || TO_CHAR(CURRENT_DATE, 'YYYYMM') || LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0')
FROM generate_series(1, count);
$$ LANGUAGE SQL;