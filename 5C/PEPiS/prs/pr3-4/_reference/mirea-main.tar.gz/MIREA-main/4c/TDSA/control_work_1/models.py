from pydantic import BaseModel, Field, field_validator

# Задание 1.4
class User(BaseModel):
    name: str
    id: int

# Задание 1.5
class UserAge(BaseModel):
    name: str
    age: int

# Задание 2.1 и 2.2
class Feedback(BaseModel):
    name: str = Field(..., min_length=2, max_length=50)
    message: str = Field(..., min_length=10, max_length=500)

    @field_validator('message')
    @classmethod
    def validate_message(cls, value: str) -> str:
        forbidden_words = ["кринж", "рофл", "вайб"]
        value_lower = value.lower()
        for word in forbidden_words:
            if word in value_lower:
                raise ValueError("Использование недопустимых слов")
        return value
