import React from 'react';

const Home = () => {
    return (
        <div>
            <h1>Главная страница</h1>
            <p>Добро пожаловать на главную страницу нашего приложения!</p>
        </div>
    );
};

export default Home;
