#ifndef HELLO_H
#define HELLO_H

#include <iostream>

void printHelloWorld(std::ostream& os);

#endif // HELLO_H