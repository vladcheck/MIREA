import amqplib from 'amqplib';

export async function setupQueues() {
    const connection = await amqplib.connect('amqp://localhost');
    const channel = await connection.createChannel();

    // 1. Создаём Dead Letter Exchange
    await channel.assertExchange('dlx_exchange', 'direct', { durable: true });

    // 2. Создаём Dead Letter Queue
    await channel.assertQueue('dead_letter_queue', { durable: true });

    // 3. Привязываем DLQ к DLX
    await channel.bindQueue('dead_letter_queue', 'dlx_exchange', 'dead');

    // 4. Создаём основную очередь с указанием DLX
    await channel.assertQueue('task_queue', {
        durable: true,
        arguments: {
            'x-dead-letter-exchange': 'dlx_exchange',
            'x-dead-letter-routing-key': 'dead',
        },
    });

    console.log('Очереди настроены: task_queue -> [DLX] -> dead_letter_queue');
    await connection.close();
}
