from fastapi import APIRouter, Depends, HTTPException
from app.dependencies import require_admin, get_storage

router = APIRouter(prefix="/admin", tags=["admin"])

@router.get("/stats")
def get_stats(
    admin=Depends(require_admin),
    storage=Depends(get_storage)
):
    total = len(storage.tasks)
    by_status = {"todo": 0, "in_progress": 0, "done": 0}
    for task in storage.tasks.values():
        status = task["status"]
        by_status[status] = by_status.get(status, 0) + 1
        
    return {
        "total_tasks": total,
        "by_status": by_status
    }

@router.delete("/tasks/{task_id}", status_code=204)
def delete_task_admin(
    task_id: int,
    admin=Depends(require_admin),
    storage=Depends(get_storage)
):
    if task_id not in storage.tasks:
        raise HTTPException(status_code=404, detail="Task not found")
    del storage.tasks[task_id]
    return None