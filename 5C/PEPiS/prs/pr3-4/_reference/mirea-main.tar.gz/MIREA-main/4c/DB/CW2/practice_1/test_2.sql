BEGIN;

DO
$$
    BEGIN
        RAISE NOTICE 'Шаг 1: Продаем объект недвижимости в первый раз...';
        INSERT INTO sale (id, property_id, realtor_id, price, sale_date) VALUES (201, 1, 1, 9000000, CURRENT_DATE);

        RAISE NOTICE 'Шаг 2: Пытаемся продать этот же объект во второй раз...';
        INSERT INTO sale (id, property_id, realtor_id, price, sale_date) VALUES (202, 1, 1, 9500000, CURRENT_DATE);

        RAISE NOTICE 'Результат: Ошибка! Триггер не сработал, объект был продан дважды.';
    EXCEPTION
        WHEN OTHERS THEN
            RAISE NOTICE 'Результат: Отлично, тест пройден! Триггер успешно заблокировал повторную сделку.';
            RAISE NOTICE 'Текст ошибки из базы: %', SQLERRM;
    END
$$;

ROLLBACK;