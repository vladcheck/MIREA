#include "catch.hpp"
#include "../include/maze_context.h"
#include "../include/dfs_generator.h"
#include "../include/kruskal_generator.h"
#include "../include/prim_generator.h"
#include "../include/pathfinder.h"
#include "../include/maze_facade.h"
TEST_CASE("Scenario 1: Full generation and pathfinding (DFS)", "[Scenario]") {
    MazeContext ctx(10, 10, 12345);
    MazeFacade facade;
    facade.setGenerator(std::make_unique<DfsGenerator>());
    REQUIRE_NOTHROW(facade.run(ctx));
    REQUIRE(ctx.getCells().size() == 100);
    Pathfinder pf;
    auto path = pf.findPath(ctx, {0, 0}, {9, 9});
    REQUIRE(!path.empty());
    REQUIRE(path.front().x == 0);
    REQUIRE(path.front().y == 0);
    REQUIRE(path.back().x == 9);
    REQUIRE(path.back().y == 9);
}
TEST_CASE("Scenario 2: Full generation and pathfinding (Kruskal)", "[Scenario]") {
    MazeContext ctx(15, 15, 54321);
    MazeFacade facade;
    facade.setGenerator(std::make_unique<KruskalGenerator>());
    REQUIRE_NOTHROW(facade.run(ctx));
    REQUIRE(ctx.getCells().size() == 225);
    Pathfinder pf;
    auto path = pf.findPath(ctx, {0, 0}, {14, 14});
    REQUIRE(!path.empty());
}
TEST_CASE("Scenario 3: Validation of path bounds with Prim", "[Scenario]") {
    MazeContext ctx(8, 8, 42);
    MazeFacade facade;
    facade.setGenerator(std::make_unique<PrimGenerator>());
    REQUIRE_NOTHROW(facade.run(ctx));
    Pathfinder pf;
    REQUIRE_THROWS(pf.findPath(ctx, {0, 0}, {8, 8})); 
    REQUIRE_THROWS(pf.findPath(ctx, {-1, 0}, {7, 7})); 
}