#pragma once
#include <vector>
#include <memory>
#include "i_maze_generator.h"
#include "maze_context.h"
class MazeFacade {
public:
    MazeFacade() = default;
    ~MazeFacade() = default;
    void setGenerator(std::unique_ptr<IMazeGenerator> gen);
    void addRule(std::unique_ptr<IMazeGenerator> rule);
    void run(MazeContext& context);
    void generate(GridNode node, MazeContext& ctx);
private:
    std::unique_ptr<IMazeGenerator> generator;
    std::vector<std::unique_ptr<IMazeGenerator>> rules;
};
