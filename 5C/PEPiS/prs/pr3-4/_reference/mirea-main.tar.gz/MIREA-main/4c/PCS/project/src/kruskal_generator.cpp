#include "../include/kruskal_generator.h"
#include "../include/grid.h"
#include <vector>
#include <numeric>
#include <algorithm>
#include <random>
struct Edge {
    int x1, y1, x2, y2;
    int dir; 
};
struct DSU {
    std::vector<int> parent;
    DSU(int n) {
        parent.resize(n);
        std::iota(parent.begin(), parent.end(), 0);
    }
    int find(int i) {
        if (parent[i] == i) return i;
        return parent[i] = find(parent[i]);
    }
    void unite(int i, int j) {
        int root_i = find(i);
        int root_j = find(j);
        if (root_i != root_j) parent[root_i] = root_j;
    }
};
void KruskalGenerator::generate(GridNode node, MazeContext& ctx) {
    int width = ctx.getWidth();
    int height = ctx.getHeight();
    Grid grid(width, height);
    std::mt19937 rng(ctx.getSourceSeed());
    std::vector<Edge> edges;
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            if (x + 1 < width) edges.push_back({x, y, x + 1, y, 2}); 
            if (y + 1 < height) edges.push_back({x, y, x, y + 1, 1}); 
        }
    }
    std::shuffle(edges.begin(), edges.end(), rng);
    DSU dsu(width * height);
    for (const auto& edge : edges) {
        int idx1 = edge.y1 * width + edge.x1;
        int idx2 = edge.y2 * width + edge.x2;
        if (dsu.find(idx1) != dsu.find(idx2)) {
            dsu.unite(idx1, idx2);
            CellData& cell1 = grid.getCell(edge.x1, edge.y1);
            CellData& cell2 = grid.getCell(edge.x2, edge.y2);
            if (edge.dir == 2) { 
                cell1.wall_east = false;
                cell2.wall_west = false;
            } else if (edge.dir == 1) { 
                cell1.wall_south = false;
                cell2.wall_north = false;
            }
        }
    }
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            ctx.addCell(grid.getCell(x, y));
        }
    }
}
