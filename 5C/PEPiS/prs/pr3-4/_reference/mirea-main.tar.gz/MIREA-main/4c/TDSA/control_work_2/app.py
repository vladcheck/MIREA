from fastapi import FastAPI, Cookie, Response, HTTPException, Depends, Header, Request
from pydantic import BaseModel
from itsdangerous import TimestampSigner, BadSignature, SignatureExpired
import uuid
import time
from typing import Optional, List
from datetime import datetime

from models import UserCreate, LoginData, CommonHeaders

app = FastAPI()

@app.post("/create_user", response_model=UserCreate)
def create_user(user: UserCreate):
    return user

sample_products = [
    {"product_id": 123, "name": "Smartphone", "category": "Electronics", "price": 599.99},
    {"product_id": 456, "name": "Phone Case", "category": "Accessories", "price": 19.99},
    {"product_id": 789, "name": "Iphone", "category": "Electronics", "price": 1299.99},
    {"product_id": 101, "name": "Headphones", "category": "Accessories", "price": 99.99},
    {"product_id": 202, "name": "Smartwatch", "category": "Electronics", "price": 299.99}
]

@app.get("/products/search")
def search_products(keyword: str, category: Optional[str] = None, limit: int = 10):
    results = []
    for p in sample_products:
        if keyword.lower() in p["name"].lower():
            if category:
                if p["category"].lower() == category.lower():
                    results.append(p)
            else:
                results.append(p)
    return results[:limit]

@app.get("/product/{product_id}")
def get_product(product_id: int):
    for p in sample_products:
        if p["product_id"] == product_id:
            return p
    raise HTTPException(status_code=404, detail="Product not found")

SECRET_KEY = "my_super_secret_key"
signer = TimestampSigner(SECRET_KEY)

@app.post("/login")
def login(data: LoginData, response: Response):
    user_id = str(uuid.uuid4())
    token = signer.sign(user_id).decode("utf-8")
    
    response.set_cookie(
        key="session_token",
        value=token,
        httponly=True,
        secure=False,
        max_age=300
    )
    return {"message": "Logged in successfully"}

@app.get("/profile")
def get_profile(response: Response, session_token: Optional[str] = Cookie(None)):
    if not session_token:
        response.status_code = 401
        return {"message": "Unauthorized"}
    
    try:
        user_id_bytes, timestamp = signer.unsign(session_token, max_age=300, return_timestamp=True)
        user_id = user_id_bytes.decode("utf-8")
        
        now = datetime.utcnow()
        time_passed = (now - timestamp).total_seconds()
        
        if 180 <= time_passed < 300:
            new_token = signer.sign(user_id).decode("utf-8")
            response.set_cookie(
                key="session_token",
                value=new_token,
                httponly=True,
                secure=False,
                max_age=300
            )
            
        return {"message": "Profile access granted", "user_id": user_id}

    except SignatureExpired:
        response.status_code = 401
        return {"message": "Session expired"}
    except BadSignature:
        response.status_code = 401
        return {"message": "Invalid session"}

@app.get("/headers")
def get_headers(headers: CommonHeaders = Depends()):
    return {
        "User-Agent": headers.user_agent,
        "Accept-Language": headers.accept_language
    }

@app.get("/info")
def get_info(response: Response, headers: CommonHeaders = Depends()):
    current_time = datetime.utcnow().isoformat()
    response.headers["X-Server-Time"] = current_time
    return {
        "message": "Добро пожаловать! Ваши заголовки успешно обработаны.",
        "headers": {
            "User-Agent": headers.user_agent,
            "Accept-Language": headers.accept_language
        }
    }
