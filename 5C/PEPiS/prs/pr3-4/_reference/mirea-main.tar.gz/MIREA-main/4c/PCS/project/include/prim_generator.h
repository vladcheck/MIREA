#pragma once
#include "i_maze_generator.h"
class PrimGenerator : public IMazeGenerator {
public:
    void generate(GridNode node, MazeContext& ctx) override;
};
