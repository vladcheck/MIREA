#pragma once
#include "cell.h"
#include <stdexcept>
#include <vector>
class Grid {
public:
  Grid(int width, int height);
  int getWidth() const { return width; }
  int getHeight() const { return height; }
  CellData &getCell(int x, int y);
  const CellData &getCell(int x, int y) const;
  bool isValid(int x, int y) const;
private:
  int width, height;
  std::vector<CellData> cells;
};
