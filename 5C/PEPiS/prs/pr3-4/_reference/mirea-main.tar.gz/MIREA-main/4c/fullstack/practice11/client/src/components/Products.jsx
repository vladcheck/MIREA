import React, { useEffect, useState } from 'react';
import api from '../api';

const Products = ({ user }) => {
    const [products, setProducts] = useState([]);
    const [name, setName] = useState('');
    const [price, setPrice] = useState('');
    const [description, setDescription] = useState('');
    const [editingId, setEditingId] = useState(null);
    const [error, setError] = useState('');

    const canManage = user.role === 'seller' || user.role === 'admin';
    const canDelete = user.role === 'admin';

    const fetchProducts = async () => {
        try {
            const { data } = await api.get('/products');
            setProducts(data);
        } catch (error) {
            setError('Не удалось загрузить список товаров');
        }
    };

    useEffect(() => {
        fetchProducts();
    }, []);

    const handleCreateOrUpdate = async (e) => {
        e.preventDefault();
        setError('');
        
        if (!name || !price) {
            setError('Название и цена обязательны для заполнения');
            return;
        }

        try {
            if (editingId) {
                await api.put(`/products/${editingId}`, { name, price: Number(price), description });
            } else {
                await api.post('/products', { name, price: Number(price), description });
            }
            
            setName('');
            setPrice('');
            setDescription('');
            setEditingId(null);
            fetchProducts();
        } catch (err) {
            setError('Ошибка: ' + (err.response?.data?.message || 'Неизвестная ошибка'));
        }
    };

    const handleEdit = (product) => {
        setEditingId(product._id);
        setName(product.name);
        setPrice(product.price);
        setDescription(product.description || '');
        setError('');
    };

    const handleDelete = async (id) => {
        if (!window.confirm('Вы уверены, что хотите удалить этот товар?')) return;
        
        try {
            await api.delete(`/products/${id}`);
            fetchProducts();
        } catch (err) {
            setError('Ошибка при удалении: ' + (err.response?.data?.message || 'Неизвестная ошибка'));
        }
    };

    const handleCancelEdit = () => {
        setEditingId(null);
        setName('');
        setPrice('');
        setDescription('');
        setError('');
    };

    return (
        <div className="products-container">
            <div className="products-header">
                <h2>Список товаров</h2>
            </div>
            
            {error && <div className="error-message">{error}</div>}
            
            {canManage && (
                <form onSubmit={handleCreateOrUpdate} className="product-form">
                    <h3>{editingId ? 'Редактировать товар' : 'Новый товар (Seller/Admin)'}</h3>
                    
                    <div className="product-inputs">
                        <input 
                            type="text" 
                            placeholder="Название" 
                            value={name} 
                            onChange={e => setName(e.target.value)} 
                            className="input-field"
                        />
                        <input 
                            type="number" 
                            placeholder="Цена (руб.)" 
                            value={price} 
                            onChange={e => setPrice(e.target.value)} 
                            className="input-field"
                        />
                        <input 
                            type="text" 
                            placeholder="Описание..." 
                            value={description} 
                            onChange={e => setDescription(e.target.value)} 
                            className="input-field"
                        />
                    </div>
                    
                    <div>
                        <button type="submit" className="btn-primary">
                            {editingId ? 'Сохранить изменения' : 'Добавить товар'}
                        </button>
                        {editingId && (
                            <button type="button" onClick={handleCancelEdit} className="btn-secondary" style={{marginLeft: '10px'}}>
                                Отмена
                            </button>
                        )}
                    </div>
                </form>
            )}

            {products.length === 0 ? (
                <p style={{ textAlign: 'center' }}>Товаров пока нет.</p>
            ) : (
                <ul style={{ listStyleType: 'none', padding: 0 }}>
                    {products.map(product => (
                        <li key={product._id} className="product-item">
                            <div className="product-info">
                                <h4>{product.name}</h4>
                                <span className="price">{product.price} ₽</span>
                                <span className="desc">{product.description || 'Нет описания'}</span>
                            </div>
                            <div className="product-actions">
                                {canManage && (
                                    <button onClick={() => handleEdit(product)} className="btn-secondary">
                                        Изменить
                                    </button>
                                )}
                                {canDelete && (
                                    <button onClick={() => handleDelete(product._id)} className="btn-danger">
                                        Удалить
                                    </button>
                                )}
                            </div>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default Products;