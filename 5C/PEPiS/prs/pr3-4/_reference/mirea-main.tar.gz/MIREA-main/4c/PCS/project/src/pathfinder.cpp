#include "../include/pathfinder.h"
#include "../include/exceptions.h"
#include <queue>
#include <map>
#include <algorithm>
std::vector<Point> Pathfinder::findPath(const MazeContext& ctx, Point start, Point end) {
    int width = ctx.getWidth();
    int height = ctx.getHeight();
    const auto& cells = ctx.getCells();
    if (start.x < 0 || start.x >= width || start.y < 0 || start.y >= height) {
        throw MazeBoundsException("Start coordinate out of bounds");
    }
    if (end.x < 0 || end.x >= width || end.y < 0 || end.y >= height) {
        throw MazeBoundsException("End coordinate out of bounds");
    }
    std::vector<const CellData*> grid(width * height, nullptr);
    for (const auto& cell : cells) {
        if (cell.x >= 0 && cell.x < width && cell.y >= 0 && cell.y < height) {
            grid[cell.y * width + cell.x] = &cell;
        }
    }
    std::queue<Point> q;
    q.push(start);
    std::map<int, Point> parent;
    std::vector<bool> visited(width * height, false);
    visited[start.y * width + start.x] = true;
    bool found = false;
    while (!q.empty()) {
        Point current = q.front();
        q.pop();
        if (current == end) {
            found = true;
            break;
        }
        const CellData* cell = grid[current.y * width + current.x];
        if (!cell) continue;
        struct Neighbor { int dx, dy; bool wall; };
        std::vector<Neighbor> neighbors = {
            {0, -1, cell->wall_north},
            {0, 1, cell->wall_south},
            {1, 0, cell->wall_east},
            {-1, 0, cell->wall_west}
        };
        for (const auto& n : neighbors) {
            int nx = current.x + n.dx;
            int ny = current.y + n.dy;
            if (nx >= 0 && nx < width && ny >= 0 && ny < height && !n.wall) {
                int n_idx = ny * width + nx;
                if (!visited[n_idx]) {
                    visited[n_idx] = true;
                    parent[n_idx] = current;
                    q.push({nx, ny});
                }
            }
        }
    }
    if (!found) return {};
    std::vector<Point> path;
    Point curr = end;
    while (!(curr == start)) {
        path.push_back(curr);
        curr = parent[curr.y * width + curr.x];
    }
    path.push_back(start);
    std::reverse(path.begin(), path.end());
    return path;
}
