CREATE TABLE IF NOT EXISTS realtor_bonus (
    realtor_id INTEGER PRIMARY KEY REFERENCES realtor(id),
    bonus_amount NUMERIC DEFAULT 0
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'realtor' AND column_name = 'passport_data'
    ) THEN
        ALTER TABLE realtor ADD COLUMN passport_data VARCHAR(15);
    END IF;
END $$;\n