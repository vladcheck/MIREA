from fastapi import Header, HTTPException, Depends
from typing import Optional
from app.schemas import User
from app.storage import storage
from functools import lru_cache

def get_current_user(
    x_user_id: Optional[str] = Header(None, alias="X-User-Id"),
    x_user_role: str = Header("user", alias="X-User-Role")
) -> User:
    if x_user_id is None:
        raise HTTPException(status_code=401, detail="X-User-Id missing")
    try:
        user_id = int(x_user_id)
    except ValueError:
        raise HTTPException(status_code=401, detail="X-User-Id must be an integer")
    return User(id=user_id, role=x_user_role)

def require_admin(user: User = Depends(get_current_user)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin permissions required")
    return user

def get_storage():
    return storage