CREATE OR REPLACE FUNCTION format_phone_number_lyapunov()
    RETURNS TRIGGER AS
$$
BEGIN
    IF NEW.phone_number IS NOT NULL THEN
        IF NEW.phone_number ~ '^[78]\d{10}$' THEN
            NEW.phone_number := '+7 (' || substr(NEW.phone_number, 2, 3) || ') ' ||
                                substr(NEW.phone_number, 5, 3) || ' ' ||
                                substr(NEW.phone_number, 8, 2) || ' ' ||
                                substr(NEW.phone_number, 10, 2);
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_format_phone_number ON realtor;
CREATE TRIGGER trg_format_phone_number
    BEFORE INSERT OR UPDATE
    ON realtor
    FOR EACH ROW
EXECUTE FUNCTION format_phone_number_lyapunov();