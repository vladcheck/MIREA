#include "../include/maze_exporter.h"
#include <sstream>
#include <vector>
#include <map>
#include <algorithm>
std::string AsciiExporter::exportMaze(const MazeContext& ctx, const std::vector<Point>& path) {
    int width = ctx.getWidth();
    int height = ctx.getHeight();
    const auto& cells = ctx.getCells();
    std::vector<std::vector<const CellData*>> grid(height, std::vector<const CellData*>(width, nullptr));
    for (const auto& cell : cells) {
        if (cell.x >= 0 && cell.x < width && cell.y >= 0 && cell.y < height) {
            grid[cell.y][cell.x] = &cell;
        }
    }
    std::stringstream ss;
    for (int x = 0; x < width; ++x) {
        ss << "+---";
    }
    ss << "+\n";
    for (int y = 0; y < height; ++y) {
        ss << "|";
        for (int x = 0; x < width; ++x) {
            bool inPath = std::find(path.begin(), path.end(), Point{x, y}) != path.end();
            if (inPath) {
                ss << " * ";
            } else {
                ss << "   ";
            }
            if (x == width - 1 || grid[y][x]->wall_east) {
                ss << "|";
            } else {
                ss << " ";
            }
        }
        ss << "\n";
        ss << "+";
        for (int x = 0; x < width; ++x) {
            if (y == height - 1 || grid[y][x]->wall_south) {
                ss << "---";
            } else {
                ss << "   ";
            }
            ss << "+";
        }
        ss << "\n";
    }
    return ss.str();
}
