const express = require('express')
const cors = require('cors')
const app = express()
const port = 3001

// Middleware
app.use(cors())
app.use(express.json())
app.use(express.static('public'))

// База данных товаров магазина "Копеечка" (в памяти)
let products = [
	{
		id: 1,
		name: 'Хлеб "Дарницкий" нарезной',
		category: 'Хлеб и выпечка',
		description:
			'Настоящий ржано-пшеничный хлеб, как в СССР. Хрустящая корочка, классический вкус. Срок годности 3 дня.',
		price: 45.9,
		stock: 127,
		rating: 4.8,
		image:
			'/images/khleb-darnitskiy.jpg',
	},
	{
		id: 2,
		name: 'Молоко "Простоквашино" 3.2%',
		category: 'Молочные продукты',
		description:
			'Отборное молоко из деревни. Натуральное, пастеризованное, без сухого молока. Пластиковая бутылка 930 мл.',
		price: 89.9,
		stock: 243,
		rating: 4.9,
		image:
			'/images/moloko-prostokvashino.jpg',
	},
	{
		id: 3,
		name: 'Колбаса "Докторская" ГОСТ',
		category: 'Колбасы и мясо',
		description:
			'Легендарная варёная колбаса по ГОСТу. Как в детстве! Без сои и крахмала. Высший сорт, 300 гр.',
		price: 199.9,
		stock: 85,
		rating: 4.7,
		image:
			'/images/kolbasa-doktorskaya.jpg',
	},
	{
		id: 4,
		name: 'Сыр "Российский" 50%',
		category: 'Молочные продукты',
		description:
			'Твёрдый сыр "Российский" в нарезке. Изготовлен по традиционной технологии.',
		price: 159.9,
		stock: 156,
		rating: 4.6,
		image:
			'/images/syr-rossiyskiy.jpg',
	},
	{
		id: 5,
		name: 'Пельмени "Сибирская коллекция"',
		category: 'Замороженные продукты',
		description:
			'Пельмени "Сочные" с фаршем на молоке. Классические пельмени с говядиной и свининой. Сочная начинка, тонкое тесто. 400 гр.',
		price: 249.9,
		stock: 92,
		rating: 4.9,
		image:
			'https://dixy.ru/upload/iblock/051/kmmnwajiqww38pp0qscgn294bj2vvau7.webp',
	},
	{
		id: 6,
		name: 'Сметана "Домик в деревне" 20%',
		category: 'Молочные продукты',
		description:
			'Густая натуральная сметана. Без растительных жиров и стабилизаторов. Пластиковый стакан 350 гр.',
		price: 119.9,
		stock: 178,
		rating: 4.8,
		image:
			'/images/smetana-domik-v-derevne.jpg',
	},
	{
		id: 7,
		name: 'Яйца куриные С1, 30 шт',
		category: 'Яйца',
		description:
			'Свежие куриные яйца первой категории. От местных производителей. Проверено на свежесть. Упаковка 30 шт.',
		price: 329.9,
		stock: 312,
		rating: 4.7,
		image:
			'/images/eggs-c1-30pcs.jpg',
	},
	{
		id: 8,
		name: 'Майонез "Провансаль" 67%',
		category: 'Соусы и приправы',
		description:
			'Классический советский майонез "Провансаль". Настоящий вкус из прошлого. Дой-пак 400 гр.',
		price: 79.9,
		stock: 214,
		rating: 4.5,
		image:
			'/images/maionez-provansali.jpg',
},
	{
		id: 9,
		name: 'Гречка "Увелка" Гречневая',
		category: 'Крупы и макароны',
		description:
			'Гречневая крупа, чистая отборная крупа. Высший сорт. Без мусора и примесей. Пакет 800 гр.',
		price: 119.9,
		stock: 267,
		rating: 4.9,
		image:
			'/images/uvelka-grechka-800g.jpg',
	},
	{
		id: 10,
		name: 'Водка "Белая Березка"',
		category: 'Алкоголь',
		description:
			'Классическая русская водка, которая производится на основе отборного зернового спирта класса «Люкс» и чистейшей природной воды с добавлением натурального березового сока.',
		price: 649.9,
		stock: 143,
		rating: 4.9,
		image:
			'/images/belaya-berezka-vodka.jpg',
	},
	{
		id: 11,
		name: 'Ликер Jägermeister',
		category: 'Алкоголь',
		description:
			'Популярный немецкий крепкий ликер, настоянный на 56 травах, кореньях, фруктах и специях. Идеален в качестве дижестива или в составе коктейлей. 1 л.',
		price: 2099.9,
		stock: 45,
		rating: 4.8,
		image:
			'/images/jagermeister-1l.jpg',
	},
	{
		id: 12,
		name: 'Пиво "Жигулёвское" светлое',
		category: 'Напитки',
		description:
			'Классическое "Жигулёвское" пиво. Легендарный вкус с 1881 года. Алкоголь 4.0%. Стеклянная бутылка 0.5 л.',
		price: 69.9,
		stock: 198,
		rating: 4.6,
		image:
			'/images/zhigulevskoe-pivo.jpg',
	},
]

// Маршруты API
app.get('/', (req, res) => {
	res.json({
		message: 'API магазина "Копеечка" - Выгодные покупки каждый день!',
	})
})

// Получить все товары
app.get('/api/products', (req, res) => {
	res.json(products)
})

// Получить товар по ID
app.get('/api/products/:id', (req, res) => {
	const product = products.find(p => p.id === Number(req.params.id))
	if (!product) {
		return res.status(404).json({ error: 'Товар не найден' })
	}
	res.json(product)
})

// Получить товары по категории
app.get('/api/products/category/:category', (req, res) => {
	const filtered = products.filter(p => p.category === req.params.category)
	res.json(filtered)
})

// Добавить новый товар
app.post('/api/products', (req, res) => {
	const { name, category, description, price, stock, rating, image } = req.body

	if (!name || !category || !price) {
		return res
			.status(400)
			.json({ error: 'Необходимо указать name, category и price' })
	}

	const newProduct = {
		id: Date.now(),
		name,
		category,
		description: description || '',
		price: Number(price),
		stock: stock || 0,
		rating: rating || 0,
		image: image || '',
	}

	products.push(newProduct)
	res.status(201).json(newProduct)
})

// Обновить товар
app.patch('/api/products/:id', (req, res) => {
	const product = products.find(p => p.id === Number(req.params.id))

	if (!product) {
		return res.status(404).json({ error: 'Товар не найден' })
	}

	const { name, category, description, price, stock, rating, image } = req.body

	if (name !== undefined) product.name = name
	if (category !== undefined) product.category = category
	if (description !== undefined) product.description = description
	if (price !== undefined) product.price = Number(price)
	if (stock !== undefined) product.stock = Number(stock)
	if (rating !== undefined) product.rating = Number(rating)
	if (image !== undefined) product.image = image

	res.json(product)
})

// Удалить товар
app.delete('/api/products/:id', (req, res) => {
	const index = products.findIndex(p => p.id === Number(req.params.id))

	if (index === -1) {
		return res.status(404).json({ error: 'Товар не найден' })
	}

	products.splice(index, 1)
	res.json({ message: 'Товар удалён' })
})

// Запуск сервера
app.listen(port, () => {
	console.log(`Сервер запущен на http://localhost:${port}`)
})