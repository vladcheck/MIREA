#include "../include/dfs_generator.h"
#include "../include/grid.h"
#include <stack>
#include <vector>
#include <algorithm>
#include <random>
#include <utility>
void DfsGenerator::generate(GridNode startNode, MazeContext& ctx) {
    int width = ctx.getWidth();
    int height = ctx.getHeight();
    Grid grid(width, height);
    std::mt19937 rng(ctx.getSourceSeed());
    std::stack<GridNode> stack;
    std::vector<bool> visited(width * height, false);
    stack.push(startNode);
    visited[startNode.y * width + startNode.x] = true;
    while (!stack.empty()) {
        GridNode current = stack.top();
        std::vector<int> dirs = {0, 1, 2, 3}; 
        std::shuffle(dirs.begin(), dirs.end(), rng);
        bool found = false;
        for (int dir : dirs) {
            int nx = current.x, ny = current.y;
            if (dir == 0) ny--; 
            else if (dir == 1) ny++; 
            else if (dir == 2) nx++; 
            else if (dir == 3) nx--; 
            if (grid.isValid(nx, ny) && !visited[ny * width + nx]) {
                CellData& currentCell = grid.getCell(current.x, current.y);
                CellData& nextCell = grid.getCell(nx, ny);
                if (dir == 0) {
                    currentCell.wall_north = false;
                    nextCell.wall_south = false;
                } else if (dir == 1) {
                    currentCell.wall_south = false;
                    nextCell.wall_north = false;
                } else if (dir == 2) {
                    currentCell.wall_east = false;
                    nextCell.wall_west = false;
                } else if (dir == 3) {
                    currentCell.wall_west = false;
                    nextCell.wall_east = false;
                }
                visited[ny * width + nx] = true;
                stack.push({nx, ny});
                found = true;
                break;
            }
        }
        if (!found) {
            stack.pop();
        }
    }
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            ctx.addCell(grid.getCell(x, y));
        }
    }
}
