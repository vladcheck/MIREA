#pragma once
#include <vector>
#include <cstdint>
#include "cell.h"
class MazeContext {
public:
    MazeContext(int width, int height, uint32_t sourceSeed);
    void addCell(CellData data);
    const std::vector<CellData>& getCells() const;
    int getWidth() const;
    int getHeight() const;
    uint32_t getSourceSeed() const;
private:
    int width;
    int height;
    uint32_t sourceSeed;
    std::vector<CellData> cells;
};
