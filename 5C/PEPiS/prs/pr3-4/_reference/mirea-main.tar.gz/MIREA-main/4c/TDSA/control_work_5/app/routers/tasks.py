from fastapi import APIRouter, Depends, HTTPException, Query
from typing import Optional
from app.schemas import TaskCreate, TaskResponse, TaskUpdateStatus, User
from app.dependencies import get_current_user, get_storage

router = APIRouter(prefix="/tasks", tags=["tasks"])

@router.post("", response_model=TaskResponse, status_code=201)
def create_task(
    task: TaskCreate,
    user: User = Depends(get_current_user),
    storage=Depends(get_storage)
):
    task_dict = task.model_dump()
    task_dict["id"] = storage.counter
    task_dict["owner_id"] = user.id
    
    storage.tasks[storage.counter] = task_dict
    storage.counter += 1
    
    return task_dict

@router.get("", response_model=list[TaskResponse])
def get_tasks(
    status: Optional[str] = Query(None),
    min_priority: Optional[int] = Query(None),
    user: User = Depends(get_current_user),
    storage=Depends(get_storage)
):
    result = []
    for task_id, task in storage.tasks.items():
        if task["owner_id"] != user.id:
            continue
        if status and task["status"] != status:
            continue
        if min_priority is not None and task["priority"] < min_priority:
            continue
        result.append(task)
    return result

@router.get("/{task_id}", response_model=TaskResponse)
def get_task(
    task_id: int,
    user: User = Depends(get_current_user),
    storage=Depends(get_storage)
):
    if task_id not in storage.tasks:
        raise HTTPException(status_code=404, detail="Task not found")
    task = storage.tasks[task_id]
    if task["owner_id"] != user.id:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@router.patch("/{task_id}/status", response_model=TaskResponse)
def update_task_status(
    task_id: int,
    status_update: TaskUpdateStatus,
    user: User = Depends(get_current_user),
    storage=Depends(get_storage)
):
    if task_id not in storage.tasks:
        raise HTTPException(status_code=404, detail="Task not found")
    task = storage.tasks[task_id]
    if task["owner_id"] != user.id:
        raise HTTPException(status_code=404, detail="Task not found")
    
    storage.tasks[task_id]["status"] = status_update.status
    return storage.tasks[task_id]

@router.delete("/{task_id}", status_code=204)
def delete_task(
    task_id: int,
    user: User = Depends(get_current_user),
    storage=Depends(get_storage)
):
    if task_id not in storage.tasks:
        raise HTTPException(status_code=404, detail="Task not found")
    task = storage.tasks[task_id]
    if task["owner_id"] != user.id:
        raise HTTPException(status_code=404, detail="Task not found")
    
    del storage.tasks[task_id]
    return None