import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.storage import storage

@pytest.fixture
def client():
    # Очищаем хранилище перед каждым тестом
    storage.drop()
    return TestClient(app)

def test_create_task(client):
    response = client.post(
        "/tasks",
        headers={"X-User-Id": "10"},
        json={
            "title": "Подготовить тесты",
            "description": "Написать интеграционные тесты для основных сценариев",
            "status": "todo",
            "priority": 4
        }
    )
    assert response.status_code == 201
    data = response.json()
    assert data["id"] == 1
    assert data["title"] == "Подготовить тесты"
    assert data["owner_id"] == 10

def test_create_task_validation_error(client):
    response = client.post(
        "/tasks",
        headers={"X-User-Id": "10"},
        json={
            "title": "ab",
            "status": "todo",
            "priority": 4
        }
    )
    assert response.status_code == 422

def test_unauthorized(client):
    response = client.post(
        "/tasks",
        json={
            "title": "Тестовая задача",
            "status": "todo",
            "priority": 4
        }
    )
    assert response.status_code == 401

def test_user_sees_only_own_tasks(client):
    # User 10 creates a task
    client.post(
        "/tasks",
        headers={"X-User-Id": "10"},
        json={"title": "Задача юзера 10", "status": "todo", "priority": 4}
    )
    # User 20 creates a task
    client.post(
        "/tasks",
        headers={"X-User-Id": "20"},
        json={"title": "Задача юзера 20", "status": "todo", "priority": 4}
    )
    
    response = client.get("/tasks", headers={"X-User-Id": "10"})
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["title"] == "Задача юзера 10"

def test_filter_tasks(client):
    client.post(
        "/tasks",
        headers={"X-User-Id": "10"},
        json={"title": "Задача 1", "status": "todo", "priority": 1}
    )
    client.post(
        "/tasks",
        headers={"X-User-Id": "10"},
        json={"title": "Задача 2", "status": "done", "priority": 5}
    )
    client.post(
        "/tasks",
        headers={"X-User-Id": "10"},
        json={"title": "Задача 3", "status": "done", "priority": 2}
    )
    
    response = client.get("/tasks?status=done&min_priority=3", headers={"X-User-Id": "10"})
    data = response.json()
    assert len(data) == 1
    assert data[0]["title"] == "Задача 2"

def test_get_task_success(client):
    create_response = client.post(
        "/tasks",
        headers={"X-User-Id": "10"},
        json={"title": "Задача", "status": "todo", "priority": 1}
    )
    task_id = create_response.json()["id"]
    
    get_response = client.get(f"/tasks/{task_id}", headers={"X-User-Id": "10"})
    assert get_response.status_code == 200
    assert get_response.json()["title"] == "Задача"

def test_get_task_not_found(client):
    response = client.get("/tasks/999", headers={"X-User-Id": "10"})
    assert response.status_code == 404

def test_update_status(client):
    create_response = client.post(
        "/tasks",
        headers={"X-User-Id": "10"},
        json={"title": "Задача", "status": "todo", "priority": 1}
    )
    task_id = create_response.json()["id"]
    
    update_response = client.patch(
        f"/tasks/{task_id}/status",
        headers={"X-User-Id": "10"},
        json={"status": "done"}
    )
    assert update_response.status_code == 200
    assert update_response.json()["status"] == "done"

def test_update_status_not_found(client):
    response = client.patch(
        "/tasks/999/status",
        headers={"X-User-Id": "10"},
        json={"status": "done"}
    )
    assert response.status_code == 404

def test_update_status_forbidden(client):
    create_response = client.post(
        "/tasks",
        headers={"X-User-Id": "10"},
        json={"title": "Task 1", "status": "todo", "priority": 1}
    )
    task_id = create_response.json()["id"]
    
    response = client.patch(
        f"/tasks/{task_id}/status",
        headers={"X-User-Id": "20"},
        json={"status": "done"}
    )
    assert response.status_code == 404

def test_get_other_user_task_404(client):
    create_response = client.post(
        "/tasks",
        headers={"X-User-Id": "10"},
        json={"title": "Задача", "status": "todo", "priority": 1}
    )
    task_id = create_response.json()["id"]
    
    get_response = client.get(f"/tasks/{task_id}", headers={"X-User-Id": "20"})
    assert get_response.status_code == 404

def test_delete_task_not_found(client):
    response = client.delete("/tasks/999", headers={"X-User-Id": "10"})
    assert response.status_code == 404

def test_delete_task(client):
    create_response = client.post(
        "/tasks",
        headers={"X-User-Id": "10"},
        json={"title": "Задача", "status": "todo", "priority": 1}
    )
    task_id = create_response.json()["id"]
    
    delete_response = client.delete(f"/tasks/{task_id}", headers={"X-User-Id": "10"})
    assert delete_response.status_code == 204
    
    get_response = client.get(f"/tasks/{task_id}", headers={"X-User-Id": "10"})
    assert get_response.status_code == 404

def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "env": "local"}