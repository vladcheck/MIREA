#include "../include/prim_generator.h"
#include "../include/grid.h"
#include <vector>
#include <random>
#include <algorithm>
struct FrontierEdge {
    int x1, y1; 
    int x2, y2; 
    int dir;    
};
void PrimGenerator::generate(GridNode node, MazeContext& ctx) {
    int width = ctx.getWidth();
    int height = ctx.getHeight();
    Grid grid(width, height);
    std::mt19937 rng(ctx.getSourceSeed());
    std::vector<bool> in_maze(width * height, false);
    std::vector<FrontierEdge> frontier;
    auto add_frontier = [&](int x, int y) {
        if (x > 0 && !in_maze[y * width + (x - 1)]) frontier.push_back({x, y, x - 1, y, 3}); 
        if (x < width - 1 && !in_maze[y * width + (x + 1)]) frontier.push_back({x, y, x + 1, y, 2}); 
        if (y > 0 && !in_maze[(y - 1) * width + x]) frontier.push_back({x, y, x, y - 1, 0}); 
        if (y < height - 1 && !in_maze[(y + 1) * width + x]) frontier.push_back({x, y, x, y + 1, 1}); 
    };
    int start_x = node.x >= 0 && node.x < width ? node.x : 0;
    int start_y = node.y >= 0 && node.y < height ? node.y : 0;
    in_maze[start_y * width + start_x] = true;
    add_frontier(start_x, start_y);
    while (!frontier.empty()) {
        std::uniform_int_distribution<size_t> dist(0, frontier.size() - 1);
        size_t idx = dist(rng);
        FrontierEdge edge = frontier[idx];
        frontier[idx] = frontier.back();
        frontier.pop_back();
        int nx = edge.x2, ny = edge.y2;
        if (!in_maze[ny * width + nx]) {
            in_maze[ny * width + nx] = true;
            CellData& cell1 = grid.getCell(edge.x1, edge.y1);
            CellData& cell2 = grid.getCell(edge.x2, edge.y2);
            if (edge.dir == 0) { 
                cell1.wall_north = false;
                cell2.wall_south = false;
            } else if (edge.dir == 1) { 
                cell1.wall_south = false;
                cell2.wall_north = false;
            } else if (edge.dir == 2) { 
                cell1.wall_east = false;
                cell2.wall_west = false;
            } else if (edge.dir == 3) { 
                cell1.wall_west = false;
                cell2.wall_east = false;
            }
            add_frontier(nx, ny);
        }
    }
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            ctx.addCell(grid.getCell(x, y));
        }
    }
}
