from fastapi import FastAPI
from fastapi.responses import FileResponse
from models import User, UserAge, Feedback

my_app = FastAPI()


@my_app.get("/hello")
def read_root():
    return {"message": "Авторелоад действительно работает"}


@my_app.get("/")
def read_html():
    return FileResponse("index.html")


@my_app.post("/calculate")
def calculate(num1: int, num2: int):
    return {"result": num1 + num2}


user_instance = User(name="Ваше Имя и Фамилия", id=1)


@my_app.get("/users")
def get_users():
    return user_instance


@my_app.post("/user")
def create_user(user: UserAge):
    is_adult = user.age >= 18
    return {"name": user.name, "age": user.age, "is_adult": is_adult}


feedbacks = []


@my_app.post("/feedback")
def post_feedback(feedback: Feedback):
    feedbacks.append(feedback)
    return {"message": f"Спасибо, {feedback.name}! Ваш отзыв сохранён."}
