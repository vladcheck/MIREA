CREATE OR REPLACE FUNCTION get_realtor_salary_lyapunov(
    p_s DOUBLE PRECISION,
    p_r DOUBLE PRECISION,
    p_month INTEGER,
    p_year INTEGER,
    p_surname VARCHAR
)
    RETURNS DOUBLE PRECISION
    LANGUAGE SQL
AS
$$
SELECT COALESCE(SUM(s.price), 0) * p_s + p_r
FROM realtor r
         LEFT JOIN sale s
                   ON r.id = s.realtor_id
                       AND EXTRACT(MONTH FROM s.sale_date) = p_month
                       AND EXTRACT(YEAR FROM s.sale_date) = p_year
WHERE r.last_name = p_surname;
$$;