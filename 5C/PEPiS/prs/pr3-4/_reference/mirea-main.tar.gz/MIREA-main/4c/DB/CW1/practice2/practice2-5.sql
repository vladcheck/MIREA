CREATE OR REPLACE FUNCTION get_yearly_sales_stats_lyapunov(p_year INTEGER)
    RETURNS TABLE
            (
                type_name  VARCHAR,
                sale_count INTEGER,
                percentage NUMERIC,
                total_sum  BIGINT
            )
    LANGUAGE SQL
AS
$$
SELECT t.name::VARCHAR,
       COUNT(*)::INTEGER                                  AS sale_count,
       ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS percentage,
       SUM(s.price)::BIGINT                               AS total_sum
FROM sale s
         JOIN property p ON s.property_id = p.id
         JOIN type t ON p.type_id = t.id
WHERE EXTRACT(YEAR FROM s.sale_date) = p_year
GROUP BY t.id, t.name;
$$;