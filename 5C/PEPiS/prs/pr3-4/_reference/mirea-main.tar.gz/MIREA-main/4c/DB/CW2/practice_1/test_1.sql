BEGIN;
DO $$ 
BEGIN
    RAISE NOTICE 'Тест 1.1: Продажа со скидкой 25%%';
    INSERT INTO sale (id, property_id, realtor_id, price, sale_date) VALUES (101, 1, 1, 7500000, CURRENT_DATE);
END $$;
ROLLBACK;

BEGIN;
DO $$
BEGIN
    RAISE NOTICE 'Тест 1.2: Продажа с наценкой 50%%';
    INSERT INTO sale (id, property_id, realtor_id, price, sale_date) VALUES (102, 1, 1, 15000000, CURRENT_DATE);
END $$;
ROLLBACK;

BEGIN;
DO $$
BEGIN
    RAISE NOTICE 'Тест 1.3: Разница ровно 20%%';
    INSERT INTO sale (id, property_id, realtor_id, price, sale_date) VALUES (103, 1, 1, 8000000, CURRENT_DATE);
END $$;
ROLLBACK;

BEGIN;
DO $$
BEGIN
    RAISE NOTICE 'Тест 1.4: Продажа с допустимой разницей 10%%';
    INSERT INTO sale (id, property_id, realtor_id, price, sale_date) VALUES (104, 1, 1, 9000000, CURRENT_DATE);
END $$;
ROLLBACK;

BEGIN;
DO $$
BEGIN
    RAISE NOTICE 'Тест 1.5: Некорректная цена 0';
    INSERT INTO sale (id, property_id, realtor_id, price, sale_date) VALUES (105, 1, 1, 0, CURRENT_DATE);
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'ОШИБКА БД перехвачена: %', SQLERRM;
END $$;
ROLLBACK;
