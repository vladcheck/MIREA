from pydantic import BaseModel, EmailStr, Field, field_validator
from typing import Optional
import re

class UserCreate(BaseModel):
    name: str
    email: EmailStr
    age: Optional[int] = Field(None, gt=0)
    is_subscribed: Optional[bool] = None

class LoginData(BaseModel):
    username: str
    password: str

class CommonHeaders(BaseModel):
    user_agent: str = Field(alias="User-Agent")
    accept_language: str = Field(alias="Accept-Language")

    @field_validator("accept_language")
    @classmethod
    def validate_accept_language(cls, v: str) -> str:
        if not re.match(r"^[a-zA-Z0-9,\-;=. ]+$", v):
            raise ValueError("Invalid Accept-Language format")
        return v
