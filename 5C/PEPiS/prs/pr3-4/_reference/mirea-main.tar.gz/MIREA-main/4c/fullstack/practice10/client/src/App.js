import React, { useState, useEffect } from 'react';
import './App.css';
import { api } from './api';

function App() {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(false);
    const [newProduct, setNewProduct] = useState({
        title: '', price: '', category: '', description: ''
    });
    const [token, setToken] = useState(localStorage.getItem('accessToken') || null);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    useEffect(() => {
        if (token) {
            fetchProducts();
        }
    }, [token]);

    const handleRegister = async (e) => {
        e.preventDefault();
        try {
            await api.register(email, password);
            alert('Регистрация успешна! Теперь вы можете войти.');
        } catch (err) {
            console.error("Ошибка сети", err);
            alert('Ошибка регистрации');
        }
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            const data = await api.login(email, password);
            setToken(data.accessToken);
            localStorage.setItem('accessToken', data.accessToken);
            localStorage.setItem('refreshToken', data.refreshToken);
        } catch (err) {
            console.error("Ошибка сети", err);
            alert('Ошибка авторизации');
        }
    };

    const handleLogout = () => {
        setToken(null);
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
    };

    const fetchProducts = async () => {
        try {
            setLoading(true);
            const data = await api.getProducts();
            setProducts(data);
        } catch (err) {
            console.error("Ошибка загрузки", err);
            if (err.response && err.response.status === 401) {
                handleLogout();
            }
        } finally {
            setLoading(false);
        }
    };

    const handleCreate = async (e) => {
        e.preventDefault();
        try {
            await api.createProduct({ ...newProduct, price: Number(newProduct.price) });
            fetchProducts();
            setNewProduct({ title: '', price: '', category: '', description: '' });
        } catch (err) {
            console.error("Ошибка создания", err);
        }
    };

    const handleDelete = async (id) => {
        if (!window.confirm("Удалить товар?")) return;
        try {
            await api.deleteProduct(id);
            fetchProducts();
        } catch (err) {
            console.error("Ошибка удаления", err);
        }
    };

    const handleUpdate = async (id, updatedData) => {
        try {
            await api.updateProduct(id, updatedData);
            fetchProducts();
        } catch (err) {
            console.error("Ошибка обновления", err);
        }
    };

    if (!token) {
        return (
            <div className='App'>
                <header style={{ background: '#2c3e50', color: 'white', padding: '20px', textAlign: 'center' }}>
                    <h1>Авторизация</h1>
                </header>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', alignItems: 'center', marginTop: '50px' }}>
                    <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
                    <input type="password" placeholder="Пароль" value={password} onChange={e => setPassword(e.target.value)} />
                    <button onClick={handleLogin} className="btn">Войти</button>
                    <button onClick={handleRegister} className="btn">Зарегистрироваться</button>
                </div>
            </div>
        );
    }

    return (
        <div className='App'>
            <header style={{ background: '#2c3e50', color: 'white', padding: '20px', textAlign: 'center', position: 'relative' }}>
                <h1>Копеечка</h1>
                <button onClick={handleLogout} style={{ position: 'absolute', right: '20px', top: '20px' }}>Выход</button>
            </header>

            <div className='container'>
                <section className="admin-panel">
                    <h3>Новый товар</h3>
                    <form onSubmit={handleCreate} className="crud-form">
                        <input type="text" placeholder="Название" value={newProduct.title} onChange={e => setNewProduct({...newProduct, title: e.target.value})} required />
                        <input type="number" placeholder="Цена" value={newProduct.price} onChange={e => setNewProduct({...newProduct, price: e.target.value})} required />
                        <input type="text" placeholder="Категория" value={newProduct.category} onChange={e => setNewProduct({...newProduct, category: e.target.value})} required />
                        <input type="text" placeholder="Описание" value={newProduct.description} onChange={e => setNewProduct({...newProduct, description: e.target.value})} required />
                        <button type="submit" className="btn btn-add">Добавить</button>
                    </form>
                </section>

                {loading ? <p>Загрузка...</p> : (
                    <div className='products-grid'>
                        {products.map(product => (
                            <ProductCard 
                                key={product._id || product.id} 
                                product={product} 
                                onDelete={handleDelete} 
                                onUpdate={handleUpdate} 
                            />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

function ProductCard({ product, onDelete, onUpdate }) {
    const [isEditing, setIsEditing] = useState(false);
    const [editData, setEditData] = useState({ ...product });

    const saveEdit = () => {
        onUpdate(product._id || product.id, editData);
        setIsEditing(false);
    };

    return (
        <div className='product-card'>
            <div className='product-info' style={{ padding: '10px' }}>
                {isEditing ? (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                        <input value={editData.title || editData.name} onChange={e => setEditData({...editData, title: e.target.value})} placeholder="Название" />
                        <input type="number" value={editData.price} onChange={e => setEditData({...editData, price: Number(e.target.value)})} />
                        <input value={editData.category} onChange={e => setEditData({...editData, category: e.target.value})} />
                        <input value={editData.description} onChange={e => setEditData({...editData, description: e.target.value})} />
                        <button className="btn btn-add" onClick={saveEdit}>Сохранить</button>
                        <button className="btn" onClick={() => setIsEditing(false)}>Отмена</button>
                    </div>
                ) : (
                    <>
                        <small>{product.category}</small>
                        <h4>{product.title || product.name}</h4>
                        <p>{product.description}</p>
                        <p><strong>{product.price} руб.</strong></p>
                        <div className="card-actions">
                            <button className="btn btn-edit" onClick={() => setIsEditing(true)}>Изменить</button>
                            <button className="btn btn-delete" onClick={() => onDelete(product._id || product.id)}>Удалить</button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}

export default App;
