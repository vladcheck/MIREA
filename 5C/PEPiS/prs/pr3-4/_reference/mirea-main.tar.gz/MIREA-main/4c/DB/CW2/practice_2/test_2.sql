BEGIN;
DO $$
BEGIN
    RAISE NOTICE 'Тест 2.1: Проверка лимитов бонусов риэлтора (уведомление при > 500 000)...';

    RAISE NOTICE 'Шаг 1: Установка бонуса в пределах нормы (ожидаем отсутствие уведомлений)...';
    INSERT INTO realtor_bonus (realtor_id, bonus_amount) VALUES (1, 100000)
    ON CONFLICT (realtor_id) DO UPDATE SET bonus_amount = 100000;
    
    RAISE NOTICE 'Шаг 2: Установка бонуса выше лимита напрямую (ожидаем уведомление ВНИМАНИЕ)...';
    INSERT INTO realtor_bonus (realtor_id, bonus_amount) VALUES (2, 600000)
    ON CONFLICT (realtor_id) DO UPDATE SET bonus_amount = 600000;
    
    RAISE NOTICE 'Шаг 3: Превышение лимита бонуса через продажу огромного объекта...';
    
    INSERT INTO realtor (id, last_name, first_name, phone_number) 
    VALUES (3, 'Boss', 'Big', '12345678903') 
    ON CONFLICT (id) DO NOTHING;

    INSERT INTO property (id, district_id, address, floor, room_count, type_id, status, price, building_material_id, area, listing_date) 
    VALUES (103, 1, 'Address 103', 1, 2, 1, true, 12000000, 1, 100, CURRENT_DATE) 
    ON CONFLICT (id) DO NOTHING;

    INSERT INTO sale (property_id, sale_date, realtor_id, price)
    VALUES (103, CURRENT_DATE, 3, 12000000);

    RAISE NOTICE 'Тест успешно отработал! Ниже будет выведена таблица realtor_bonus:';
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'ОШИБКА: Тест упал при выполнении операций: %', SQLERRM;
END $$;

SELECT * FROM realtor_bonus WHERE realtor_id IN (1, 2, 3) ORDER BY realtor_id;

ROLLBACK;