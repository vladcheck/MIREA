import React from 'react';

const About = () => {
    return (
        <div>
            <h1>О нас</h1>
            <p>Это страница с информацией о нас. Она загружается лениво (lazy load).</p>
        </div>
    );
};

export default About;
