CREATE OR REPLACE FUNCTION check_sale_date_lyapunov()
    RETURNS TRIGGER AS
$$
DECLARE
    v_listing_date DATE;
BEGIN
    SELECT listing_date INTO v_listing_date FROM property WHERE id = NEW.property_id;
    IF NEW.sale_date < v_listing_date THEN
        RAISE NOTICE 'ВНИМАНИЕ: Дата продажи (%) раньше, чем дата размещения объявления (%).', NEW.sale_date, v_listing_date;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_check_sale_date ON sale;
CREATE TRIGGER trg_check_sale_date
    BEFORE INSERT OR UPDATE
    ON sale
    FOR EACH ROW
EXECUTE FUNCTION check_sale_date_lyapunov();