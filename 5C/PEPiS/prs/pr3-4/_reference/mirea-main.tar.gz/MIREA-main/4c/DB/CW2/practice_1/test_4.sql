BEGIN;
DO $$
BEGIN
    RAISE NOTICE 'Тест 4.1: Попытка продажи (sale_date) раньше, чем дата размещения объявления (listing_date)...';
    INSERT INTO sale (id, property_id, realtor_id, price, sale_date) VALUES (401, 2, 1, 5000000, '2023-01-15');
    
    RAISE NOTICE 'Тест 4.1 пройден: успешная вставка. Проверьте выше наличие предупреждения от триггера.';
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'ОШИБКА: Тест упал, хотя должен был только выдать предупреждение (NOTICE): %', SQLERRM;
END $$;
ROLLBACK;

BEGIN;
DO $$
BEGIN
    RAISE NOTICE 'Тест 4.2: Корректная продажа после даты размещения...';
    INSERT INTO sale (id, property_id, realtor_id, price, sale_date) VALUES (402, 2, 1, 5000000, '2023-03-01');
    
    RAISE NOTICE 'Тест 4.2 пройден: штатная продажа. Предупреждений быть не должно.';
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'ОШИБКА: Запрос завершился с ошибкой: %', SQLERRM;
END $$;
ROLLBACK;

BEGIN;
DO $$
BEGIN
    RAISE NOTICE 'Тест 4.3: Проверка обновления (UPDATE) даты продажи на некорректную...';
    INSERT INTO sale (id, property_id, realtor_id, price, sale_date) VALUES (403, 2, 1, 5000000, '2023-03-01');
    
    RAISE NOTICE 'Попытка обновления sale_date на 2023-01-10...';
    UPDATE sale SET sale_date = '2023-01-10' WHERE id = 403;
    
    RAISE NOTICE 'Тест 4.3 пройден: успешное обновление. Проверьте выше наличие предупреждения от триггера.';
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'ОШИБКА: Тест упал при обновлении: %', SQLERRM;
END $$;
ROLLBACK;