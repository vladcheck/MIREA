const mongoose = require('mongoose');

const uri = 'mongodb://YourMongoAdmin:1234@localhost:27017/mydatabase?authSource=admin';

mongoose.connect(uri)
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('Connection error:', err));

module.exports = mongoose;
