CREATE OR REPLACE FUNCTION check_duplicate_sale_lyapunov()
    RETURNS TRIGGER AS
$$
BEGIN
    IF EXISTS (SELECT 1 FROM sale WHERE property_id = NEW.property_id) THEN
        RAISE EXCEPTION 'ОШИБКА: Объект недвижимости с ID % уже был продан. Повторная продажа запрещена.', NEW.property_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_check_duplicate_sale ON sale;
CREATE TRIGGER trg_check_duplicate_sale
    BEFORE INSERT
    ON sale
    FOR EACH ROW
EXECUTE FUNCTION check_duplicate_sale_lyapunov();