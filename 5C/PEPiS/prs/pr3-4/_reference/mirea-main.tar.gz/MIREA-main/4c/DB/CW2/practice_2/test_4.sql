BEGIN;
DO $$
DECLARE
    v_phone_raw VARCHAR(20);
    v_phone_formatted VARCHAR(20);
    v_phone_short VARCHAR(20);
BEGIN
    RAISE NOTICE 'Тест 4.1: Проверка форматирования номера телефона риэлтора...';

    RAISE NOTICE 'Шаг 1: Добавление сырого номера (ожидаем форматирование)...';
    INSERT INTO realtor (last_name, first_name, phone_number) 
    VALUES ('Тестов', 'Тест', '79996667788')
    RETURNING phone_number INTO v_phone_raw;
    RAISE NOTICE 'Результат Шага 1: телефон сохранен как % (ожидается: +7 (999) 666 77 88)', v_phone_raw;

    RAISE NOTICE 'Шаг 2: Добавление отформатированного номера (ожидаем сохранение без изменений)...';
    INSERT INTO realtor (last_name, first_name, phone_number) 
    VALUES ('Тестов', 'Тест', '+7 (999) 666 77 88')
    RETURNING phone_number INTO v_phone_formatted;
    RAISE NOTICE 'Результат Шага 2: телефон сохранен как %', v_phone_formatted;

    RAISE NOTICE 'Шаг 3: Добавление короткого/некорректного номера (ожидаем сохранение без форматирования)...';
    INSERT INTO realtor (last_name, first_name, phone_number) 
    VALUES ('Тестов', 'Тест', '12345')
    RETURNING phone_number INTO v_phone_short;
    RAISE NOTICE 'Результат Шага 3: телефон сохранен как %', v_phone_short;

    RAISE NOTICE 'Тест успешно отработал!';
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'ОШИБКА: Тест упал при выполнении операций: %', SQLERRM;
END $$;
ROLLBACK;