const express = require('express');
const router = express.Router();
const authMiddleware = require('../middlewares/auth');
const rolesMiddleware = require('../middlewares/roles');





module.exports = (users) => {
    
    router.get('/', authMiddleware, rolesMiddleware(['admin']), (req, res) => {
        const usersList = users.map(({ password, ...u }) => u);
        res.json(usersList);
    });

    
    router.get('/:id', authMiddleware, rolesMiddleware(['admin']), (req, res) => {
        const user = users.find(u => u._id === req.params.id);
        if (!user) return res.status(404).json({ message: 'Пользователь не найден' });
        const { password, ...userWithoutPassword } = user;
        res.json(userWithoutPassword);
    });

    
    router.put('/:id', authMiddleware, rolesMiddleware(['admin']), async (req, res) => {
        const index = users.findIndex(u => u._id === req.params.id);
        if (index === -1) return res.status(404).json({ message: 'Пользователь не найден' });
        
        const { email, role } = req.body;
        users[index] = { ...users[index], email: email || users[index].email, role: role || users[index].role };
        
        const { password, ...updatedUser } = users[index];
        res.json(updatedUser);
    });

    
    router.delete('/:id', authMiddleware, rolesMiddleware(['admin']), (req, res) => {
        const index = users.findIndex(u => u._id === req.params.id);
        if (index === -1) return res.status(404).json({ message: 'Пользователь не найден' });
        
        users.splice(index, 1);
        res.json({ message: 'Пользователь удален/заблокирован' });
    });

    return router;
};