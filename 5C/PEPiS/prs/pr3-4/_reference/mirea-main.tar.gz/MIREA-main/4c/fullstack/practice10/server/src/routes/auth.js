const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const authMiddleware = require('../middlewares/auth');

const users = [];

const generateTokens = (userId) => {
    const accessToken = jwt.sign({ id: userId }, process.env.JWT_ACCESS_SECRET || 'secret_access', { expiresIn: '15m' });
    const refreshToken = jwt.sign({ id: userId }, process.env.JWT_REFRESH_SECRET || 'secret_refresh', { expiresIn: '7d' });
    return { accessToken, refreshToken };
};

router.post('/register', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        const candidate = users.find(u => u.email === email);
        if (candidate) {
            return res.status(400).json({ message: 'Пользователь с таким email уже существует' });
        }
        
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = {
            _id: Date.now().toString(), 
            email,
            password: hashedPassword
        };
        
        users.push(newUser);
        res.status(201).json({ message: 'Пользователь успешно создан' });
    } catch (e) {
        console.error('Registration error:', e);
        res.status(500).json({ message: 'Ошибка при регистрации: ' + e.message });
    }
});

router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        const user = users.find(u => u.email === email);
        if (!user) {
            return res.status(400).json({ message: 'Пользователь не найден' });
        }
        
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Неверный пароль' });
        }
        
        const tokens = generateTokens(user._id);
        res.json(tokens);
    } catch (e) {
        res.status(500).json({ message: 'Ошибка при входе' });
    }
});

router.post('/refresh', async (req, res) => {
    try {
        const { token } = req.body;
        if (!token) {
            return res.status(401).json({ message: 'Токен не предоставлен' });
        }

        const decoded = jwt.verify(token, process.env.JWT_REFRESH_SECRET || 'secret_refresh');
        
        const user = users.find(u => u._id === decoded.id);
        if (!user) {
            return res.status(401).json({ message: 'Пользователь не найден' });
        }

        const tokens = generateTokens(user._id);
        res.json({ ...tokens, refresh_expired: false });
    } catch (e) {
        res.status(401).json({ refresh_expired: true, message: 'Неверный refresh токен' });
    }
});

router.get('/me', authMiddleware, async (req, res) => {
    try {
        const user = users.find(u => u._id === req.user.id);
        if (!user) {
             return res.status(404).json({ message: 'Пользователь не найден' });
        }
        
        const { password, ...userWithoutPassword } = user;
        res.json(userWithoutPassword);
    } catch (e) {
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

module.exports = router;