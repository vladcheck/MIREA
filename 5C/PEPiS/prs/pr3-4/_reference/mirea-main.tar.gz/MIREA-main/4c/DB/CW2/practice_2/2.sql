CREATE OR REPLACE FUNCTION check_bonus_limit_lyapunov()
    RETURNS TRIGGER AS
$$
DECLARE
    v_max_bonus NUMERIC := 500000;
BEGIN
    IF NEW.bonus_amount > v_max_bonus THEN
        RAISE NOTICE 'ВНИМАНИЕ: Накопленный бонус риэлтора (ID: %) составляет %, что превышает установленный лимит в % !', NEW.realtor_id, NEW.bonus_amount, v_max_bonus;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_check_bonus_limit ON realtor_bonus;
CREATE TRIGGER trg_check_bonus_limit
    AFTER INSERT OR UPDATE
    ON realtor_bonus
    FOR EACH ROW
EXECUTE FUNCTION check_bonus_limit_lyapunov();
