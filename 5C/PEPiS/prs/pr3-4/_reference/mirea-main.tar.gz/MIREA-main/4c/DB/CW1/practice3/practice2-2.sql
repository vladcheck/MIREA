CREATE OR REPLACE FUNCTION categorize_order_lyapunov(order_amount DECIMAL(10, 2))
    RETURNS TEXT AS
$$
BEGIN
    RETURN CASE
               WHEN order_amount < 0 THEN 'ОШИБКА: ОТРИЦАТЕЛЬНАЯ СУММА'
               WHEN order_amount < 1000 THEN 'МАЛЫЙ'
               WHEN order_amount < 5000 THEN 'СРЕДНИЙ'
               WHEN order_amount < 20000 THEN 'КРУПНЫЙ'
               ELSE 'ОСОБО КРУПНЫЙ'
        END;
END;
$$ LANGUAGE plpgsql;