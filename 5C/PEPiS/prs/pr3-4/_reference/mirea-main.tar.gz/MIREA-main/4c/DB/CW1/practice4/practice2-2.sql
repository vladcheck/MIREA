CREATE OR REPLACE FUNCTION calculate_working_hours_per_week_lyapunov(starting_date date)
    RETURNS TABLE
            (
                amount     integer,
                commentary text
            )
    LANGUAGE plpgsql
AS
$$
BEGIN
    RETURN QUERY
        WITH weekly_events AS (SELECT *
                               FROM work_day_lyapunov
                               WHERE gate_log >= starting_date
                                 AND gate_log < starting_date + interval '7 days'),
             ordered_events AS (SELECT employee_id,
                                       gate_log,
                                       card_reader_value,
                                       LAG(gate_log)
                                       OVER (PARTITION BY employee_id, gate_log::date ORDER BY gate_log) AS prev_time,
                                       LAG(card_reader_value)
                                       OVER (PARTITION BY employee_id, gate_log::date ORDER BY gate_log) AS prev_type
                                FROM weekly_events),
             work_intervals AS (SELECT employee_id,
                                       EXTRACT(EPOCH FROM (gate_log - prev_time)) AS seconds
                                FROM ordered_events
                                WHERE card_reader_value = 2
                                  AND prev_type = 1),
             total_seconds_per_employee AS (SELECT employee_id,
                                                   COALESCE(SUM(seconds), 0) AS total_seconds
                                            FROM work_intervals
                                            GROUP BY employee_id)
        SELECT ROUND(total_seconds / 3600.0)::integer AS amount,
               'Сотрудник ' || employee_id || ': ' ||
               CASE
                   WHEN ROUND(total_seconds / 3600.0) < 40 THEN 'Меньше нормы'
                   WHEN ROUND(total_seconds / 3600.0) = 40 THEN 'Норма'
                   ELSE 'Больше нормы'
                   END                                AS commentary
        FROM total_seconds_per_employee
        ORDER BY employee_id;
END;
$$;
