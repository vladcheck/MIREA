import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.storage import storage

@pytest.fixture
def client():
    storage.drop()
    return TestClient(app)

def test_users_me(client):
    response = client.get("/users/me", headers={"X-User-Id": "10", "X-User-Role": "admin"})
    assert response.status_code == 200
    assert response.json() == {"id": 10, "role": "admin"}

def test_unauthorized_user(client):
    response = client.get("/users/me")
    assert response.status_code == 401
    
def test_get_user(client):
    response = client.get("/users/42", headers={"X-User-Id": "10"})
    assert response.status_code == 200
    assert response.json() == {"id": 42, "role": "user"}

def test_unauthorized_bad_user_id(client):
    response = client.get("/users/me", headers={"X-User-Id": "not_an_int"})
    assert response.status_code == 401

def test_user_cannot_access_admin_stats(client):
    response = client.get("/admin/stats", headers={"X-User-Id": "10", "X-User-Role": "user"})
    assert response.status_code == 403

def test_admin_can_access_stats(client):
    client.post(
        "/tasks",
        headers={"X-User-Id": "10"},
        json={"title": "Task 1", "status": "todo", "priority": 1}
    )
    client.post(
        "/tasks",
        headers={"X-User-Id": "10"},
        json={"title": "Task 2", "status": "in_progress", "priority": 1}
    )
    response = client.get("/admin/stats", headers={"X-User-Id": "10", "X-User-Role": "admin"})
    assert response.status_code == 200
    data = response.json()
    assert data["total_tasks"] == 2
    assert data["by_status"]["todo"] == 1
    assert data["by_status"]["in_progress"] == 1

def test_admin_cannot_delete_nonexistent_task(client):
    response = client.delete("/admin/tasks/999", headers={"X-User-Id": "99", "X-User-Role": "admin"})
    assert response.status_code == 404

def test_user_cannot_delete_other_user_task(client):
    client.post(
        "/tasks",
        headers={"X-User-Id": "20"},
        json={"title": "Задача", "status": "todo", "priority": 1}
    )
    
    response = client.delete("/tasks/1", headers={"X-User-Id": "10"})
    assert response.status_code == 404

def test_admin_can_delete_other_user_task(client):
    client.post(
        "/tasks",
        headers={"X-User-Id": "20"},
        json={"title": "Задача", "status": "todo", "priority": 1}
    )
    
    response = client.delete("/admin/tasks/1", headers={"X-User-Id": "99", "X-User-Role": "admin"})
    assert response.status_code == 204
    
    # Verify it's gone
    assert len(storage.tasks) == 0