# E-commerce API

## Запуск

### Бекенд

```bash
cd client/server 
pnpm install
node server.js
```
После этого в консоли будет указано, что сервер запущен. API будет доступно по порту **5001**.

### Фронтенд

```bash
cd practice11/client 
pnpm install
pnpm run dev
```
Клиентское приложение на базе Vite + React будет доступно по порту **5173** (`http://localhost:5173`).

---

## Маршруты

### Клиент

| Маршрут | Пояснение |
| --- | --- |
| `/` | Главная страница (отображается список товаров) |
| `/register` | Страница регистрации |
| `/login` | Страница авторизации (логин) |
| `*` | Страница 404 (любые другие ненайденные маршруты ведут сюда) |

### Сервер

| Маршрут | Метод | Нужна авторизация? | Разрешенные роли |
| --- | --- | --- | --- |
| `/api/products` | GET | Нет | Все |
| `/api/products/:id` | GET | Нет | Все |
| `/api/products` | POST | Да | admin, seller |
| `/api/products/:id` | PUT | Да | admin, seller |
| `/api/products/:id` | DELETE | Да | admin, seller |
| `/api/auth/register` | POST | Нет | Все |
| `/api/auth/login` | POST | Нет | Все |
| `/api/auth/refresh` | POST | Да | Все |
| `/api/auth/me` | GET | Да | Все |
