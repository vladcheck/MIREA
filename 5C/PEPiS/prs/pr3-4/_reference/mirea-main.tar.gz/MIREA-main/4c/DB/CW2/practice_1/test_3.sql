BEGIN;
DO $$
BEGIN
    RAISE NOTICE 'Тест 3.1: Попытка добавить комнату, площадь которой превышает общую площадь объекта (60 кв.м > 50 кв.м)...';
    
    INSERT INTO property_structure (id, property_id, room_name, room_area) VALUES (301, 2, 'Комната 1', 60);
    
    RAISE NOTICE 'ОШИБКА ТЕСТА: Добавление разрешено, триггер не сработал.';
EXCEPTION 
    WHEN OTHERS THEN
        RAISE NOTICE 'Тест 3.1 пройден: добавление комнаты заблокировано триггером.';
        RAISE NOTICE 'Сообщение СУБД: %', SQLERRM;
END $$;
ROLLBACK;

BEGIN;
DO $$
BEGIN
    RAISE NOTICE 'Тест 3.2: Проверка накопительного ограничения (лимит = 50 кв.м)';
    RAISE NOTICE 'Шаг 1: Добавление первой комнаты (20 кв.м)...';
    INSERT INTO property_structure (id, property_id, room_name, room_area) VALUES (302, 2, 'Комната 1', 20);
    
    RAISE NOTICE 'Шаг 2: Добавление второй комнаты (30 кв.м). Текущая сумма: 50 кв.м...';
    INSERT INTO property_structure (id, property_id, room_name, room_area) VALUES (303, 2, 'Комната 2', 30);
    
    RAISE NOTICE 'Шаг 3: Попытка превысить лимит добавлением третьей комнаты (5 кв.м)...';
    INSERT INTO property_structure (id, property_id, room_name, room_area) VALUES (304, 2, 'Комната 3', 5);
    
    RAISE NOTICE 'ОШИБКА ТЕСТА: Добавление третьей комнаты разрешено, накопительный триггер не сработал.';
EXCEPTION 
    WHEN OTHERS THEN
        RAISE NOTICE 'Тест 3.2 пройден: добавление третьей комнаты отклонено (сумма площадей превышает общую).';
        RAISE NOTICE 'Сообщение СУБД: %', SQLERRM;
END $$;
ROLLBACK;