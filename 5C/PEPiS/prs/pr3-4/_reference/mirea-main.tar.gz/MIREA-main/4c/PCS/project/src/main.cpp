#include <iostream>
#include <string>
#include <getopt.h>
#include <random>
#include "../include/maze_facade.h"
#include "../include/dfs_generator.h"
#include "../include/kruskal_generator.h"
#include "../include/prim_generator.h"
#include "../include/maze_exporter.h"
#include "../include/pathfinder.h"
#include "../include/exceptions.h"
#include <stdexcept>
void printUsage() {
    std::cout << "Usage: maze_generator -w <width> -h <height> -a <algorithm> -f <format> [-s <seed>]\n";
    std::cout << "Algorithms: dfs, kruskal, prim\n";
    std::cout << "Formats: ascii, json, png\n";
}
int main(int argc, char* argv[]) {
    int width = 10;
    int height = 10;
    std::string algorithm = "dfs";
    std::string format = "ascii";
    uint32_t seed = std::random_device{}();
    int opt;
    while ((opt = getopt(argc, argv, "w:h:a:f:s:")) != -1) {
        switch (opt) {
            case 'w': width = std::stoi(optarg); break;
            case 'h': height = std::stoi(optarg); break;
            case 'a': algorithm = optarg; break;
            case 'f': format = optarg; break;
            case 's': seed = std::stoul(optarg); break;
            default: printUsage(); return 1;
        }
    }
    MazeFacade facade;
    if (algorithm == "dfs") {
        facade.setGenerator(std::make_unique<DfsGenerator>());
    } else if (algorithm == "kruskal") {
        facade.setGenerator(std::make_unique<KruskalGenerator>());
    } else if (algorithm == "prim") {
        facade.setGenerator(std::make_unique<PrimGenerator>());
    } else {
        std::cerr << "Unknown algorithm: " << algorithm << "\n";
        printUsage();
        return 1;
    }
    try {
        MazeContext context(width, height, seed);
        facade.run(context);
        std::cout << "Generated Maze (" << width << "x" << height << ", seed: " << seed << ", algorithm: " << algorithm << "):\n";        
        Pathfinder pathfinder;
        Point start = {0, 0};
        Point end = {width - 1, height - 1};
        auto path = pathfinder.findPath(context, start, end);
        std::unique_ptr<IMazeExporter> exporter;
        if (format == "json") {
            exporter = std::make_unique<JsonExporter>();
        } else if (format == "png") {
            exporter = std::make_unique<PngExporter>();
        } else {
            exporter = std::make_unique<AsciiExporter>();
        }
        if (format == "png") {
            std::cout << exporter->exportMaze(context, path) << "\n";
        } else {
            std::cout << exporter->exportMaze(context, path);
        }
        if (!path.empty()) {
            std::cout << "\nPath from (" << start.x << "," << start.y << ") to (" << end.x << "," << end.y << "): ";
            for (const auto& p : path) {
                std::cout << "(" << p.x << "," << p.y << ") ";
            }
            std::cout << "\n";
        } else {
            std::cout << "\nNo path found.\n";
        }    } catch (const std::invalid_argument& e) {
        std::cerr << "Invalid argument error: " << e.what() << "\n";
        return 1;
    } catch (const MazeBoundsException& e) {
        std::cerr << "Bounds error: " << e.what() << "\n";
        return 1;
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
