import express from 'express';
import amqplib from 'amqplib';
import { setupQueues } from './setup.js';

const app = express();
app.use(express.json());

let channel;

async function initRabbitMQ() {
    await setupQueues();
    const connection = await amqplib.connect('amqp://localhost');
    channel = await connection.createChannel();
}

app.post('/tasks', async (req, res) => {
    const { type, payload } = req.body;
    
    if (!type || !payload) {
        return res.status(400).json({ error: 'type and payload are required' });
    }
    
    const task = { id: Date.now().toString(), type, payload };
    
    channel.sendToQueue('task_queue', Buffer.from(JSON.stringify(task)), {
        persistent: true,
        headers: { 'x-retry-count': 0 }
    });
    
    console.log(`[Producer] Отправлена задача:`, task);
    res.json({ message: 'Task queued', task });
});

const PORT = 3000;
initRabbitMQ().then(() => {
    app.listen(PORT, () => {
        console.log(`API Server listening on port ${PORT}`);
    });
}).catch(console.error);
