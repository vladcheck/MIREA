#pragma once
#include "i_maze_generator.h"
class DfsGenerator : public IMazeGenerator {
public:
    void generate(GridNode node, MazeContext& ctx) override;
};
