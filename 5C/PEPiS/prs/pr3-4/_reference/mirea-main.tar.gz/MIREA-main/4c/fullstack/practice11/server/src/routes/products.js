const express = require('express');
const router = express.Router();
const authMiddleware = require('../middlewares/auth');
const rolesMiddleware = require('../middlewares/roles');

const products = [];


router.get('/', authMiddleware, (req, res) => {
    try {
        res.json(products);
    } catch (e) {
        res.status(500).json({ message: 'Ошибка получения товаров' });
    }
});


router.get('/:id', authMiddleware, (req, res) => {
    try {
        const product = products.find(p => p._id === req.params.id);
        if (!product) return res.status(404).json({ message: 'Товар не найден' });
        res.json(product);
    } catch (e) {
        res.status(500).json({ message: 'Ошибка получения товара' });
    }
});


router.post('/', authMiddleware, rolesMiddleware(['seller', 'admin']), (req, res) => {
    try {
        const { name, description, price } = req.body;
        const newProduct = {
            _id: Date.now().toString(),
            name,
            description,
            price
        };
        products.push(newProduct);
        res.status(201).json(newProduct);
    } catch (e) {
        res.status(500).json({ message: 'Ошибка создания товара' });
    }
});


router.put('/:id', authMiddleware, rolesMiddleware(['seller', 'admin']), (req, res) => {
    try {
        const index = products.findIndex(p => p._id === req.params.id);
        if (index === -1) return res.status(404).json({ message: 'Товар не найден' });
        
        const updatedProduct = {
            ...products[index],
            ...req.body,
            _id: products[index]._id
        };
        
        products[index] = updatedProduct;
        res.json(updatedProduct);
    } catch (e) {
        res.status(500).json({ message: 'Ошибка обновления товара' });
    }
});


router.delete('/:id', authMiddleware, rolesMiddleware(['admin']), (req, res) => {
    try {
        const index = products.findIndex(p => p._id === req.params.id);
        if (index === -1) return res.status(404).json({ message: 'Товар не найден' });
        
        products.splice(index, 1);
        res.json({ message: 'Товар удален' });
    } catch (e) {
        res.status(500).json({ message: 'Ошибка удаления товара' });
    }
});

module.exports = router;