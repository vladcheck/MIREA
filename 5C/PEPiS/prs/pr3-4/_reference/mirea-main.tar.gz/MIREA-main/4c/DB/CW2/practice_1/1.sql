CREATE OR REPLACE FUNCTION check_price_difference_lyapunov()
RETURNS TRIGGER AS $$
DECLARE
    v_declared_price NUMERIC;
    v_difference NUMERIC;
BEGIN
    SELECT price INTO v_declared_price FROM property WHERE id = NEW.property_id;
    IF v_declared_price IS NOT NULL AND NEW.price > 0 THEN
        v_difference := ABS(v_declared_price - NEW.price) / v_declared_price * 100;
        IF v_difference > 20 THEN
            RAISE NOTICE 'ВНИМАНИЕ: Разница между заявленной стоимостью (%) и продажной (%) составляет % %%, что больше 20%%', v_declared_price, NEW.price, ROUND(v_difference, 2);
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_check_price_difference ON sale;
CREATE TRIGGER trg_check_price_difference
BEFORE INSERT ON sale
FOR EACH ROW
EXECUTE FUNCTION check_price_difference_lyapunov();