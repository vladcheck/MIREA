const express = require('express');
const bcrypt = require('bcrypt');
const crypto = require('crypto');

const app = express();
const port = 3000;

let users = [];
let products = [];

app.use(express.json());


app.post('/api/auth/register', async (req, res) => {
    const { email, first_name, last_name, password } = req.body;

    if (!email || !first_name || !last_name || !password) {
        return res.status(400).json({ error: 'Все поля (email, first_name, last_name, password) обязательны' });
    }

    const existingUser = users.find(u => u.email === email);
    if (existingUser) {
        return res.status(400).json({ error: 'Пользователь с таким email уже существует' });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        
        const newUser = {
            id: crypto.randomUUID(),
            email,
            first_name,
            last_name,
            password: hashedPassword
        };

        users.push(newUser);

        res.status(201).json({
            id: newUser.id,
            email: newUser.email,
            first_name: newUser.first_name,
            last_name: newUser.last_name
        });
    } catch (error) {
        res.status(500).json({ error: 'Ошибка сервера при регистрации' });
    }
});

app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: 'Обязательно укажите email и пароль' });
    }

    const user = users.find(u => u.email === email);
    
    if (!user) {
        return res.status(404).json({ error: 'Пользователь не найден' });
    }

    try {
        const isAuthenticated = await bcrypt.compare(password, user.password);
        
        if (isAuthenticated) {
            res.status(200).json({ login: true, message: 'Вход выполнен успешно' });
        } else {
            res.status(401).json({ error: 'Неверный пароль' });
        }
    } catch (error) {
        res.status(500).json({ error: 'Ошибка сервера при авторизации' });
    }
});


app.post('/api/products', (req, res) => {
    const { title, category, description, price } = req.body;

    if (!title || !category || !description || price === undefined) {
        return res.status(400).json({ error: 'Поля (title, category, description, price) обязательны' });
    }

    const newProduct = {
        id: crypto.randomUUID(),
        title,
        category,
        description,
        price: Number(price)
    };

    products.push(newProduct);
    res.status(201).json(newProduct);
});

app.get('/api/products', (req, res) => {
    res.status(200).json(products);
});

app.get('/api/products/:id', (req, res) => {
    const { id } = req.params;
    const product = products.find(p => p.id === id);

    if (!product) {
        return res.status(404).json({ error: 'Товар не найден' });
    }

    res.status(200).json(product);
});

app.put('/api/products/:id', (req, res) => {
    const { id } = req.params;
    const { title, category, description, price } = req.body;

    const index = products.findIndex(p => p.id === id);
    if (index === -1) {
        return res.status(404).json({ error: 'Товар не найден' });
    }

    if (title !== undefined) products[index].title = title;
    if (category !== undefined) products[index].category = category;
    if (description !== undefined) products[index].description = description;
    if (price !== undefined) products[index].price = Number(price);

    res.status(200).json(products[index]);
});

app.delete('/api/products/:id', (req, res) => {
    const { id } = req.params;
    const index = products.findIndex(p => p.id === id);

    if (index === -1) {
        return res.status(404).json({ error: 'Товар не найден' });
    }

    products.splice(index, 1);
    res.status(200).json({ message: 'Товар успешно удален', success: true });
});

app.listen(port, () => {
    console.log(`Сервер запущен на http://localhost:${port}`);
});
