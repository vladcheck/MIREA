#include "../include/maze_facade.h"
void MazeFacade::setGenerator(std::unique_ptr<IMazeGenerator> gen) {
    generator = std::move(gen);
}
void MazeFacade::addRule(std::unique_ptr<IMazeGenerator> rule) {
    rules.push_back(std::move(rule));
}
void MazeFacade::run(MazeContext& context) {
    generate({0, 0}, context);
}
void MazeFacade::generate(GridNode node, MazeContext& ctx) {
    if (generator) {
        generator->generate(node, ctx);
    }
    for (const auto& rule : rules) {
        rule->generate(node, ctx);
    }
}
