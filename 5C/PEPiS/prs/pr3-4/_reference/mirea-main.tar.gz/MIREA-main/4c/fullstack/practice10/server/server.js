const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

app.use(cors());
app.use(express.json());

const authRoutes = require('./src/routes/auth');
const productRoutes = require('./src/routes/products');

app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);

const PORT = 5001;

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT} (Using in-memory storage)`);
});