#include "../include/grid.h"
#include "../include/exceptions.h"
#include <stdexcept>
Grid::Grid(int width, int height) : width(width), height(height) {
    if (width <= 0 || height <= 0) {
        throw std::invalid_argument("Grid dimensions must be positive");
    }
    cells.reserve(width * height);
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            CellData cell;
            cell.x = x;
            cell.y = y;
            cells.push_back(cell);
        }
    }
}
CellData& Grid::getCell(int x, int y) {
    if (!isValid(x, y)) {
        throw MazeBoundsException("Grid coordinates out of bounds");
    }
    return cells[y * width + x];
}
const CellData& Grid::getCell(int x, int y) const {
    if (!isValid(x, y)) {
        throw MazeBoundsException("Grid coordinates out of bounds");
    }
    return cells[y * width + x];
}
bool Grid::isValid(int x, int y) const {
    return x >= 0 && x < width && y >= 0 && y < height;
}
