CREATE TABLE IF NOT EXISTS property_structure (
    id SERIAL PRIMARY KEY,
    property_id INTEGER NOT NULL REFERENCES property(id),
    room_name VARCHAR(100),
    room_area NUMERIC
);
CREATE TABLE IF NOT EXISTS journal (
    id SERIAL PRIMARY KEY,
    operation_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    operation VARCHAR(10) NOT NULL,
    username VARCHAR(255) NOT NULL
);\n

