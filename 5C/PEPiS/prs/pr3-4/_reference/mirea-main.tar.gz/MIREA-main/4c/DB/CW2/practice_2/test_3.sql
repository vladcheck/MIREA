BEGIN;
DO $$
BEGIN
    RAISE NOTICE 'Тест 3.1: Проверка валидации паспортных данных риэлтора...';

    RAISE NOTICE 'Шаг 1: Добавление корректных паспортных данных (ожидаем успех)...';
    INSERT INTO realtor (last_name, first_name, phone_number, passport_data) 
    VALUES ('Тестов', 'Тест', '79991112233', '1234 567890');

    RAISE NOTICE 'Шаг 2: Добавление NULL вместо паспорта (ожидаем успех, так как это допустимо)...';
    INSERT INTO realtor (last_name, first_name, phone_number, passport_data) 
    VALUES ('Тестов', 'Тест', '79991112233', NULL);

    RAISE NOTICE 'Шаг 3: Добавление паспорта без пробела (ожидаем ошибку)...';
    BEGIN
        INSERT INTO realtor (last_name, first_name, phone_number, passport_data) 
        VALUES ('Тестов', 'Тест', '79991112233', '1234567890');
    EXCEPTION WHEN OTHERS THEN
        RAISE NOTICE 'Успешный перехват: %', SQLERRM;
    END;

    RAISE NOTICE 'Шаг 4: Добавление паспорта с буквами (ожидаем ошибку)...';
    BEGIN
        INSERT INTO realtor (last_name, first_name, phone_number, passport_data) 
        VALUES ('Тестов', 'Тест', '79991112233', '12AB 567890');
    EXCEPTION WHEN OTHERS THEN
        RAISE NOTICE 'Успешный перехват: %', SQLERRM;
    END;

    RAISE NOTICE 'Тест успешно отработал!';
END $$;
ROLLBACK;