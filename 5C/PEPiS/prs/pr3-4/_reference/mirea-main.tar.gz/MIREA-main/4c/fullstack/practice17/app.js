const contentDiv = document.getElementById('app-content');
const homeBtn = document.getElementById('home-btn');
const aboutBtn = document.getElementById('about-btn');
const socket = io(window.location.origin);
function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding).replace(/\-/g, '+').replace(/_/g, '/');
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
        outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
}
async function saveSubscriptionToServer(subscription) {
    const res = await fetch('/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(subscription)
    });
    if (!res.ok) {
        throw new Error(`Server responded with ${res.status}`);
    }
    console.log('Подписка на push отправлена');
}

async function subscribeToPush() {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;
    try {
        const registration = await navigator.serviceWorker.ready;
        const subscription = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array('BDqohPmAlopaR4fyICK7kQ4IyCqxoqKy5uPCSr20eL95QjnxKtJIHNld2iwBZmvNe5QNsLDwfM5XQlFX8AQbzjo')
        });
        await saveSubscriptionToServer(subscription);
    } catch (err) {
        console.error('Ошибка подписки на push:', err);
    }
}
async function unsubscribeFromPush() {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;
    const registration = await navigator.serviceWorker.ready;
    const subscription = await registration.pushManager.getSubscription();
    if (subscription) {
        await fetch('/unsubscribe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ endpoint: subscription.endpoint })
        });
        await subscription.unsubscribe();
        console.log('Отписка выполнена');
    }
}
socket.on('connect', () => {
    console.log('Socket подключён, id:', socket.id);
});
socket.on('connect_error', (err) => {
    console.error('Socket ошибка подключения:', err.message);
});
socket.on('taskAdded', (task) => {
    console.log('Задача от другого клиента:', task);
    const notification = document.createElement('div');
    notification.textContent = `Новая задача: ${task.text}`;
    notification.style.cssText = `
        position: fixed; top: 10px; right: 10px;
        background: #4285f4; color: white; padding: 1rem;
        border-radius: 5px; z-index: 1000;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    `;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
    const notes = JSON.parse(localStorage.getItem('notes') || '[]');
    const alreadyExists = notes.find(n => {
        const text = typeof n === 'string' ? n : n.text;
        return text === task.text;
    });
    if (!alreadyExists) {
        notes.push({ id: task.id || Date.now(), text: task.text, reminder: null });
        localStorage.setItem('notes', JSON.stringify(notes));
    }
    renderNotesList();
});
function renderNotesList() {
    const list = document.getElementById('notes-list');
    if (!list) return;
    
    let rawNotes = JSON.parse(localStorage.getItem('notes') || '[]');
    let needsSave = false;
    let notes = rawNotes.map((note, index) => {
        if (typeof note === 'string') {
            needsSave = true;
            return { id: Date.now() + index, text: note, completed: false, reminder: null };
        }
        if (!note.id) {
            needsSave = true;
            note.id = Date.now() + index;
        }
        return note;
    });
    if (needsSave) {
        localStorage.setItem('notes', JSON.stringify(notes));
    }
    
    if (notes.length === 0) {
        list.innerHTML = `<li class="is-center text-grey" style="padding: 2rem; color: #888;">Заметок пока нет. Добавьте первую!</li>`;
        return;
    }

    list.innerHTML = notes.map(noteObj => {
        let reminderInfo = '';
        if (noteObj.reminder) {
            const date = new Date(noteObj.reminder);
            reminderInfo = `<br><small>Напоминание: ${date.toLocaleString()}</small>`;
        }
        
        const checked = noteObj.completed ? 'checked' : '';
        const textStyle = noteObj.completed ? 'text-decoration: line-through; opacity: 0.6;' : '';

        return `<li class="card" style="margin-bottom: 0.5rem; padding: 0.5rem; display: flex; justify-content: space-between; align-items: center;">
                    <div style="flex-grow: 1; ${textStyle}">
                        <input type="checkbox" ${checked} onchange="window.toggleNoteCompletion('${noteObj.id}')" style="margin-right: 10px; cursor: pointer; transform: scale(1.2);">
                        ${noteObj.text} ${reminderInfo}
                    </div>
                    <button class="button error" onclick="window.deleteNote('${noteObj.id}')" style="background-color: #ff4d4f !important; color: white !important; border: none; padding: 0.2rem 0.5rem; margin-left: 10px; min-height: unset; opacity: 1 !important;">Удалить</button>
                </li>`;
    }).join('');
}

window.toggleNoteCompletion = (id) => {
    let notes = JSON.parse(localStorage.getItem('notes') || '[]');
    const note = notes.find(n => String(n.id) === String(id));
    if (note) {
        note.completed = !note.completed;
        localStorage.setItem('notes', JSON.stringify(notes));
        renderNotesList();
        socket.emit('toggleTask', { id: note.id, completed: note.completed });
    }
};

window.deleteNote = (id) => {
    let notes = JSON.parse(localStorage.getItem('notes') || '[]');
    notes = notes.filter(n => String(n.id) !== String(id));
    localStorage.setItem('notes', JSON.stringify(notes));
    renderNotesList();
    socket.emit('deleteTask', { id });
};

socket.on('taskToggled', (data) => {
    let notes = JSON.parse(localStorage.getItem('notes') || '[]');
    const note = notes.find(n => String(n.id) === String(data.id));
    if (note) {
        note.completed = data.completed;
        localStorage.setItem('notes', JSON.stringify(notes));
        renderNotesList();
    }
});

socket.on('taskDeleted', (data) => {
    let notes = JSON.parse(localStorage.getItem('notes') || '[]');
    notes = notes.filter(n => String(n.id) !== String(data.id));
    localStorage.setItem('notes', JSON.stringify(notes));
    renderNotesList();
});

function setActiveButton(activeId) {
    [homeBtn, aboutBtn].forEach(btn => btn.classList.remove('active'));
    document.getElementById(activeId).classList.add('active');
}
async function loadContent(page) {
    try {
        const response = await fetch(`/content/${page}.html`);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const html = await response.text();
        contentDiv.innerHTML = html;
        if (page === 'home') {
            initNotes();
        }
    } catch (err) {
        contentDiv.innerHTML = `<p class="is-center text-error">Ошибка загрузки страницы: ${err.message}</p>`;
        console.error('loadContent error:', err);
    }
}
homeBtn.setAttribute('aria-label', 'Главная страница');
aboutBtn.setAttribute('aria-label', 'О приложении');

homeBtn.addEventListener('click', () => {
    setActiveButton('home-btn');
    loadContent('home');
});
aboutBtn.addEventListener('click', () => {
    setActiveButton('about-btn');
    loadContent('about');
});
loadContent('home');
function initNotes() {
    const form = document.getElementById('note-form');
    const input = document.getElementById('note-input');
    const reminderForm = document.getElementById('reminder-form');
    const reminderText = document.getElementById('reminder-text');
    const reminderTime = document.getElementById('reminder-time');
    function addNote(text, reminderTimestamp = null) {
        const notes = JSON.parse(localStorage.getItem('notes') || '[]');
        const newNote = { id: Date.now(), text, reminder: reminderTimestamp };
        notes.push(newNote);
        localStorage.setItem('notes', JSON.stringify(notes));
        renderNotesList();
        if (reminderTimestamp) {
            socket.emit('newReminder', {
                id: newNote.id,
                text: text,
                reminderTime: reminderTimestamp
            });
        } else {
            socket.emit('newTask', { id: newNote.id, text, timestamp: Date.now() });
        }
    }
    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const text = input.value.trim();
            if (text) {
                addNote(text);
                input.value = '';
            }
        });
    }
    if (reminderForm) {
        reminderForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const text = reminderText.value.trim();
            const datetime = reminderTime.value;
            if (text && datetime) {
                const timestamp = new Date(datetime).getTime();
                if (timestamp > Date.now()) {
                    addNote(text, timestamp);
                    reminderText.value = '';
                    reminderTime.value = '';
                } else {
                    alert('Дата напоминания должна быть в будущем');
                }
            }
        });
    }
    renderNotesList();
}
if ('serviceWorker' in navigator) {
    window.addEventListener('load', async () => {
        try {
            const reg = await navigator.serviceWorker.register('/sw.js');
            console.log('SW registered:', reg.scope);
            const enableBtn = document.getElementById('enable-push');
            const disableBtn = document.getElementById('disable-push');
            if (enableBtn && disableBtn) {
                const subscription = await reg.pushManager.getSubscription();
                if (subscription) {
                    enableBtn.style.display = 'none';
                    disableBtn.style.display = 'inline-block';
                    saveSubscriptionToServer(subscription).catch(console.error);
                }
                enableBtn.addEventListener('click', async () => {
                    if (Notification.permission === 'denied') {
                        alert('Уведомления запрещены. Разрешите их в настройках браузера.');
                        return;
                    }
                    if (Notification.permission === 'default') {
                        const permission = await Notification.requestPermission();
                        if (permission !== 'granted') {
                            alert('Необходимо разрешить уведомления.');
                            return;
                        }
                    }
                    await subscribeToPush();
                    enableBtn.style.display = 'none';
                    disableBtn.style.display = 'inline-block';
                });
                disableBtn.addEventListener('click', async () => {
                    await unsubscribeFromPush();
                    disableBtn.style.display = 'none';
                    enableBtn.style.display = 'inline-block';
                });
            }
        } catch (err) {
            console.log('SW registration failed:', err);
        }
    });
}
let deferredPrompt;
const installBtn = document.getElementById('install-btn');

window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    if (installBtn) {
        installBtn.style.display = 'inline-block';
    }
});

if (installBtn) {
    installBtn.addEventListener('click', async () => {
        if (deferredPrompt) {
            deferredPrompt.prompt();
            const { outcome } = await deferredPrompt.userChoice;
            console.log(`User response to the install prompt: ${outcome}`);
            deferredPrompt = null;
            installBtn.style.display = 'none';
        }
    });
}

window.addEventListener('appinstalled', () => {
    console.log('PWA was installed');
    if (installBtn) installBtn.style.display = 'none';
});
