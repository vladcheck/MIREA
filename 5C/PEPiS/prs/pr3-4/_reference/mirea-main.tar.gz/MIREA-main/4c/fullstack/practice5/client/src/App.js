import React, { useState, useEffect } from 'react';
import './App.css'; // Убедись, что файл создан в той же папке!

const API_URL = '/api';

function App() {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [newProduct, setNewProduct] = useState({
        name: '', price: '', category: '', image: 'https://via.placeholder.com/150'
    });

    useEffect(() => {
        fetchProducts();
    }, []);

    const fetchProducts = async () => {
        try {
            setLoading(true);
            const response = await fetch(`${API_URL}/products`);
            const data = await response.json();
            setProducts(data);
        } catch (err) {
            console.error("Ошибка загрузки");
        } finally {
            setLoading(false);
        }
    };

    const handleCreate = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch(`${API_URL}/products`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ...newProduct, price: Number(newProduct.price) })
            });
            if (response.ok) {
                fetchProducts();
                setNewProduct({ name: '', price: '', category: '', image: 'https://via.placeholder.com/150' });
            }
        } catch (err) { console.error("Ошибка создания"); }
    };

    const handleDelete = async (id) => {
        if (!window.confirm("Удалить товар?")) return;
        try {
            const response = await fetch(`${API_URL}/products/${id}`, { method: 'DELETE' });
            if (response.ok) fetchProducts();
        } catch (err) { console.error("Ошибка удаления"); }
    };

    const handleUpdate = async (id, updatedData) => {
        try {
            const response = await fetch(`${API_URL}/products/${id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatedData)
            });
            if (response.ok) fetchProducts();
        } catch (err) { console.error("Ошибка обновления"); }
    };

    return (
        <div className='App'>
            <header style={{ background: '#2c3e50', color: 'white', padding: '20px', textAlign: 'center' }}>
                <h1>Копеечка</h1>
            </header>

            <div className='container'>
                <section className="admin-panel">
                    <h3>Новый товар</h3>
                    <form onSubmit={handleCreate} className="crud-form">
                        <input type="text" placeholder="Название" value={newProduct.name} onChange={e => setNewProduct({...newProduct, name: e.target.value})} required />
                        <input type="number" placeholder="Цена" value={newProduct.price} onChange={e => setNewProduct({...newProduct, price: e.target.value})} required />
                        <input type="text" placeholder="Категория" value={newProduct.category} onChange={e => setNewProduct({...newProduct, category: e.target.value})} required />
                        <button type="submit" className="btn btn-add">Добавить</button>
                    </form>
                </section
>
                {loading ? <p>Загрузка...</p> : (
                    <div className='products-grid'>
                        {products.map(product => (
                            <ProductCard 
                                key={product.id} 
                                product={product} 
                                onDelete={handleDelete} 
                                onUpdate={handleUpdate} 
                            />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

function ProductCard({ product, onDelete, onUpdate }) {
    const [isEditing, setIsEditing] = useState(false);
    const [editData, setEditData] = useState({ ...product });

    const saveEdit = () => {
        onUpdate(product.id, editData);
        setIsEditing(false);
    };

    return (
        <div className='product-card'>
            <div className='product-image-wrapper'>
                <img src={product.image} alt={product.name} className='product-image' />
            </div>
            <div className='product-info' style={{ padding: '10px' }}>
                {isEditing ? (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                        <input value={editData.name} onChange={e => setEditData({...editData, name: e.target.value})} />
                        <input type="number" value={editData.price} onChange={e => setEditData({...editData, price: Number(e.target.value)})} />
                        <button className="btn btn-add" onClick={saveEdit}>Сохранить</button>
                        <button className="btn" onClick={() => setIsEditing(false)}>Отмена</button>
                    </div>
                ) : (
                    <>
                        <small>{product.category}</small>
                        <h4>{product.name}</h4>
                        <p><strong>{product.price} руб.</strong></p>
                        <div className="card-actions">
                            <button className="btn btn-edit" onClick={() => setIsEditing(true)}>Изменить</button>
                            <button className="btn btn-delete" onClick={() => onDelete(product.id)}>Удалить</button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}

export default App;