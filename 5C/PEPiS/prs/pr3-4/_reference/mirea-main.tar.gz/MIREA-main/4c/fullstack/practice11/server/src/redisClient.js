const { createClient } = require('redis');

const redisClient = createClient({
    url: 'redis://127.0.0.1:6379'
});

redisClient.on('error', (err) => {
    console.error('Redis error:', err);
});

const initRedis = async () => {
    try {
        await redisClient.connect();
        console.log('Redis connected');
    } catch (e) {
        console.error('Failed to connect to redis', e);
    }
};

const invalidateUsersCache = async (userId = null) => {
    try {
        await redisClient.del('users:all');
        if (userId) {
            await redisClient.del(`users:${userId}`);
        }
    } catch (err) {
        console.error('Users cache invalidate error:', err);
    }
};

const invalidateProductsCache = async (productId = null) => {
    try {
        await redisClient.del('products:all');
        if (productId) {
            await redisClient.del(`products:${productId}`);
        }
    } catch (err) {
        console.error('Products cache invalidate error:', err);
    }
};

const saveToCache = async (key, data, ttl) => {
    try {
        await redisClient.set(key, JSON.stringify(data), {
            EX: ttl
        });
    } catch (err) {
        console.error('Cache save error:', err);
    }
};

module.exports = {
    redisClient,
    initRedis,
    invalidateUsersCache,
    invalidateProductsCache,
    saveToCache
};
