
const form = document.getElementById('todo-form');
const input = document.getElementById('todo-input');
const list = document.getElementById('todo-list');


function loadTodos() {
    const todos = JSON.parse(localStorage.getItem('todos') || '[]');
    list.innerHTML = todos.map(todo => `<li>${todo}</li>`).join('');
}


function addTodo(text) {
    const todos = JSON.parse(localStorage.getItem('todos') || '[]');
    todos.push(text);
    localStorage.setItem('todos', JSON.stringify(todos));
    loadTodos();
}


form.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (text) {
        addTodo(text);
        input.value = '';
    }
});


loadTodos();


if ('serviceWorker' in navigator) {
    window.addEventListener('load', async () => {
        try {
            const registration = await navigator.serviceWorker.register('./sw.js');
            console.log('ServiceWorker успешно зарегистрирован. Область видимости:', registration.scope);
        } catch (err) {
            console.error('Ошибка регистрации ServiceWorker:', err);
        }
    });
}