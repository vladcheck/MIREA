INSERT INTO district (id, name) VALUES (1, 'Test District') ON CONFLICT (id) DO NOTHING;
INSERT INTO type (id, name) VALUES (1, 'Test Type') ON CONFLICT (id) DO NOTHING;
INSERT INTO building_material (id, name) VALUES (1, 'Brick') ON CONFLICT (id) DO NOTHING;
INSERT INTO property (id, district_id, address, floor, room_count, type_id, status, price, building_material_id, area, listing_date) 
VALUES (1, 1, 'Address 1', 1, 2, 1, true, 10000000, 1, 100, '2023-01-01') ON CONFLICT (id) DO NOTHING;
INSERT INTO realtor (id, last_name, first_name, phone_number, passport_data) 
VALUES (1, 'Doe', 'John', '12345678901', '1234 567890'),
       (2, 'Smith', 'Jane', '12345678902', '1234 567891')
ON CONFLICT (id) DO NOTHING;\n