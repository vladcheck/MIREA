import axios from "axios";

const apiClient = axios.create({
    baseURL: "/api",
    headers: {
        "Content-Type": "application/json",
        "accept": "application/json",
    }
});

apiClient.interceptors.request.use(
    (config) => {
        let accessToken = localStorage.getItem('accessToken');
        if (accessToken) {
            config.headers.Authorization = `Bearer ${accessToken}`;
        }
        return config;
    },
    (error) => Promise.reject(error)
);

apiClient.interceptors.response.use(
    (response) => response,
    async (error) => {
        let accessToken = localStorage.getItem('accessToken');
        let refreshToken = localStorage.getItem('refreshToken');
        let originalRequest = error.config;

        if (error.response && error.response.status === 401 && !originalRequest._retry) {
            originalRequest._retry = true;
            if (!accessToken || !refreshToken) {
                localStorage.removeItem('accessToken');
                localStorage.removeItem('refreshToken');
                return Promise.reject(error);
            }
            try {
                let response = await axios.post("/api/auth/refresh", { token: refreshToken });
                let isRefreshExpired = response.data.refresh_expired;
                if (isRefreshExpired) {
                    localStorage.removeItem('accessToken');
                    localStorage.removeItem('refreshToken');
                    return Promise.reject(error);
                }
                let newAccessToken = response.data.accessToken;
                let newRefreshToken = response.data.refreshToken;
                originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
                localStorage.setItem('accessToken', newAccessToken);
                if (newRefreshToken) {
                    localStorage.setItem('refreshToken', newRefreshToken);
                }
                return apiClient(originalRequest);
            } catch (refreshError) {
                localStorage.removeItem('accessToken');
                localStorage.removeItem('refreshToken');
                return Promise.reject(refreshError);
            }
        }
        return Promise.reject(error);
    }
);

export const api = {
    login: async (email, password) => {
        let response = await axios.post("/api/auth/login", { email, password });
        return response.data;
    },
    register: async (email, password) => {
        let response = await axios.post("/api/auth/register", { email, password });
        return response.data;
    },
    getProducts: async () => {
        let response = await apiClient.get("/products");
        return response.data;
    },
    createProduct: async (product) => {
        let response = await apiClient.post("/products", product);
        return response.data;
    },
    updateProduct: async (id, product) => {
        let response = await apiClient.put(`/products/${id}`, product);
        return response.data;
    },
    deleteProduct: async (id) => {
        await apiClient.delete(`/products/${id}`);
    }
};
