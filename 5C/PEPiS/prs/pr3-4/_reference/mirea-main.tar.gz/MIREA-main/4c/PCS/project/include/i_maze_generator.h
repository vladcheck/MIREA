#pragma once
#include "cell.h"
#include "maze_context.h"
#include "grid.h"
struct GridNode {
    int x, y;
};
class IMazeGenerator {
public:
    virtual ~IMazeGenerator() = default;
    virtual void generate(GridNode node, MazeContext& ctx) = 0;
};
