#pragma once
#include <string>
#include <vector>
#include "maze_context.h"
#include "pathfinder.h"
class IMazeExporter {
public:
    virtual ~IMazeExporter() = default;
    virtual std::string exportMaze(const MazeContext& ctx, const std::vector<Point>& path = {}) = 0;
};
class AsciiExporter : public IMazeExporter {
public:
    std::string exportMaze(const MazeContext& ctx, const std::vector<Point>& path = {}) override;
};
class JsonExporter : public IMazeExporter {
public:
    std::string exportMaze(const MazeContext& ctx, const std::vector<Point>& path = {}) override;
};
class PngExporter : public IMazeExporter {
public:
    std::string exportMaze(const MazeContext& ctx, const std::vector<Point>& path = {}) override;
};
