class Storage:
    def __init__(self):
        self.tasks = {}
        self.counter = 1

    def drop(self):
        self.tasks = {}
        self.counter = 1

storage = Storage()