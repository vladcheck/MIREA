BEGIN;
DO $$
BEGIN
    RAISE NOTICE 'Тест 5.1: Проверка работы журнала (INSERT, UPDATE, DELETE)...';
    
    RAISE NOTICE 'Шаг 1: Создаем запись (ожидаем лог INSERT)...';
    INSERT INTO sale (id, property_id, realtor_id, price, sale_date) VALUES (501, 1, 1, 10000000, CURRENT_DATE);
    
    RAISE NOTICE 'Шаг 2: Обновляем запись (ожидаем лог UPDATE)...';
    UPDATE sale SET price = 5500000 WHERE id = 501;
    
    RAISE NOTICE 'Шаг 3: Удаляем запись (ожидаем лог DELETE)...';
    DELETE FROM sale WHERE id = 501;
    
    RAISE NOTICE 'Журнал успешно отработал! Ниже будет выведена таблица journal со всеми тремя операциями:';
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'ОШИБКА: Тест упал при выполнении операций: %', SQLERRM;
END $$;

-- Выводим таблицу так, чтобы было видно результат
SELECT id, operation_time::time(0) as time, operation, username FROM journal ORDER BY id DESC LIMIT 3;

ROLLBACK;