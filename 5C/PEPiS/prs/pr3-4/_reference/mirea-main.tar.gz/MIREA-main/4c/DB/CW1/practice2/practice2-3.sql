CREATE OR REPLACE FUNCTION get_mortgage_payment_lyapunov(
    object_code INTEGER,
    percent_value DOUBLE PRECISION,
    pay_period INTEGER,
    first_pay DOUBLE PRECISION
)
    RETURNS DOUBLE PRECISION
    LANGUAGE SQL
AS
$$
SELECT (p.price - first_pay) * ((percent_value / 12) * POWER(1 + (percent_value / 12), pay_period * 12)) /
       (POWER(1 + (percent_value / 12), pay_period * 12) - 1)
FROM property p
WHERE id = object_code;
$$;