import React, { useEffect, useState } from 'react';
import api from '../api';

const Users = () => {
    const [users, setUsers] = useState([]);
    const [error, setError] = useState('');
    const [editingUser, setEditingUser] = useState(null);
    const [editRole, setEditRole] = useState('');

    const fetchUsers = async () => {
        try {
            const { data } = await api.get('/users');
            setUsers(data);
        } catch (err) {
            setError('Ошибка загрузки пользователей');
        }
    };

    useEffect(() => {
        fetchUsers();
    }, []);

    const handleUpdateRole = async (userId) => {
        try {
            await api.put(`/users/${userId}`, { role: editRole });
            setEditingUser(null);
            fetchUsers();
        } catch (err) {
            setError('Ошибка обновления роли');
        }
    };

    const handleDeleteUser = async (userId) => {
        if (!window.confirm('Вы уверены, что хотите удалить (заблокировать) этого пользователя?')) return;
        try {
            await api.delete(`/users/${userId}`);
            fetchUsers();
        } catch (err) {
            setError('Ошибка удаления пользователя');
        }
    };

    return (
        <div className="products-container">
            <h2>Управление пользователями (Admin)</h2>
            {error && <div className="error-message">{error}</div>}
            
            <ul style={{ listStyle: 'none', padding: 0 }}>
                {users.map(user => (
                    <li key={user._id} className="product-item">
                        <div className="product-info">
                            <h4>{user.email}</h4>
                            <span className="desc">Роль: <strong>{user.role}</strong></span>
                        </div>
                        <div className="product-actions">
                            {editingUser === user._id ? (
                                <>
                                    <select 
                                        value={editRole} 
                                        onChange={(e) => setEditRole(e.target.value)}
                                        className="input-field"
                                        style={{ marginBottom: 0, marginRight: '10px', width: 'auto' }}
                                    >
                                        <option value="user">User</option>
                                        <option value="seller">Seller</option>
                                        <option value="admin">Admin</option>
                                    </select>
                                    <button onClick={() => handleUpdateRole(user._id)} className="btn-primary">OK</button>
                                    <button onClick={() => setEditingUser(null)} className="btn-secondary">Отмена</button>
                                </>
                            ) : (
                                <>
                                    <button onClick={() => {
                                        setEditingUser(user._id);
                                        setEditRole(user.role);
                                    }} className="btn-secondary">Изменить роль</button>
                                    <button onClick={() => handleDeleteUser(user._id)} className="btn-danger">Удалить</button>
                                </>
                            )}
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Users;