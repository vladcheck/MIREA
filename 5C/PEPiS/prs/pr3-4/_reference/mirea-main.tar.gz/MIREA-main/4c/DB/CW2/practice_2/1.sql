CREATE OR REPLACE FUNCTION update_realtor_bonus_lyapunov()
    RETURNS TRIGGER AS
$$
DECLARE
    v_bonus NUMERIC;
BEGIN
    IF TG_OP = 'INSERT' THEN
        v_bonus := NEW.price * 0.05;
        INSERT INTO realtor_bonus (realtor_id, bonus_amount)
        VALUES (NEW.realtor_id, v_bonus)
        ON CONFLICT (realtor_id) DO UPDATE
            SET bonus_amount = realtor_bonus.bonus_amount + EXCLUDED.bonus_amount;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        v_bonus := OLD.price * 0.05;
        UPDATE realtor_bonus
        SET bonus_amount = bonus_amount - v_bonus
        WHERE realtor_id = OLD.realtor_id;
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_update_realtor_bonus ON sale;
CREATE TRIGGER trg_update_realtor_bonus
    AFTER INSERT OR DELETE
    ON sale
    FOR EACH ROW
EXECUTE FUNCTION update_realtor_bonus_lyapunov();