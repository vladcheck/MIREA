CREATE OR REPLACE FUNCTION log_sale_changes_lyapunov()
    RETURNS TRIGGER AS
$$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO journal (operation, username) VALUES ('INSERT', current_user);
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO journal (operation, username) VALUES ('UPDATE', current_user);
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO journal (operation, username) VALUES ('DELETE', current_user);
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_log_sale_changes ON sale;
CREATE TRIGGER trg_log_sale_changes
    AFTER INSERT OR UPDATE OR DELETE
    ON sale
    FOR EACH ROW
EXECUTE FUNCTION log_sale_changes_lyapunov();