import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../api';

const Register = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('user');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        try {
            await api.post('/auth/register', { email, password, role });
            alert('Регистрация успешна! Теперь вы можете войти.');
            navigate('/login');
        } catch (err) {
            if (err.response && err.response.data && err.response.data.message) {
                setError(err.response.data.message);
            } else {
                setError('Не удалось подключиться к серверу. Проверьте соединение.');
            }
        }
    };

    return (
        <div className="auth-container">
            <h2>Регистрация</h2>
            {error && <div className="error-message">{error}</div>}
            <form onSubmit={handleSubmit} className="auth-form">
                <div>
                    <input 
                        type="email" 
                        className="input-field"
                        placeholder="Email" 
                        value={email} 
                        onChange={e => setEmail(e.target.value)} 
                        required 
                    />
                </div>
                <div>
                    <input 
                        type="password" 
                        className="input-field"
                        placeholder="Пароль" 
                        value={password} 
                        onChange={e => setPassword(e.target.value)} 
                        required 
                    />
                </div>
                <div style={{ marginBottom: '15px' }}>
                    <select 
                        value={role} 
                        onChange={e => setRole(e.target.value)}
                        className="input-field"
                        style={{ width: '100%' }}
                    >
                        <option value="user">User (Просмотр)</option>
                        <option value="seller">Seller (Товары)</option>
                        <option value="admin">Admin (Все права)</option>
                    </select>
                </div>
                <button type="submit" className="btn-primary">Зарегистрироваться</button>
            </form>
            <p className="auth-footer">Уже есть аккаунт? <Link to="/login">Войти</Link></p>
        </div>
    );
};

export default Register;