#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "../include/grid.h"
#include "../include/exceptions.h"
#include "../include/maze_context.h"
#include "../include/dfs_generator.h"
#include "../include/kruskal_generator.h"
#include "../include/prim_generator.h"
#include "../include/pathfinder.h"
#include "../include/maze_facade.h"
TEST_CASE("ValidDimensions", "[GridTest]") {
    Grid grid(10, 10);
    REQUIRE(grid.isValid(0, 0) == true);
    REQUIRE(grid.isValid(9, 9) == true);
    REQUIRE(grid.isValid(10, 10) == false);
    REQUIRE(grid.isValid(-1, 0) == false);
}
TEST_CASE("InvalidDimensionsThrow", "[GridTest]") {
    REQUIRE_THROWS_AS(Grid(-5, 10), std::invalid_argument);
    REQUIRE_THROWS_AS(Grid(0, 10), std::invalid_argument);
}
TEST_CASE("OutOfBoundsAccessThrows", "[GridTest]") {
    Grid grid(5, 5);
    REQUIRE_THROWS_AS(grid.getCell(5, 5), MazeBoundsException);
    REQUIRE_THROWS_AS(grid.getCell(-1, 2), MazeBoundsException);
    REQUIRE_NOTHROW(grid.getCell(4, 4));
}
TEST_CASE("MazeContextInvalidDimensionsThrow", "[MazeContextTest]") {
    REQUIRE_THROWS_AS(MazeContext(-1, 5, 123), std::invalid_argument);
}
TEST_CASE("DfsGeneratesCorrectNumberOfCells", "[GeneratorTest]") {
    MazeContext ctx(5, 5, 42);
    DfsGenerator gen;
    gen.generate({0, 0}, ctx);
    REQUIRE(ctx.getCells().size() == 25);
}
TEST_CASE("KruskalGeneratesCorrectNumberOfCells", "[GeneratorTest]") {
    MazeContext ctx(6, 4, 123);
    KruskalGenerator gen;
    gen.generate({0, 0}, ctx);
    REQUIRE(ctx.getCells().size() == 24);
}
TEST_CASE("PrimGeneratesCorrectNumberOfCells", "[GeneratorTest]") {
    MazeContext ctx(3, 3, 999);
    PrimGenerator gen;
    gen.generate({0, 0}, ctx);
    REQUIRE(ctx.getCells().size() == 9);
}
TEST_CASE("OutOfBoundsThrows", "[PathfinderTest]") {
    MazeContext ctx(5, 5, 42);
    DfsGenerator gen;
    gen.generate({0, 0}, ctx);
    Pathfinder pf;
    REQUIRE_THROWS_AS(pf.findPath(ctx, {-1, 0}, {4, 4}), MazeBoundsException);
    REQUIRE_THROWS_AS(pf.findPath(ctx, {0, 0}, {5, 5}), MazeBoundsException);
}
TEST_CASE("FindsPathSuccessfully", "[PathfinderTest]") {
    MazeContext ctx(5, 5, 42);
    DfsGenerator gen;
    gen.generate({0, 0}, ctx);
    Pathfinder pf;
    auto path = pf.findPath(ctx, {0, 0}, {4, 4});
    REQUIRE(path.empty() == false);
    REQUIRE(path.front().x == 0);
    REQUIRE(path.front().y == 0);
    REQUIRE(path.back().x == 4);
    REQUIRE(path.back().y == 4);
}
TEST_CASE("GeneratesUsingFacade", "[MazeFacadeTest]") {
    MazeContext ctx(4, 4, 100);
    MazeFacade facade;
    facade.setGenerator(std::make_unique<DfsGenerator>());
    REQUIRE_NOTHROW(facade.run(ctx));
    REQUIRE(ctx.getCells().size() == 16);
}
