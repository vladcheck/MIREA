#pragma once
#include <cstdint>
enum class WallType {
    INNER_WALL,
    OUTER_BOUNDARY,
    ENTRANCE,
    EXIT
};
struct CellData {
    int x, y;
    bool wall_north = true;
    bool wall_south = true;
    bool wall_east = true;
    bool wall_west = true;
    WallType type = WallType::INNER_WALL;
};
