#include "../include/maze_exporter.h"
#include <sstream>
std::string JsonExporter::exportMaze(const MazeContext& ctx, const std::vector<Point>& path) {
    std::stringstream ss;
    int width = ctx.getWidth();
    int height = ctx.getHeight();
    const auto& cells = ctx.getCells();
    ss << "{\n";
    ss << "  \"width\": " << width << ",\n";
    ss << "  \"height\": " << height << ",\n";
    ss << "  \"cells\": [\n";
    for (size_t i = 0; i < cells.size(); ++i) {
        const auto& cell = cells[i];
        ss << "    {\n";
        ss << "      \"x\": " << cell.x << ",\n";
        ss << "      \"y\": " << cell.y << ",\n";
        ss << "      \"walls\": {\n";
        ss << "        \"north\": " << (cell.wall_north ? "true" : "false") << ",\n";
        ss << "        \"south\": " << (cell.wall_south ? "true" : "false") << ",\n";
        ss << "        \"east\": " << (cell.wall_east ? "true" : "false") << ",\n";
        ss << "        \"west\": " << (cell.wall_west ? "true" : "false") << "\n";
        ss << "      }\n";
        ss << "    }" << (i == cells.size() - 1 ? "" : ",") << "\n";
    }
    ss << "  ],\n";
    ss << "  \"path\": [\n";
    for (size_t i = 0; i < path.size(); ++i) {
        ss << "    {\"x\": " << path[i].x << ", \"y\": " << path[i].y << "}" << (i == path.size() - 1 ? "" : ",") << "\n";
    }
    ss << "  ]\n";
    ss << "}\n";
    return ss.str();
}
