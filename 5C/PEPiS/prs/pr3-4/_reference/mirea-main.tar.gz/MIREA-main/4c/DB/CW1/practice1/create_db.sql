CREATE DATABASE lyapunov
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'en_US.UTF-8'
    LC_CTYPE = 'en_US.UTF-8'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;

-- Таблица «Тип»
CREATE TABLE type
(
    id   SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

-- Таблица «Районы»
CREATE TABLE district
(
    id   SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

-- Таблица «Материалы здания»
CREATE TABLE building_material
(
    id   SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

-- Таблица «Объект недвижимости»
CREATE TABLE property
(
    id                   SERIAL PRIMARY KEY,
    district_id          INTEGER      NOT NULL REFERENCES district (id),
    address              VARCHAR(255) NOT NULL,
    floor                SMALLINT     NOT NULL,
    room_count           SMALLINT     NOT NULL,
    type_id              SMALLINT     NOT NULL REFERENCES type (id),
    status               BOOLEAN      NOT NULL,
    price                INTEGER      NOT NULL,
    description          TEXT,
    building_material_id INTEGER      NOT NULL REFERENCES building_material (id),
    area                 SMALLINT     NOT NULL,
    listing_date         DATE         NOT NULL
);

-- Таблица «Критерии оценки»
CREATE TABLE evaluation_criterion
(
    id   SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

-- Таблица «Оценки»
CREATE TABLE evaluation
(
    id              SERIAL PRIMARY KEY,
    property_id     INTEGER          NOT NULL REFERENCES property (id),
    evaluation_date DATE             NOT NULL,
    criterion_id    SMALLINT         NOT NULL REFERENCES evaluation_criterion (id),
    score           DOUBLE PRECISION NOT NULL
);

-- Таблица «Риэлтор»
CREATE TABLE realtor
(
    id           SERIAL PRIMARY KEY,
    last_name    VARCHAR(255) NOT NULL,
    first_name   VARCHAR(255) NOT NULL,
    middle_name  VARCHAR(255),
    phone_number VARCHAR(20)  NOT NULL
);

-- Таблица «Продажа»
CREATE TABLE sale
(
    id          SERIAL PRIMARY KEY,
    property_id INTEGER          NOT NULL REFERENCES property (id),
    sale_date   DATE             NOT NULL,
    realtor_id  INTEGER          NOT NULL REFERENCES realtor (id),
    price       DOUBLE PRECISION NOT NULL
);