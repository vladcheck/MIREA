CREATE OR REPLACE FUNCTION get_cheap_properties_lyapunov()
    RETURNS TABLE
            (
                address       VARCHAR(255),
                district_name VARCHAR(255),
                room_count    INTEGER
            )
    LANGUAGE SQL
AS
$$
SELECT p.address,
       d.name AS district_name,
       p.room_count
FROM property p
         JOIN district d ON p.district_id = d.id
WHERE p.area > 0
  AND (p.price::numeric / p.area) < (SELECT AVG(sub.price::numeric / sub.area)
                                     FROM property sub
                                     WHERE sub.district_id = p.district_id
                                       AND sub.area > 0);
$$;