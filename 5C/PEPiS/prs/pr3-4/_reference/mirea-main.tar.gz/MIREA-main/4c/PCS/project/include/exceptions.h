#pragma once
#include <stdexcept>
#include <string>
class MazeBoundsException : public std::runtime_error {
public:
    MazeBoundsException(const std::string& msg) : std::runtime_error(msg) {}
};
