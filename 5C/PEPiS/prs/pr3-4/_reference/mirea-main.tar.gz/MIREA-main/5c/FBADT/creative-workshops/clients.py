"""Clients of creative workshops."""

from typing import List, Optional


class Client:
    """Клиент творческой мастерской."""

    def __init__(
        self,
        client_id: int,
        name: str,
        age: int,
        is_student: bool = False,
    ) -> None:
        """Создать объект клиента."""
        self.id = client_id
        self.name = name
        self.age = age
        self.is_student = is_student

    @classmethod
    def from_data(cls, data: dict) -> "Client":
        """Создать клиента из словаря."""
        return cls(
            client_id=int(data["id"]),
            name=str(data["name"]),
            age=int(data["age"]),
            is_student=bool(data.get("is_student", False)),
        )

    def __str__(self) -> str:
        """Вернуть строковое представление клиента."""
        if self.is_student:
            return f"{self.name}, {self.age} лет, студент"
        return f"{self.name}, {self.age} лет"


def add_client(
    clients: List[Client],
    name: str,
    age: int,
    is_student: bool = False,
) -> Client:
    """Add a client and return created object."""
    if age < 0:
        raise ValueError("age must be non-negative")
    new_id = max((item.id for item in clients), default=0) + 1
    item = Client(new_id, name, age, is_student)
    clients.append(item)
    return item


def find_client(
    clients: List[Client],
    query: str,
) -> List[Client]:
    """Find clients with query substring in the name."""
    result = []
    lowered = query.strip().lower()
    for item in clients:
        if lowered in item.name.lower():
            result.append(item)
    return result


def find_client_by_id(
    clients: List[Client],
    client_id: int,
) -> Optional[Client]:
    """Find client object by id or return None."""
    for item in clients:
        if item.id == client_id:
            return item
    return None
