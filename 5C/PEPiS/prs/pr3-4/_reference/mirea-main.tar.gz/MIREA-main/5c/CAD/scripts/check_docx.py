"""Check PR2 docx for samlib requirements. Prints PASS/FAIL, asserts."""
from docx import Document

DOC = "Практическая работа 2 — Исследование для проекта.docx"

def text_all(doc):
    parts = [p.text for p in doc.paragraphs]
    for t in doc.tables:
        for r in t.rows:
            for c in r.cells:
                parts.append(c.text)
    return "\n".join(parts)

def main():
    doc = Document(DOC)
    full = text_all(doc)
    low = full.lower()
    checks = []
    def check(name, ok, detail=""):
        print(f"{'PASS' if ok else 'FAIL'}: {name}" + (f" — {detail}" if detail else ""))
        checks.append(ok)

    check("samlib упомянут", "samlib" in low, f"count={low.count('samlib')}")
    https_n = full.count("https://")
    check(">=6 https://", https_n >= 6, f"found={https_n}")
    check(">=1 таблица", len(doc.tables) >= 1, f"tables={len(doc.tables)}")
    check("Артём present", "Артём" in full or "Артем" in full)
    check("Софья present", "Софья" in full)
    kogda_n = full.count("Когда")
    check(">=6 «Когда»", kogda_n >= 6, f"found={kogda_n}")
    import re
    for bad in ["TBD", "TODO", "lorem"]:
        check(f"нет '{bad}'", re.search(rf"(?<!\w){bad}(?!\w)", full, re.IGNORECASE) is None)
    ok = all(checks)
    print("RESULT:", "ALL PASS" if ok else "FAILURES PRESENT")
    assert ok, "check_docx FAILED"

if __name__ == "__main__":
    main()
