"""ПР6: генерация презентации samlib.ru (5 слайдов) -> presentation-samlib.pdf.

Запуск: python3 scripts/gen_presentation.py
Выход: presentation-samlib.pdf + копия «Практическая работа 6 — Презентация-samlib.pdf»
Требуется: reportlab (кириллица через DejaVuSans).
"""
import shutil
from pathlib import Path

from reportlab.lib.pagesizes import landscape, A4
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "presentation-samlib.pdf"
COPY = ROOT / "Практическая работа 6 — Презентация-samlib.pdf"

INK = HexColor("#1A1A1A")
PAPER = HexColor("#FFFFFF")
CREAM = HexColor("#F5F0E8")
ACCENT = HexColor("#C84B31")
GREY1 = HexColor("#C4C4C4")
GREY2 = HexColor("#E5E5E5")

W, H = landscape(A4)  # 841.9 x 595.3 pt

DEJAVU = "/Users/d.d.lyapunov/Library/Python/3.9/lib/python/site-packages/matplotlib/mpl-data/fonts/ttf/DejaVuSans.ttf"
DEJAVU_B = "/Users/d.d.lyapunov/Library/Python/3.9/lib/python/site-packages/matplotlib/mpl-data/fonts/ttf/DejaVuSans-Bold.ttf"
ARIALUNI = "/Library/Fonts/Arial Unicode.ttf"


def register_fonts():
    if Path(DEJAVU).exists() and Path(DEJAVU_B).exists():
        pdfmetrics.registerFont(TTFont("Body", DEJAVU))
        pdfmetrics.registerFont(TTFont("BodyB", DEJAVU_B))
        return "Body", "BodyB"
    if Path(ARIALUNI).exists():
        pdfmetrics.registerFont(TTFont("Body", ARIALUNI))
        return "Body", "Body"
    return "Helvetica", "Helvetica-Bold"


F, FB = register_fonts()


def bg(c, color):
    c.setFillColor(color)
    c.rect(0, 0, W, H, stroke=0, fill=1)


def header_bar(c, num, title):
    c.setFillColor(INK)
    c.rect(0, H - 64, W, 64, stroke=0, fill=1)
    c.setFillColor(PAPER)
    c.setFont(FB, 13)
    c.drawString(28, H - 30, f"Слайд {num}/5")
    c.setFont(FB, 16)
    c.drawString(150, H - 30, title)
    c.setFillColor(ACCENT)
    c.rect(W - 120, H - 64, 120, 64, stroke=0, fill=1)
    c.setFillColor(PAPER)
    c.setFont(FB, 13)
    c.drawString(W - 88, H - 30, "samlib")


def footer(c, text="Ляпунов Д. Д. · samlib.ru · 2026"):
    c.setFillColor(INK)
    c.setFont(F, 9)
    c.drawString(28, 22, text)


def bullet(c, x, y, text, font=F, size=11, color=INK, step=18):
    c.setFillColor(color)
    c.setFont(font, size)
    c.drawString(x, y, "•  " + text)
    return y - step


def slide1(c):
    bg(c, CREAM)
    c.setFillColor(INK)
    c.rect(0, H - 150, W, 150, stroke=0, fill=1)
    c.setFillColor(PAPER)
    c.setFont(FB, 15)
    c.drawString(28, H - 45, "МИРЭА · ИПТИП · Кафедра компьютерного дизайна")
    c.setFont(F, 12)
    c.drawString(28, H - 70, "Дисциплина «Компьютерный дизайн» · Практическая работа 6")
    c.setFont(F, 10)
    c.drawString(28, H - 95, "Преподаватели: Мильчакова Н. Е., Мочалова Л. В., Чурин А. С.")
    c.setFillColor(ACCENT)
    c.rect(W - 190, H - 150, 190, 150, stroke=0, fill=1)
    c.setFillColor(PAPER)
    c.setFont(FB, 22)
    c.drawString(W - 165, H - 70, "ПР6")
    c.setFont(F, 11)
    c.drawString(W - 165, H - 95, "финал + защита")
    # title
    c.setFillColor(INK)
    c.setFont(FB, 40)
    c.drawString(28, H - 230, "Редизайн samlib.ru")
    c.setFont(F, 15)
    c.drawString(28, H - 262, "Журнал «Самиздат» — бесплатная библиотека: читать, подписаться, опубликовать")
    # card
    c.setFillColor(PAPER)
    c.setStrokeColor(INK)
    c.setLineWidth(2)
    c.rect(28, 60, 500, 220, stroke=1, fill=1)
    c.setFillColor(INK)
    c.setFont(FB, 14)
    c.drawString(48, 250, "Выполнил: Ляпунов Д. Д.")
    c.setFont(F, 11)
    c.drawString(48, 226, "студент ИПТИП · Москва, 2026")
    c.setFont(F, 11)
    c.drawString(48, 200, "Целевые действия: Читать · Подписаться · Опубликовать")
    c.drawString(48, 178, "Критерий успеха: задача решается за 2 минуты с телефона")
    c.setFillColor(ACCENT)
    c.rect(48, 120, 200, 40, stroke=0, fill=1)
    c.setFillColor(PAPER)
    c.setFont(FB, 13)
    c.drawString(105, 134, "Читать")
    c.setFillColor(PAPER)
    c.setStrokeColor(INK)
    c.setLineWidth(2)
    c.rect(260, 120, 200, 40, stroke=1, fill=1)
    c.setFillColor(INK)
    c.setFont(F, 13)
    c.drawString(295, 134, "Опубликовать")
    # right: palette
    c.setFillColor(INK)
    c.setFont(FB, 13)
    c.drawString(580, 250, "Палитра финала — 4 цвета:")
    c.setFont(F, 11)
    c.drawString(580, 232, "обводки width 2")
    sw = [(INK, "#1A1A1A"), (PAPER, "#FFFFFF"),
          (CREAM, "#F5F0E8"), (ACCENT, "#C84B31")]
    x = 580
    for col, label in sw:
        c.setFillColor(col)
        c.setStrokeColor(INK)
        c.setLineWidth(2)
        c.rect(x, 150, 55, 55, stroke=1, fill=1)
        c.setFillColor(INK)
        c.setFont(F, 9)
        c.drawString(x + 2, 132, label)
        x += 62
    c.setFont(F, 10)
    c.drawString(580, 100, "photo-treatment: brightness(1.02)")
    c.drawString(580, 82, "contrast(1.05) saturate(0.9) warm")
    c.setFont(F, 10)
    c.drawString(580, 62, "Десктоп 1920 / контент 1300")
    c.drawString(580, 46, "Мобила 390 / контент 358")
    footer(c)
    c.showPage()


def slide2(c):
    bg(c, PAPER)
    header_bar(c, 2, "Исследование: цель · персоны · 6 конкурентов")
    y = H - 110
    c.setFillColor(INK)
    c.setFont(FB, 14)
    c.drawString(28, y, "Цель проекта")
    c.setFont(F, 11)
    c.drawString(28, y - 22, "Спроектировать лендинг samlib.ru, упрощающий путь к действиям: читать, подписаться, опубликовать.")
    y -= 60
    c.setFont(FB, 14)
    c.drawString(28, y, "Персоны")
    y -= 24
    # persona cards
    for i, (name, desc) in enumerate([
        ("Артём, 19 — читатель", "курьер · читает фантастику с телефона · хочет подборки и подписку на продолжения"),
        ("Софья, 22 — начинающий автор", "пишет рассказы · хочет простые шаги публикации · боится, что текст никто не найдёт"),
    ]):
        x = 28 + i * 395
        c.setFillColor(CREAM)
        c.setStrokeColor(INK)
        c.setLineWidth(2)
        c.rect(x, y - 78, 380, 78, stroke=1, fill=1)
        c.setFillColor(INK)
        c.setFont(FB, 11)
        c.drawString(x + 12, y - 22, name)
        c.setFont(F, 9.5)
        # wrap manually in two lines
        parts = desc.split(" · ")
        c.drawString(x + 12, y - 42, " · ".join(parts[:2]))
        if len(parts) > 2:
            c.drawString(x + 12, y - 58, " · ".join(parts[2:]))
    y -= 108
    c.setFillColor(INK)
    c.setFont(FB, 14)
    c.drawString(28, y, "6 конкурентов (ПР2): прямые + косвенные")
    y -= 24
    comps = [
        ("Proza.ru — прямой", "https://proza.ru"),
        ("Author.Today — прямой", "https://author.today"),
        ("Ridero — прямой", "https://ridero.ru"),
        ("LiveLib — косвенный", "https://www.livelib.ru/"),
        ("Yandex Books — косвенный", "https://books.yandex.ru/"),
        ("LitRes — косвенный", "https://www.litres.ru/"),
    ]
    for i, (name, url) in enumerate(comps):
        col = i % 3
        row = i // 3
        x = 28 + col * 262
        yy = y - row * 62
        c.setFillColor(CREAM if row == 0 else PAPER)
        c.setStrokeColor(INK)
        c.setLineWidth(2)
        c.rect(x, yy - 48, 250, 48, stroke=1, fill=1)
        c.setFillColor(INK)
        c.setFont(FB, 10)
        c.drawString(x + 10, yy - 20, name)
        c.setFont(F, 8.5)
        c.drawString(x + 10, yy - 36, url)
    y -= 140
    c.setFillColor(ACCENT)
    c.setFont(FB, 11)
    c.drawString(28, y, "Вывод: взять у конкурентов карточки с обложками, подписки и чтение с телефона — сохранить бесплатность samlib.")
    footer(c)
    c.showPage()


def ia_tree(c, x, y, w=760):
    # root
    c.setFillColor(ACCENT)
    c.setStrokeColor(INK)
    c.setLineWidth(2)
    c.rect(x + w / 2 - 70, y - 34, 140, 34, stroke=1, fill=1)
    c.setFillColor(PAPER)
    c.setFont(FB, 10)
    c.drawCentredString(x + w / 2, y - 22, "samlib.ru")
    l1 = ["Каталог", "Новинки", "Рейтинги", "Как опубл.", "Подписка"]
    l2 = ["Жанры", "Авторы", "Конкурсы", "Читать", "Подписаться"]
    l3 = ["Подписка", "Публикация", "Подтвержд."]
    bw = 138
    gap = (w - 5 * bw) / 4
    y1 = y - 90
    xs = [x + i * (bw + gap) for i in range(5)]
    for i, t in enumerate(l1):
        c.setFillColor(PAPER)
        c.setStrokeColor(INK)
        c.setLineWidth(2)
        c.rect(xs[i], y1 - 34, bw, 34, stroke=1, fill=1)
        c.setFillColor(INK)
        c.setFont(F, 9)
        c.drawCentredString(xs[i] + bw / 2, y1 - 22, t)
        # connector root->l1
        c.setStrokeColor(INK)
        c.setLineWidth(2)
        c.line(x + w / 2, y - 34, xs[i] + bw / 2, y1)
    y2 = y1 - 90
    for i, t in enumerate(l2):
        c.setFillColor(CREAM)
        c.setStrokeColor(INK)
        c.setLineWidth(2)
        c.rect(xs[i], y2 - 34, bw, 34, stroke=1, fill=1)
        c.setFillColor(INK)
        c.setFont(F, 9)
        c.drawCentredString(xs[i] + bw / 2, y2 - 22, t)
        c.setStrokeColor(INK)
        c.setLineWidth(2)
        c.line(xs[i] + bw / 2, y1 - 34, xs[i] + bw / 2, y2)
    y3 = y2 - 90
    for i, t in enumerate(l3):
        xx = x + 90 + i * 210
        c.setFillColor(PAPER)
        c.setStrokeColor(ACCENT)
        c.setLineWidth(2)
        c.rect(xx, y3 - 34, 170, 34, stroke=1, fill=1)
        c.setFillColor(INK)
        c.setFont(F, 9)
        c.drawCentredString(xx + 85, y3 - 22, t)
    return y3 - 50


def slide3(c):
    bg(c, PAPER)
    header_bar(c, 3, "Информационная архитектура: 3 уровня")
    c.setFillColor(INK)
    c.setFont(F, 11)
    c.drawString(28, H - 100, "ИА из ПР3 (00-IA.svg, 1600×1000): L1 — 5 разделов · L2 — 5 подразделов · L3 — 3 попапа.")
    end_y = ia_tree(c, 40, H - 120)
    y = end_y - 10
    c.setFillColor(INK)
    c.setFont(FB, 12)
    c.drawString(28, y, "Как читать схему")
    y = bullet(c, 28, y - 24, "L1 разделы: Каталог · Новинки · Рейтинги · Как опубликоваться · Подписка")
    y = bullet(c, 28, y, "L2 подразделы: Жанры · Авторы · Конкурсы · Читать · Подписаться")
    y = bullet(c, 28, y, "L3 попапы 480×360: Подписка (email + галочка) · Публикация (название + файл) · Подтверждение (OK)")
    y = bullet(c, 28, y, "Действие «Читать» живёт в Новинках/Рейтинге · «Подписаться» — в Подписке · Конкурсы — внутри Рейтингов")
    footer(c)
    c.showPage()


def wire_mock(c, x, y, w, h, title, cols=3):
    c.setFillColor(GREY2)
    c.setStrokeColor(INK)
    c.setLineWidth(2)
    c.rect(x, y - h, w, h, stroke=1, fill=1)
    c.setFillColor(INK)
    c.setFont(FB, 10)
    c.drawString(x + 8, y - 20, title)
    # header strip
    c.setFillColor(GREY1)
    c.setStrokeColor(INK)
    c.setLineWidth(2)
    c.rect(x + 8, y - 52, w - 16, 24, stroke=1, fill=1)
    # hero
    c.rect(x + 8, y - 110, w - 16, 52, stroke=1, fill=1)
    # cards row
    cw = (w - 16 - (cols - 1) * 8) / cols
    for i in range(cols):
        c.rect(x + 8 + i * (cw + 8), y - 170, cw, 52, stroke=1, fill=1)
    c.setFillColor(INK)
    c.setFont(F, 8)
    c.drawString(x + 8, y - h + 8, "серый вайрфрейм · обводка 2")


def slide4(c):
    bg(c, PAPER)
    header_bar(c, 4, "Вайрфреймы: десктоп + мобила (серые)")
    c.setFillColor(INK)
    c.setFont(F, 11)
    c.drawString(28, H - 100, "ПР3–ПР5: серые #C4C4C4 / #E5E5E5 · обводка width 2 · реальный текст samlib.")
    # desktop mock
    wire_mock(c, 28, H - 120, 560, 330, "Десктоп 1920 · контент 1300 · сетка 12 · gutter 20–30", cols=4)
    c.setFont(F, 10)
    c.setFillColor(INK)
    c.drawString(28, H - 470, "01-hero-1920.svg (3000) + 03-blocks.svg (3300) + 04-footer-popups.svg")
    # mobile mock narrow
    wire_mock(c, 620, H - 120, 170, 330, "Мобила 390", cols=1)
    c.setFillColor(INK)
    c.setFont(F, 10)
    c.drawString(620, H - 470, "05-mobile.svg (6870) · контент 358")
    c.drawString(620, H - 486, "сетка 8 · margin 16 · gutter 10 · 1 колонка")
    y = H - 500
    y = bullet(c, 28, y - 10, "Десктоп: шапка 110 · hero 700 · каталог 3×2 · новинки+рейтинги · 3 шага · отзывы · подписка · FAQ · футер · 3 попапа")
    y = bullet(c, 28, y, "Мобила: те же блоки вертикально · бургер ≡ · кнопки ≥44 (326×48, 240×56, 200×44) · попапы 358 из 390")
    footer(c)
    c.showPage()


def slide5(c):
    bg(c, CREAM)
    header_bar(c, 5, "Финал в цвете: десктоп + мобила")
    c.setFillColor(INK)
    c.setFont(F, 11)
    c.drawString(28, H - 100, "06-final-desktop.svg (1920×4800) + 07-final-mobile.svg (390×6870) · те же блоки ПР-3+ПР-4 · палитра 4 · stroke 2.")
    # desktop color mock
    x, y, w, h = 28, H - 120, 430, 300
    c.setFillColor(PAPER)
    c.setStrokeColor(INK)
    c.setLineWidth(2)
    c.rect(x, y - h, w, h, stroke=1, fill=1)
    c.setFillColor(INK)
    c.rect(x, y - h + h - 34, w, 34, stroke=0, fill=1)
    c.setFillColor(PAPER)
    c.setFont(FB, 10)
    c.drawString(x + 8, y - 22, "samlib · финал десктоп 1920")
    # hero cream
    c.setFillColor(CREAM)
    c.setStrokeColor(INK)
    c.setLineWidth(2)
    c.rect(x + 8, y - 100, w - 16, 58, stroke=1, fill=1)
    c.setFillColor(ACCENT)
    c.rect(x + 8, y - 130, 90, 24, stroke=0, fill=1)
    c.setFillColor(PAPER)
    c.setFont(FB, 9)
    c.drawString(x + 30, y - 122, "Читать")
    # cards
    for i in range(3):
        c.setFillColor(PAPER)
        c.setStrokeColor(INK)
        c.setLineWidth(2)
        cw = (w - 16 - 16) / 3
        c.rect(x + 8 + i * (cw + 8), y - 190, cw, 52, stroke=1, fill=1)
    c.setFillColor(CREAM)
    c.rect(x + 8, y - 250, w - 16, 52, stroke=1, fill=1)
    c.setFillColor(ACCENT)
    c.rect(x + 8, y - 280, 120, 24, stroke=0, fill=1)
    c.setFillColor(INK)
    c.setFont(F, 8)
    c.drawString(x + 8, y - h + 8, "контент 1300 · x=310 · 12 колонок")
    # mobile color mock
    mx, mw, mh = 480, 150, 300
    c.setFillColor(PAPER)
    c.setStrokeColor(INK)
    c.setLineWidth(2)
    c.rect(mx, y - mh, mw, mh, stroke=1, fill=1)
    c.setFillColor(INK)
    c.rect(mx, y - mh + mh - 26, mw, 26, stroke=0, fill=1)
    c.setFillColor(PAPER)
    c.setFont(FB, 9)
    c.drawString(mx + 8, y - 20, "samlib · 390")
    c.setFillColor(CREAM)
    c.setStrokeColor(INK)
    c.setLineWidth(2)
    c.rect(mx + 8, y - 80, mw - 16, 46, stroke=1, fill=1)
    c.setFillColor(ACCENT)
    c.rect(mx + 8, y - 110, mw - 16, 24, stroke=0, fill=1)
    c.rect(mx + 8, y - 170, mw - 16, 52, stroke=1, fill=1)
    c.setFillColor(PAPER)
    c.rect(mx + 8, y - 200, mw - 16, 24, stroke=0, fill=1)
    c.setFillColor(INK)
    c.setFont(F, 8)
    c.drawString(mx + 8, y - mh + 8, "контент 358 · x=16 · 8 кол.")
    # palette + params
    px = 650
    c.setFillColor(INK)
    c.setFont(FB, 12)
    c.drawString(px, y - 60, "Палитра — ровно 4:")
    sw = [(INK, "#1A1A1A", "ink"), (PAPER, "#FFFFFF", "paper"),
          (CREAM, "#F5F0E8", "cream"), (ACCENT, "#C84B31", "accent")]
    sx = px
    for col, hexlabel, namelabel in sw:
        c.setFillColor(col)
        c.setStrokeColor(INK)
        c.setLineWidth(2)
        c.rect(sx, y - 115, 40, 40, stroke=1, fill=1)
        c.setFillColor(INK)
        c.setFont(F, 8)
        c.drawString(sx + 1, y - 128, hexlabel)
        c.drawString(sx + 1, y - 139, namelabel)
        sx += 48
    yy = y - 170
    yy = bullet(c, px, yy, "Все stroke-width = 2", size=10)
    yy = bullet(c, px, yy, "photo-treatment: brightness(1.02)", size=9)
    yy = bullet(c, px, yy, "contrast(1.05) saturate(0.9) warm", size=9)
    yy = bullet(c, px, yy, "Текст реальный: samlib, жанры,", size=9)
    yy = bullet(c, px, yy, "рейтинги, шаги, отзывы, FAQ", size=9)
    yy = bullet(c, px, yy, "ПР1 Космос -> бейджи (stroke 2)", size=9)
    yy = bullet(c, px, yy, "ПР2-5: тексты и сетки 1-в-1", size=9)
    footer(c)
    c.showPage()


def main():
    c = canvas.Canvas(str(OUT), pagesize=landscape(A4))
    c.setTitle("Практическая работа 6 — Презентация samlib.ru — Ляпунов Д.Д.")
    c.setAuthor("Ляпунов Д.Д.")
    slide1(c)
    slide2(c)
    slide3(c)
    slide4(c)
    slide5(c)
    c.save()
    shutil.copyfile(OUT, COPY)
    print(f"saved: {OUT}")
    print(f"saved: {COPY}")


if __name__ == "__main__":
    main()
