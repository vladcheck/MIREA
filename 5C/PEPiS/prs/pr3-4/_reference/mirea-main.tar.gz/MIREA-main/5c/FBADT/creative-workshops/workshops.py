"""Functions for managing master classes."""

from typing import List, Optional


class MasterClass:
    """Мастер-класс творческой мастерской."""

    def __init__(
        self,
        class_id: int,
        name: str,
        capacity: int,
        base_price: int,
        age_limit: int = 12,
    ) -> None:
        """Создать объект мастер-класса."""
        self.id = class_id
        self.name = name
        self.capacity = capacity
        self.base_price = base_price
        self.age_limit = age_limit

    def is_suitable_for(self, people_count: int) -> bool:
        """Проверить вместимость мастер-класса."""
        return self.capacity >= people_count

    @staticmethod
    def validate_capacity(capacity: int) -> bool:
        """Проверить корректность вместимости."""
        return capacity > 0

    def __str__(self) -> str:
        """Вернуть строковое представление."""
        return (
            f"{self.name}, {self.capacity} мест, "
            f"{self.base_price} руб., {self.age_limit}+"
        )


def add_class(
    classes: List[MasterClass],
    name: str,
    capacity: int,
    base_price: int,
    age_limit: int = 12,
) -> MasterClass:
    """Add a master class and return created object."""
    if not MasterClass.validate_capacity(capacity):
        raise ValueError("capacity must be positive")
    if base_price < 0:
        raise ValueError("base_price must be non-negative")
    new_id = max((item.id for item in classes), default=0) + 1
    item = MasterClass(new_id, name, capacity, base_price, age_limit)
    classes.append(item)
    return item


def find_class(
    classes: List[MasterClass],
    query: str,
) -> List[MasterClass]:
    """Find classes with query substring in the name."""
    result = []
    lowered = query.strip().lower()
    for item in classes:
        if lowered in item.name.lower():
            result.append(item)
    return result


def find_class_by_id(
    classes: List[MasterClass],
    class_id: int,
) -> Optional[MasterClass]:
    """Find class object by id or return None."""
    for item in classes:
        if item.id == class_id:
            return item
    return None


def check_capacity(
    classes: List[MasterClass],
    class_id: int,
    min_capacity: int,
) -> bool:
    """Return True if class capacity is enough."""
    item = find_class_by_id(classes, class_id)
    if item is None:
        raise KeyError(f"class {class_id} not found")
    return item.is_suitable_for(min_capacity)


def filter_classes_by_capacity(
    classes: List[MasterClass],
    min_capacity: int,
) -> List[MasterClass]:
    """Select classes with capacity not less than given."""
    return [item for item in classes if item.is_suitable_for(min_capacity)]


def sort_classes(classes: List[MasterClass]) -> List[MasterClass]:
    """Return classes ordered by capacity."""
    return sorted(classes, key=lambda item: item.capacity)


def get_classes_stats(classes: List[MasterClass]) -> dict:
    """Return total count and average capacity."""
    total = len(classes)
    if total == 0:
        return {"total": 0, "avg_capacity": 0.0}
    capacities = [item.capacity for item in classes]
    avg = sum(capacities) / total
    return {"total": total, "avg_capacity": round(avg, 2)}
