"""Load and save project data in JSON files."""

import json
from datetime import date
from typing import List

from bookings import Booking
from clients import Client, find_client_by_id
from workshops import MasterClass, find_class_by_id


def load_classes(filename: str) -> List[MasterClass]:
    """Load classes from JSON file."""
    try:
        with open(filename, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except FileNotFoundError:
        return []
    except json.JSONDecodeError as exc:
        raise ValueError(f"bad JSON in {filename}: {exc}")
    result = []
    for item in raw:
        result.append(
            MasterClass(
                class_id=int(item["id"]),
                name=str(item["name"]),
                capacity=int(item["capacity"]),
                base_price=int(item["base_price"]),
                age_limit=int(item.get("age_limit", 12)),
            )
        )
    return result


def save_classes(filename: str, classes: List[MasterClass]) -> None:
    """Save classes to JSON file."""
    raw = []
    for item in sorted(classes, key=lambda c: c.id):
        raw.append(
            {
                "id": item.id,
                "name": item.name,
                "capacity": item.capacity,
                "base_price": item.base_price,
                "age_limit": item.age_limit,
            }
        )
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(raw, f, ensure_ascii=False, indent=2)


def load_clients(filename: str) -> List[Client]:
    """Load clients from JSON file."""
    try:
        with open(filename, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except FileNotFoundError:
        return []
    except json.JSONDecodeError as exc:
        raise ValueError(f"bad JSON in {filename}: {exc}")
    result = []
    for item in raw:
        result.append(Client.from_data(item))
    return result


def save_clients(filename: str, clients: List[Client]) -> None:
    """Save clients to JSON file."""
    raw = []
    for item in sorted(clients, key=lambda c: c.id):
        raw.append(
            {
                "id": item.id,
                "name": item.name,
                "age": item.age,
                "is_student": item.is_student,
            }
        )
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(raw, f, ensure_ascii=False, indent=2)


def load_bookings(
    filename: str,
    classes: List[MasterClass],
    clients: List[Client],
) -> List[Booking]:
    """Load bookings from JSON file."""
    try:
        with open(filename, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except FileNotFoundError:
        return []
    except json.JSONDecodeError as exc:
        raise ValueError(f"bad JSON in {filename}: {exc}")
    result = []
    for item in raw:
        workshop = find_class_by_id(classes, int(item["class_id"]))
        client = None
        if "client_id" in item:
            client = find_client_by_id(clients, int(item["client_id"]))
        if workshop is None or client is None:
            continue
        bdate = date.fromisoformat(str(item["booking_date"]))
        booking = Booking(
            booking_id=int(item["id"]),
            workshop=workshop,
            booking_date=bdate,
            client=client,
            is_cancelled=bool(item.get("is_cancelled", False)),
        )
        result.append(booking)
    return result


def save_bookings(filename: str, bookings: List[Booking]) -> None:
    """Save bookings to JSON file."""
    raw = []
    for item in bookings:
        bdate = item.booking_date
        if isinstance(bdate, date):
            bdate_str = bdate.isoformat()
        else:
            bdate_str = str(bdate)
        raw.append(
            {
                "id": int(item.id),
                "class_id": int(item.workshop.id),
                "booking_date": bdate_str,
                "client_id": int(item.client.id),
                "is_cancelled": bool(item.is_cancelled),
            }
        )
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(raw, f, ensure_ascii=False, indent=2)
