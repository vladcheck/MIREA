"""Check PR3 samlib SVG params. Usage: python3 scripts/check_svg_params.py --pr3"""
import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
IA = ROOT / "figma-build-PR3" / "00-IA.svg"
HERO = ROOT / "figma-build-PR3" / "01-hero-1920.svg"
POPUPS = ROOT / "figma-build-PR3" / "02-popups.svg"
BLOCKS = ROOT / "figma-build-PR4" / "03-blocks.svg"
FOOT = ROOT / "figma-build-PR4" / "04-footer-popups.svg"
MOBILE = ROOT / "figma-build-PR5" / "05-mobile.svg"

checks = []


def check(name, ok, detail=""):
    print(f"{'PASS' if ok else 'FAIL'}: {name}" + (f" — {detail}" if detail else ""))
    checks.append(bool(ok))


def read(p):
    if not p.exists():
        return None
    return p.read_text(encoding="utf-8")


def rects(s):
    out = []
    for m in re.finditer(r"<rect\b([^>]*)/?>", s):
        attrs = m.group(1)
        def num(n):
            mm = re.search(rf'{n}\s*=\s*"([\d.]+)"', attrs)
            return float(mm.group(1)) if mm else None
        out.append({"x": num("x") or 0, "y": num("y") or 0,
                    "w": num("width") or 0, "h": num("height") or 0,
                    "raw": attrs})
    return out


def check_pr3():
    checks.clear()
    ia = read(IA)
    hero = read(HERO)
    pop = read(POPUPS)
    check("00-IA.svg exists", ia is not None)
    check("01-hero-1920.svg exists", hero is not None)
    check("02-popups.svg exists", pop is not None)
    if ia is None or hero is None or pop is None:
        return False

    # --- 00-IA: regex width/height ---
    check("IA width=1600 (regex)", re.search(r'width\s*=\s*"1600"', ia) is not None)
    check("IA height=1000 (regex)", re.search(r'height\s*=\s*"1000"', ia) is not None)
    for t in ["Каталог", "Новинки", "Рейтинги", "Как", "опубликоваться", "Подписка"]:
        check(f"IA L1 has '{t}'", t in ia)
    for t in ["Жанры", "Авторы", "Конкурсы", "Читать", "Подписаться"]:
        check(f"IA L2 has '{t}'", t in ia)
    for t in ["Подписка", "Публикация", "Подтверждение"]:
        check(f"IA L3 has '{t}'", t in ia)
    lines = re.findall(r"<line\b[^>]*>", ia)
    check("IA connectors >=10 lines", len(lines) >= 10, f"found={len(lines)}")
    check("IA lines stroke #888", re.search(r"<line\b[^>]*stroke\s*=\s*\"#888", ia) is not None)
    check("IA lines stroke-width 2", re.search(r"<line\b[^>]*stroke-width\s*=\s*\"2\"", ia) is not None)

    # --- 01-hero: regex width/height/header/hero ---
    check("hero width=1920 (regex)", re.search(r'width\s*=\s*"1920"', hero) is not None)
    check("hero height=3000 (regex)", re.search(r'height\s*=\s*"3000"', hero) is not None)
    check("hero content x=310 width=1300 (regex)",
          re.search(r'x\s*=\s*"310"', hero) is not None and re.search(r'width\s*=\s*"1300"', hero) is not None)
    check("hero grid comment grid:12 gutter:20-30",
          "grid:12" in hero and "gutter:20-30" in hero)
    check("hero header height=110 (regex)", re.search(r'height\s*=\s*"110"', hero) is not None)
    check("hero hero-block height=700 (regex)", re.search(r'height\s*=\s*"700"', hero) is not None)
    check("hero logo samlib", "samlib" in hero.lower())
    for t in ["Каталог", "Новинки", "Рейтинги", "Как опубликоваться", "Подписка"]:
        check(f"hero menu has '{t}'", t in hero)
    check("hero has поиск", "поиск" in hero.lower())
    check("hero title", "Читайте и публикуйтесь за минуты" in hero)
    check("hero button Читать", "Читать" in hero)
    check("hero button Опубликовать", "Опубликовать" in hero)
    check("hero grey oval (ellipse)", "<ellipse" in hero)
    check("hero trust 80k", "80k" in hero)
    check("hero trust 1M", "1M" in hero)
    check("hero grey fill #C4C4C4", "#C4C4C4" in hero)
    check("hero grey fill #E5E5E5", "#E5E5E5" in hero)
    check("hero stroke #888", "#888" in hero)
    check("hero stroke-width 2", 'stroke-width="2"' in hero)

    # --- 02-popups: 3 rect 480x360 ---
    n_popup = len(re.findall(r'width\s*=\s*"480"\s+height\s*=\s*"360"', pop))
    if n_popup < 3:
        n_popup = len(re.findall(r'<rect\b[^>]*width="480"[^>]*height="360"', pop))
    check("popups 3x rect 480x360", n_popup >= 3, f"found={n_popup}")
    for t in ["Подписка", "Публикация", "Подтверждение"]:
        check(f"popup has '{t}'", t in pop)
    check("popup Подписка: email", "email" in pop.lower())
    check("popup Подписка: галочка", "галочка" in pop.lower() or "✓" in pop)
    check("popup Публикация: название", "название" in pop.lower())
    check("popup Публикация: файл", "файл" in pop.lower())
    check("popups grey fills", "#C4C4C4" in pop and "#E5E5E5" in pop)

    # --- visual self-check: сетка/отступы/буквы/налезания ---
    # gaps in hero: header(0+110)=hero top, hero bottom=810, sections sequence
    check("visual hero: header(110)->hero(700) стык",
          'y="0" width="1920" height="110"' in hero and 'y="110" width="1920" height="700"' in hero)
    seq = [(860, 400), (1300, 400), (1740, 400), (2180, 300), (2520, 380)]
    ok_gaps = True
    prev_end = 810
    for y, h in seq:
        if y - prev_end < 20:
            ok_gaps = False
        prev_end = y + h
    check("visual hero: отступы секций >=20", ok_gaps, f"end={prev_end}<=3000")
    check("visual hero: низ <=3000", prev_end <= 3000, f"end={prev_end}")
    # IA rows non-overlap
    check("visual IA: ряды без налезания (90/250/490/720)",
          all(s in ia for s in ['y="90"', 'y="250"', 'y="490"', 'y="720"']))
    # popups x-intervals non-overlap
    check("visual popups: 3 колонки без налезания",
          all(s in pop for s in ['x="40" y="70"', 'x="560" y="70"', 'x="1080" y="70"']))
    # буквы: min font-size >=12 in all files
    def min_font(s):
        sizes = [int(x) for x in re.findall(r'font-size\s*=\s*"(\d+)', s)]
        return min(sizes) if sizes else 0
    check("visual IA: буквы >=12px", min_font(ia) >= 12, f"min={min_font(ia)}")
    check("visual hero: буквы >=12px", min_font(hero) >= 12, f"min={min_font(hero)}")
    check("visual popups: буквы >=12px", min_font(pop) >= 12, f"min={min_font(pop)}")

    ok = all(checks)
    print("RESULT:", "ALL PASS" if ok else "FAILURES PRESENT")
    return ok


def check_pr4():
    checks.clear()
    blocks = read(BLOCKS)
    foot = read(FOOT)
    check("03-blocks.svg exists", blocks is not None)
    check("04-footer-popups.svg exists", foot is not None)
    if blocks is None or foot is None:
        return False

    # --- 03-blocks: canvas + content guide ---
    check("blocks width=1920 (regex)", re.search(r'width\s*=\s*"1920"', blocks) is not None)
    check("blocks height=3300 (regex)", re.search(r'height\s*=\s*"3300"', blocks) is not None)
    check("blocks content x=310 width=1300 (regex)",
          re.search(r'x\s*=\s*"310"', blocks) is not None and re.search(r'width\s*=\s*"1300"', blocks) is not None)
    check("blocks grid comment grid:12 gutter:20-30",
          "grid:12" in blocks and "gutter:20-30" in blocks)

    # --- 03-blocks: >=5 blocks ---
    n_blocks = len(re.findall(r'data-block="', blocks))
    check("blocks >=5 sections (data-block)", n_blocks >= 5, f"found={n_blocks}")
    for t in ["Каталог", "Новинки", "Рейтинги", "опубликоваться", "Отзывы", "Подписка", "FAQ"]:
        check(f"blocks has '{t}'", t in blocks)

    # --- block content details ---
    for g in ["Фантастика", "Фэнтези", "Фанфики", "Детективы", "Поэзия", "Публицистика"]:
        check(f"catalog 3x2 has '{g}'", g in blocks)
    check("new+ratings stars present", blocks.count("★") >= 8, f"stars={blocks.count('★')}")
    for s in ["Шаг 1", "Шаг 2", "Шаг 3"]:
        check(f"howto has '{s}'", s in blocks)
    for n in ["Сергей", "Анна", "Мария"]:
        check(f"reviews has '{n}'", n in blocks)
    check("subscribe field email", "email" in blocks.lower())
    check("subscribe button", "Подписаться" in blocks)
    n_faq = len(re.findall(r"В:", blocks))
    check("FAQ 4 questions (В:)", n_faq >= 4, f"found={n_faq}")
    n_cta_big = len(re.findall(r'width="240" height="56"', blocks))
    check("CTA identical 240x56 >=2", n_cta_big >= 2, f"found={n_cta_big}")
    n_cta_small = len(re.findall(r'width="200" height="44"', blocks))
    check("CTA identical 200x44 >=6", n_cta_small >= 6, f"found={n_cta_small}")

    # --- grey palette both files ---
    for name, s in [("blocks", blocks), ("footer", foot)]:
        check(f"{name} grey fill #C4C4C4", "#C4C4C4" in s)
        check(f"{name} grey fill #E5E5E5", "#E5E5E5" in s)
        check(f"{name} stroke #888", "#888" in s)
        check(f"{name} stroke-width 2", 'stroke-width="2"' in s)

    # --- 04-footer: contacts + nav ---
    check("footer contacts samlib", "samlib" in foot.lower() and "контакты" in foot.lower())
    check("footer email info@samlib.ru", "info@samlib.ru" in foot)
    for t in ["Каталог", "Новинки", "Рейтинги", "Подписка"]:
        check(f"footer nav has '{t}'", t in foot)
    check("footer rect present", 'data-footer=' in foot)

    # --- 04-footer: 3 popups duplicates 480x360 ---
    n_popup = len(re.findall(r'<rect\b[^>]*width="480"[^>]*height="360"', foot))
    check("footer popups 3x rect 480x360", n_popup >= 3, f"found={n_popup}")
    for t in ["Подписка", "Публикация", "Подтверждение"]:
        check(f"footer popup has '{t}'", t in foot)
    check("footer popup Подписка: email", "email" in foot.lower())
    check("footer popup Подписка: галочка", "галочка" in foot.lower() or "✓" in foot)
    check("footer popup Публикация: название", "название" in foot.lower())
    check("footer popup Публикация: файл", "файл" in foot.lower())

    # --- visual self-check ---
    seq = [(120, 560), (720, 520), (1280, 420), (1740, 440), (2220, 360), (2620, 560)]
    ok_gaps = True
    prev_end = 80
    for y, h in seq:
        if y - prev_end < 20:
            ok_gaps = False
        prev_end = y + h
    check("visual blocks: отступы секций >=20", ok_gaps, f"end={prev_end}<=3300")
    check("visual blocks: низ <=3300", prev_end <= 3300, f"end={prev_end}")
    check("visual footer: 3 колонки попапов без налезания",
          all(s in foot for s in ['x="40" y="470"', 'x="560" y="470"', 'x="1080" y="470"']))

    def min_font(s):
        sizes = [int(x) for x in re.findall(r'font-size\s*=\s*"(\d+)', s)]
        return min(sizes) if sizes else 0
    check("visual blocks: буквы >=12px", min_font(blocks) >= 12, f"min={min_font(blocks)}")
    check("visual footer: буквы >=12px", min_font(foot) >= 12, f"min={min_font(foot)}")

    ok = all(checks)
    print("RESULT:", "ALL PASS" if ok else "FAILURES PRESENT")
    return ok


def check_pr5():
    checks.clear()
    m = read(MOBILE)
    check("05-mobile.svg exists", m is not None)
    if m is None:
        return False

    # --- frame iPhone 14: width=390, viewport 844 ---
    check("mobile width=390 (regex)", re.search(r'width\s*=\s*"390"', m) is not None)
    check("mobile viewport 844 mentioned", "844" in m)
    m_root_h = re.search(r'<svg\b[^>]*height\s*=\s*"(\d+)"', m)
    root_h = int(m_root_h.group(1)) if m_root_h else 0
    check("mobile tall scroll height>=4000 (1 column)", root_h >= 4000, f"height={root_h}")

    # --- grid 8 / margin 16 / gutter 10, content x=16 w=358 ---
    check("mobile grid comment grid:8 margin:16 gutter:10",
          "grid:8" in m and "margin:16" in m and "gutter:10" in m)
    check("mobile content x=16 width=358 (regex)",
          re.search(r'x\s*=\s*"16"', m) is not None and re.search(r'width\s*=\s*"358"', m) is not None)
    n_cols = len(re.findall(r'width="36"', m))
    check("mobile 8 columns w=36", n_cols >= 8, f"found={n_cols}")

    # --- header 64: logo + burger + CTA ---
    check("mobile header height=64 (regex)", re.search(r'height\s*=\s*"64"', m) is not None)
    check("mobile header rect y=0 w=390 h=64",
          'y="0" width="390" height="64"' in m)
    check("mobile header logo samlib", "samlib" in m.lower())
    check("mobile header burger", "≡" in m or "бургер" in m.lower())

    # --- all PR3+PR4 blocks vertically, 1 column ---
    n_blocks = len(re.findall(r'data-block="', m))
    check("mobile >=7 sections (data-block)", n_blocks >= 7, f"found={n_blocks}")
    col_ok = True
    for mm in re.finditer(r"<rect\b[^>]*data-block=\"[^\"]*\"[^>]*>", m):
        attrs = mm.group(0)
        if 'x="16"' not in attrs or 'width="358"' not in attrs:
            col_ok = False
    check("mobile sections single column x=16 w=358", col_ok)
    for t in ["Каталог", "Новинки", "Рейтинги", "Как опубликоваться", "Подписка",
              "Отзывы", "FAQ", "контакты"]:
        check(f"mobile has block '{t}'", t in m)

    # --- full content: nothing thrown away ---
    for t in ["Читайте и публикуйтесь", "за минуты", "Читать", "Опубликовать",
              "80k", "1M", "поиск", "Войти",
              "Фантастика", "Фэнтези", "Фанфики", "Детективы", "Поэзия", "Публицистика",
              "Читать подборку", "Жанры", "Авторы", "Конкурсы",
              "Звёздный путь", "Тень башни", "Город дождей", "Летний конкурс",
              "Топ недели", "Рейтинги недели",
              "Шаг 1", "Шаг 2", "Шаг 3",
              "Зарегистрируйтесь", "Загрузите файл", "Опубликуйте",
              "Сергей", "Анна", "Мария",
              "email", "Подписаться", "галочка", "✓",
              "info@samlib.ru", "Подтверждение", "название", "файл"]:
        check(f"mobile content has '{t}'", t in m)
    check("mobile stars >=8", m.count("★") >= 8, f"stars={m.count('★')}")
    n_faq = len(re.findall(r"В:", m))
    check("mobile FAQ 4 questions (В:)", n_faq >= 4, f"found={n_faq}")

    # --- touch44: buttons/fields height>=44 ---
    rs = rects(m)
    btns = [r for r in rs if r["w"] >= 150 and r["h"] > 0]
    min_h = min([r["h"] for r in btns]) if btns else 0
    check("mobile touch44: wide rects h>=44", len(btns) >= 8 and all(r["h"] >= 44 for r in btns),
          f"n={len(btns)} min_h={min_h}")
    check("mobile CTA 240x56 present", 'width="240" height="56"' in m)
    check("mobile CTA 200x44 present", 'width="200" height="44"' in m)

    # --- grey palette ---
    check("mobile grey fill #C4C4C4", "#C4C4C4" in m)
    check("mobile grey fill #E5E5E5", "#E5E5E5" in m)
    check("mobile stroke #888", "#888" in m)
    check("mobile stroke-width 2", 'stroke-width="2"' in m)

    # --- footer + mobile popups full width ---
    check("mobile footer contacts", 'data-footer=' in m and "info@samlib.ru" in m)
    n_pop = len(re.findall(r'data-popup="', m))
    check("mobile 3 popups (data-popup)", n_pop >= 3, f"found={n_pop}")

    # --- visual self-check: gaps>=12, bottom<=H, fonts>=12 ---
    seq = [(80, 300), (396, 680), (1092, 1020), (2128, 740), (2884, 660),
           (3560, 720), (4296, 380), (4692, 620), (5328, 420),
           (5796, 340), (6152, 330), (6498, 310)]
    ok_gaps = True
    prev_end = 64
    for y, h in seq:
        if y - prev_end < 12:
            ok_gaps = False
        prev_end = y + h
    check("mobile visual: отступы секций >=12", ok_gaps, f"end={prev_end}<={root_h}")
    check("mobile visual: низ <=H", prev_end <= root_h, f"end={prev_end} H={root_h}")
    check("mobile visual: секции на местах y",
          all(s in m for s in ['y="80"', 'y="396"', 'y="1092"', 'y="2128"',
                               'y="2884"', 'y="3560"', 'y="4296"', 'y="4692"', 'y="5328"']))
    sizes = [int(x) for x in re.findall(r'font-size\s*=\s*"(\d+)', m)]
    check("mobile visual: буквы >=12px", bool(sizes) and min(sizes) >= 12,
          f"min={min(sizes) if sizes else 0}")

    ok = all(checks)
    print("RESULT:", "ALL PASS" if ok else "FAILURES PRESENT")
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pr3", action="store_true", help="check PR3 samlib SVGs")
    ap.add_argument("--pr4", action="store_true", help="check PR4 samlib SVGs")
    ap.add_argument("--pr5", action="store_true", help="check PR5 mobile samlib SVG")
    args = ap.parse_args()
    if args.pr3:
        ok = check_pr3()
        assert ok, "check_svg_params --pr3 FAILED"
    elif args.pr4:
        ok = check_pr4()
        assert ok, "check_svg_params --pr4 FAILED"
    elif args.pr5:
        ok = check_pr5()
        assert ok, "check_svg_params --pr5 FAILED"
    else:
        print("Usage: python3 scripts/check_svg_params.py --pr3|--pr4|--pr5")
        sys.exit(2)


if __name__ == "__main__":
    main()
