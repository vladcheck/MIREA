"""Tests for Client class."""

from clients import (
    Client,
    add_client,
    find_client,
    find_client_by_id,
)


def test_client_creation():
    item = Client(1, "Иван Петров", 19, False)
    assert item.id == 1
    assert item.name == "Иван Петров"
    assert item.age == 19
    assert item.is_student is False


def test_client_str():
    item = Client(1, "Иван Петров", 19, False)
    assert "Иван Петров" in str(item)
    assert "19" in str(item)
    student = Client(2, "Анна Смирнова", 20, True)
    assert "студент" in str(student).lower()


def test_client_from_data():
    item = Client.from_data(
        {"id": 1, "name": "Иван Петров", "age": 19}
    )
    assert item.id == 1
    assert item.name == "Иван Петров"
    assert item.is_student is False
    student = Client.from_data(
        {"id": 2, "name": "Анна", "age": 20, "is_student": True}
    )
    assert student.is_student is True


def test_add_client():
    clients = []
    item = add_client(clients, "Иван Петров", 19, False)
    assert item.id == 1
    assert clients == [item]


def test_find_client():
    clients = []
    add_client(clients, "Иван Петров", 19, False)
    add_client(clients, "Анна Смирнова", 20, True)
    found = find_client(clients, "иван")
    assert len(found) == 1
    assert found[0].name == "Иван Петров"


def test_find_client_by_id():
    clients = []
    add_client(clients, "Иван Петров", 19, False)
    item = find_client_by_id(clients, 1)
    assert item is not None
    assert item.name == "Иван Петров"
    assert find_client_by_id(clients, 99) is None
