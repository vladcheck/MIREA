"""ПР4: сборка итогового PDF для портала (samlib, связный цикл ПР1-ПР6).
Cover (reportlab, DejaVu) + merge exports/03-blocks.pdf + exports/04-footer.pdf.
Выход: «Практическая работа 4 — Вайрфрейм остальных блоков (samlib).pdf»
"""
from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
import fitz

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "Практическая работа 4 — Вайрфрейм остальных блоков (samlib).pdf"
B3 = ROOT / "exports/03-blocks.pdf"
B4 = ROOT / "exports/04-footer.pdf"

DEJAVU = "/Users/d.d.lyapunov/Library/Python/3.9/lib/python/site-packages/matplotlib/mpl-data/fonts/ttf/DejaVuSans.ttf"
DEJAVU_B = "/Users/d.d.lyapunov/Library/Python/3.9/lib/python/site-packages/matplotlib/mpl-data/fonts/ttf/DejaVuSans-Bold.ttf"
pdfmetrics.registerFont(TTFont("Body", DEJAVU))
pdfmetrics.registerFont(TTFont("BodyB", DEJAVU_B))
F, FB = "Body", "BodyB"
INK = HexColor("#1A1A1A"); GREY = HexColor("#888888"); LIGHT = HexColor("#F2F2F2")
W, H = A4  # 595x842

def cover(path):
    c = canvas.Canvas(str(path), pagesize=A4)
    c.setFillColor(LIGHT); c.rect(0,0,W,H,stroke=0,fill=1)
    c.setFillColor(INK)
    c.setFont(FB, 11); c.drawString(40, H-40, "МИРЭА · ИПТИП · Компьютерный дизайн · samlib.ru · 2026")
    c.setFont(FB, 20); c.drawString(40, H-75, "Практическая работа 4")
    c.setFont(FB, 15); c.drawString(40, H-98, "Вайрфрейм остальных блоков (samlib.ru)")
    c.setFont(F, 11); c.drawString(40, H-118, "Выполнил: Ляпунов Д. Д. · Журнал «Самиздат» — читать / подписаться / опубликовать")
    y = H-150
    def h2(t):
        nonlocal y
        c.setFont(FB, 12); c.drawString(40, y, t); y-=18
    def p(t, size=10, indent=40):
        nonlocal y
        c.setFont(F, size)
        # ручной перенос по ~95 символов
        import textwrap
        for line in textwrap.wrap(t, width=95):
            c.drawString(indent, y, line); y-=14
        y-=4
    h2("1. Цель (по методичке)")
    p("Разработать вайрфрейм остальных блоков лендинга с учётом правил гештальт-композиции. Всех блоков вместе с главным экраном и футером — не менее 5; нарисовать всплывающие окна; сдать в PDF.")
    h2("2. Связность цикла ПР1–ПР6 (единый проект samlib.ru)")
    p("ПР1 «Космос»: набор иконок-контуров — приём замкнутости/иконки в кругах переиспользован в карточках Каталога (Блок 2).")
    p("ПР2: персоны Артём (19, читатель) и Софья (22, автор) + 6 JTBD — Блок 3 (новинки/подписка для Артёма), Блок 4 (3 шага публикации для Софьи).")
    p("ПР3: ИА 3 уровня + hero 1920 (Блок 1: header 110, hero 700, контент 1300, gutter 24, 12 колонок) — header-меню Каталог/Новинки/Рейтинги/Как опубликоваться/Подписка дублируется в Блоках 2–8 и футере.")
    p("ПР4 (эта работа): Блоки 2–7 + Блок 8 футер + 3 попапа 480x360 (дубли ПР3). ПР5: та же структура — 1 колонка 390. ПР6: финал в 4 цветах по тем же блокам.")
    h2("3. Состав (8 блоков: требование >=5 закрыто)")
    p("Блок 1 — Первый экран/hero (ПР3, 01-hero). Блок 2 — Каталог жанров 3x2 (6 карточек). Блок 3 — Новинки и рейтинги (список 4 + Топ недели). Блок 4 — Как опубликоваться (3 шага + CTA). Блок 5 — Отзывы (Сергей/Анна/Мария). Блок 6 — Подписка (email + галочка). Блок 7 — FAQ (4 В/О). Блок 8 — Футер (контакты info@samlib.ru + навигация). Попапы: Подписка / Публикация / Подтверждение 480x360.")
    h2("4. Параметры (наследованы из ПР3)")
    p("Фрейм 1920x3300, контент x=310 w=1300 по центру, 12 колонок, gutter 24 (допуск 20–30), header 80-полоса/110 в hero, всё серое #C4C4C4/#E5E5E5, обводка #888 w2, шрифты >=14px, текст реальный без lorem, графика — геометрия (прямоугольники/овалы/круги/векторные звёзды). Лист попапов 1600 — как в ПР3 02-popups.")
    h2("5. Гештальт (подписан в макете у каждого блока)")
    p("Б2 — общая область + замкнутость (карточки в рамках). Б3 — близость + продолжение (строки списком). Б4 — схожесть (3 шага). Б5 — схожесть + симметрия (3 карточки). Б6 — близость (поле+кнопка). Б7 — общая область (стопка). Б8/попапы — общая область + замкнутость + общая судьба.")
    h2("6. Что внутри PDF")
    p("Стр. 2 — остальные блоки 1920x3300 (Блоки 2–7). Стр. 3 — футер + 3 попапа 480x360 (Блок 8). Исходники: figma-build-PR4/03-blocks.svg, 04-footer-popups.svg. Проверка: scripts/check_svg_params.py --pr4 = ALL PASS; PyMuPDF null-glyphs = 0.")
    c.showPage(); c.save()

tmp = ROOT/"exports/_pr4_cover.pdf"
cover(tmp)
# merge
out = fitz.open()
for f in [tmp, B3, B4]:
    d = fitz.open(f)
    out.insert_pdf(d); d.close()
out.save(OUT); out.close()
tmp.unlink()
print("saved", OUT, OUT.stat().st_size)
# verify
d = fitz.open(OUT)
print("pages", len(d))
for i,pg in enumerate(d):
    t = pg.get_text()
    print(f"p{i+1} rect={pg.rect} nulls={t.count(chr(0))} chars={len(t)}")
d.close()
