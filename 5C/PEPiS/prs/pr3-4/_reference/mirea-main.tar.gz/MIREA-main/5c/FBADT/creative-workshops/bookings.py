"""Booking class and functions, PR1 scenario preserved."""
from datetime import date
from typing import List, Optional

from clients import Client
from workshops import MasterClass


class Booking:
    """Запись клиента на мастер-класс."""

    def __init__(
        self,
        booking_id: int,
        workshop: MasterClass,
        booking_date: date,
        client: Client,
        is_cancelled: bool = False,
    ) -> None:
        """Создать объект бронирования."""
        self.id = booking_id
        self.workshop = workshop
        self.booking_date = booking_date
        self.client = client
        self.is_cancelled = is_cancelled

    def cancel(self) -> None:
        """Отменить бронирование."""
        self.is_cancelled = True

    def __str__(self) -> str:
        """Вернуть строковое представление бронирования."""
        base = (
            f"№{self.id}: {self.workshop.name} — "
            f"{self.booking_date} ({self.client.name})"
        )
        if self.is_cancelled:
            return base + ", отменено"
        return base


def get_availability_status(free_seats: int, is_open: bool) -> str:
    """Return text booking status (PR1 function)."""
    if is_open and free_seats > 0:
        return "Запись открыта"
    if is_open and free_seats <= 0:
        return "Мест нет, запись в лист ожидания"
    return "Запись закрыта"


def calculate_price(
    base_price_str: str,
    is_weekend: bool,
    is_student: bool,
) -> float:
    """Calculate price with weekend markup and student discount."""
    base_price = int(base_price_str)
    if is_weekend:
        price = base_price * 1.2
    else:
        price = float(base_price)
    if is_student:
        price = price * 0.85
    return price


def check_age_limit(client_age_str: str, age_limit: int = 12) -> str:
    """Check age limit, default 12+ as in PR1."""
    age = int(client_age_str)
    if age >= age_limit:
        return "Допущен"
    return f"Не допущен: мастер-класс {age_limit}+"


def format_booking(
    workshop: str,
    master_class: str,
    class_date: date,
    status: str,
    price: float,
    age_result: str,
) -> str:
    """Format booking confirmation (PR1 function)."""
    total = str(round(price)) + " руб."
    if status == "Запись открыта" and age_result == "Допущен":
        verdict = "Бронирование подтверждено"
    else:
        verdict = "Бронирование невозможно: " + status + ", "
        verdict += age_result
    return (
        "Мастерская: " + workshop + "\n"
        "Мастер-класс: " + master_class + "\n"
        "Дата: " + str(class_date) + "\n"
        "Статус записи: " + status + "\n"
        "Возраст: " + age_result + "\n"
        "Итого: " + total + "\n"
        + verdict
    )


def is_slot_available(
    bookings: List[Booking],
    workshop: MasterClass,
    booking_date: date,
) -> bool:
    """Return False if workshop is booked for the date."""
    if isinstance(booking_date, date):
        target = booking_date.isoformat()
    else:
        target = str(booking_date)
    for item in bookings:
        if item.is_cancelled:
            continue
        item_date = item.booking_date
        if isinstance(item_date, date):
            item_date_str = item_date.isoformat()
        else:
            item_date_str = str(item_date)
        if item.workshop.id == workshop.id and item_date_str == target:
            return False
    return True


def create_booking(
    bookings: List[Booking],
    workshop: MasterClass,
    booking_date: date,
    client: Client,
) -> Optional[Booking]:
    """Create booking if the slot is free, else None."""
    if not is_slot_available(bookings, workshop, booking_date):
        return None
    new_id = max((item.id for item in bookings), default=0) + 1
    record = Booking(new_id, workshop, booking_date, client)
    bookings.append(record)
    return record


def cancel_booking(
    bookings: List[Booking],
    booking_id: int,
) -> bool:
    """Cancel booking by id, keep object in list."""
    for item in bookings:
        if item.id == booking_id:
            item.cancel()
            return True
    return False


def get_booking_status(
    bookings: List[Booking],
    workshop: MasterClass,
    booking_date: date,
    is_open: bool = True,
) -> str:
    """Form availability message for workshop and date."""
    if is_slot_available(bookings, workshop, booking_date):
        free = 1
    else:
        free = 0
    return get_availability_status(free, is_open)


def get_booking_stats(
    bookings: List[Booking],
    classes: List[MasterClass],
) -> dict:
    """Count bookings total and per class."""
    named: dict[str, int] = {}
    for item in bookings:
        name = item.workshop.name
        named[name] = named.get(name, 0) + 1
    return {"total": len(bookings), "per_class": named}
