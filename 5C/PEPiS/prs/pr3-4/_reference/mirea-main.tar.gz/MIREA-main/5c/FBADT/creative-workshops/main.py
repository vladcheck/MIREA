"""Entry point: console menu of creative workshops."""

import os
from datetime import date
from typing import List

from bookings import (
    Booking,
    calculate_price,
    cancel_booking,
    check_age_limit,
    create_booking,
    format_booking,
    get_availability_status,
    get_booking_stats,
    get_booking_status,
    is_slot_available,
)
from clients import Client, find_client_by_id
from storage import (
    load_bookings,
    load_classes,
    load_clients,
    save_bookings,
    save_classes,
    save_clients,
)
from utils import input_date, input_int
from workshops import (
    MasterClass,
    check_capacity,
    filter_classes_by_capacity,
    find_class,
    find_class_by_id,
    get_classes_stats,
    sort_classes,
)

WORKSHOP_NAME = "Гончарная мастерская «Терра»"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CLASSES_FILE = os.path.join(BASE_DIR, "data", "classes.json")
CLIENTS_FILE = os.path.join(BASE_DIR, "data", "clients.json")
BOOKINGS_FILE = os.path.join(BASE_DIR, "data", "bookings.json")


def show_classes(classes: List[MasterClass]) -> None:
    """Print classes as a table."""
    if not classes:
        print("Мастер-классов пока нет.")
        return
    print("ID | Название | Мест | Цена | Возраст")
    for item in sort_classes(classes):
        print(f"{item.id} | {item}")


def show_clients(clients: List[Client]) -> None:
    """Print clients with names and ages."""
    if not clients:
        print("Клиентов пока нет.")
        return
    print("ID | Клиент")
    for item in sorted(clients, key=lambda c: c.id):
        print(f"{item.id} | {item}")


def show_bookings(bookings: List[Booking]) -> None:
    """Print bookings with class names and dates."""
    if not bookings:
        print("Бронирований пока нет.")
        return
    for item in bookings:
        print(item)


def count_booked(
    bookings: List[Booking],
    class_id: int,
    day: date,
) -> int:
    """Count active bookings for class and date."""
    total = 0
    target = day.isoformat()
    for item in bookings:
        if item.is_cancelled:
            continue
        bdate = item.booking_date
        if isinstance(bdate, date):
            bdate_str = bdate.isoformat()
        else:
            bdate_str = str(bdate)
        if item.workshop.id == class_id and bdate_str == target:
            total += 1
    return total


def create_new_booking(
    bookings: List[Booking],
    classes: List[MasterClass],
    clients: List[Client],
) -> None:
    """Create booking linking MasterClass and Client objects."""
    cid = input_int("ID мастер-класса: ")
    workshop = find_class_by_id(classes, cid)
    if workshop is None:
        print("Мастер-класс не найден.")
        return
    uid = input_int("ID клиента: ")
    client = find_client_by_id(clients, uid)
    if client is None:
        print("Клиент не найден.")
        return
    day = input_date("Дата (ДД.ММ.ГГГГ): ")
    if not is_slot_available(bookings, workshop, day):
        print("Место уже занято")
        return
    try:
        age_res = check_age_limit(str(client.age), workshop.age_limit)
    except ValueError:
        print("Возраст — целое число.")
        return
    is_weekend = day.weekday() >= 5
    price = calculate_price(
        str(workshop.base_price), is_weekend, client.is_student
    )
    free = workshop.capacity - count_booked(bookings, workshop.id, day)
    status = get_availability_status(free, True)
    record = create_booking(bookings, workshop, day, client)
    if record is None:
        print("Место уже занято")
        return
    print(f"Создано бронирование №{record.id}")
    print(
        format_booking(
            WORKSHOP_NAME,
            workshop.name,
            day,
            status,
            price,
            age_res,
        )
    )


def main() -> None:
    """Run menu loop and call project functions."""
    try:
        classes = load_classes(CLASSES_FILE)
        clients = load_clients(CLIENTS_FILE)
        bookings = load_bookings(BOOKINGS_FILE, classes, clients)
    except ValueError as exc:
        print(f"Ошибка данных: {exc}")
        classes, clients, bookings = [], [], []
    is_open = True
    while True:
        print("=== Творческие мастерские ===")
        print("1. Показать мастер-классы")
        print("2. Найти мастер-класс по названию")
        print("3. Проверить вместимость")
        print("4. Проверить доступность на дату")
        print("5. Забронировать место")
        print("6. Отменить бронирование")
        print("7. Показать бронирования")
        print("8. Показать клиентов")
        print("0. Выход")
        try:
            choice = input("Выберите действие: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nВыход.")
            break
        try:
            if choice == "1":
                show_classes(classes)
            elif choice == "2":
                query = input("Подстрока названия: ")
                found = find_class(classes, query)
                show_classes(found)
            elif choice == "3":
                cid = input_int("ID мастер-класса: ")
                need = input_int("Нужно мест: ")
                ok = check_capacity(classes, cid, need)
                if ok:
                    print("Мест хватает")
                else:
                    print("Мест не хватает")
            elif choice == "4":
                cid = input_int("ID мастер-класса: ")
                day = input_date("Дата (ДД.ММ.ГГГГ): ")
                item = find_class_by_id(classes, cid)
                if item is None:
                    print("Мастер-класс не найден.")
                    continue
                status = get_booking_status(bookings, item, day, is_open)
                print(status)
            elif choice == "5":
                create_new_booking(bookings, classes, clients)
                save_bookings(BOOKINGS_FILE, bookings)
            elif choice == "6":
                bid = input_int("ID бронирования: ")
                if cancel_booking(bookings, bid):
                    save_bookings(BOOKINGS_FILE, bookings)
                    print("Бронирование отменено.")
                else:
                    print("Бронирование не найдено.")
            elif choice == "7":
                show_bookings(bookings)
                stats = get_booking_stats(bookings, classes)
                cstats = get_classes_stats(classes)
                print(f"Всего бронирований: {stats['total']}")
                print(f"Всего мастер-классов: {cstats['total']}")
                big = filter_classes_by_capacity(classes, 10)
                print(f"Классов на 10+ мест: {len(big)}")
            elif choice == "8":
                show_clients(clients)
            elif choice == "0":
                os.makedirs(os.path.dirname(CLASSES_FILE), exist_ok=True)
                save_classes(CLASSES_FILE, classes)
                save_clients(CLIENTS_FILE, clients)
                save_bookings(BOOKINGS_FILE, bookings)
                print("Данные сохранены. Выход.")
                break
            else:
                print("Неизвестное действие.")
        except (ValueError, KeyError) as exc:
            print(f"Ошибка: {exc}")


if __name__ == "__main__":
    main()
