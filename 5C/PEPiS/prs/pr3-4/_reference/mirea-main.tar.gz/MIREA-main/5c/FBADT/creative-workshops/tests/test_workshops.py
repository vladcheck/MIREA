"""Tests for workshops module and MasterClass."""

import pytest

from workshops import (
    MasterClass,
    add_class,
    check_capacity,
    filter_classes_by_capacity,
    find_class,
    find_class_by_id,
    get_classes_stats,
    sort_classes,
)


def test_master_class_creation():
    item = MasterClass(1, "Лепка кружки", 12, 2500, 12)
    assert item.id == 1
    assert item.name == "Лепка кружки"
    assert item.capacity == 12
    assert item.base_price == 2500
    assert item.age_limit == 12


def test_master_class_str():
    item = MasterClass(1, "Лепка кружки", 12, 2500, 12)
    text = str(item)
    assert "Лепка кружки" in text
    assert "12" in text


def test_is_suitable_for():
    item = MasterClass(1, "Лепка кружки", 12, 2500, 12)
    assert item.is_suitable_for(8) is True
    assert item.is_suitable_for(12) is True
    assert item.is_suitable_for(13) is False


def test_validate_capacity():
    assert MasterClass.validate_capacity(10) is True
    assert MasterClass.validate_capacity(0) is False
    assert MasterClass.validate_capacity(-5) is False


def test_add_class():
    classes = []
    item = add_class(classes, "Лепка кружки", 12, 2500, 12)
    assert item.id == 1
    assert classes == [item]
    assert classes[0].name == "Лепка кружки"


def test_find_class():
    classes = []
    add_class(classes, "Лепка кружки", 12, 2500, 12)
    add_class(classes, "Роспись керамики", 10, 2000, 8)
    found = find_class(classes, "лепка")
    assert len(found) == 1
    assert found[0].name == "Лепка кружки"


def test_find_class_by_id():
    classes = []
    add_class(classes, "Лепка кружки", 12, 2500, 12)
    item = find_class_by_id(classes, 1)
    assert item is not None
    assert item.name == "Лепка кружки"
    assert find_class_by_id(classes, 99) is None


def test_check_capacity():
    classes = []
    add_class(classes, "Роспись керамики", 10, 2000, 8)
    assert check_capacity(classes, 1, 8) is True
    assert check_capacity(classes, 1, 11) is False
    with pytest.raises(KeyError):
        check_capacity(classes, 99, 5)


def test_filter_classes_by_capacity():
    classes = []
    add_class(classes, "A", 12, 2500, 12)
    add_class(classes, "B", 8, 2000, 8)
    filtered = filter_classes_by_capacity(classes, 10)
    assert len(filtered) == 1
    assert filtered[0].name == "A"


def test_sort_classes():
    classes = []
    add_class(classes, "Big", 12, 2500, 12)
    add_class(classes, "Small", 8, 2000, 8)
    ordered = sort_classes(classes)
    assert [c.capacity for c in ordered] == [8, 12]
    assert ordered[0].name == "Small"


def test_get_classes_stats():
    classes = []
    add_class(classes, "A", 12, 2500, 12)
    add_class(classes, "B", 8, 2000, 8)
    assert get_classes_stats(classes) == {
        "total": 2,
        "avg_capacity": 10.0,
    }
    assert get_classes_stats([]) == {
        "total": 0,
        "avg_capacity": 0.0,
    }
