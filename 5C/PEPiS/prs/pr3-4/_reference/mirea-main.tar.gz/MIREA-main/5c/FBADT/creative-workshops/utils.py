"""Safe user input helpers."""

from datetime import date, datetime


def input_int(prompt: str) -> int:
    """Ask user for int, repeat on bad input."""
    while True:
        try:
            raw = input(prompt)
            return int(raw.strip())
        except ValueError:
            print("Нужно целое число, попробуйте ещё раз.")
        except (EOFError, KeyboardInterrupt):
            raise


def input_date(prompt: str) -> date:
    """Ask user for date DD.MM.YYYY, repeat on bad input."""
    while True:
        try:
            raw = input(prompt).strip()
            return datetime.strptime(raw, "%d.%m.%Y").date()
        except ValueError:
            print("Формат даты ДД.ММ.ГГГГ, попробуйте ещё раз.")
        except (EOFError, KeyboardInterrupt):
            raise
