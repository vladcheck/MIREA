"""Tests for JSON storage with objects."""

from datetime import date

from bookings import Booking
from clients import Client
from storage import (
    load_bookings,
    load_classes,
    load_clients,
    save_bookings,
    save_classes,
    save_clients,
)
from workshops import MasterClass


def test_classes_roundtrip(tmp_path):
    path = str(tmp_path / "classes.json")
    classes = [MasterClass(1, "Лепка", 12, 2500, 12)]
    save_classes(path, classes)
    loaded = load_classes(path)
    assert len(loaded) == 1
    assert loaded[0].id == 1
    assert loaded[0].name == "Лепка"
    assert loaded[0].capacity == 12


def test_clients_roundtrip(tmp_path):
    path = str(tmp_path / "clients.json")
    clients = [Client(1, "Иван Петров", 19, False)]
    save_clients(path, clients)
    loaded = load_clients(path)
    assert len(loaded) == 1
    assert loaded[0].name == "Иван Петров"
    assert loaded[0].age == 19


def test_bookings_roundtrip(tmp_path):
    classes_path = str(tmp_path / "classes.json")
    clients_path = str(tmp_path / "clients.json")
    bookings_path = str(tmp_path / "bookings.json")
    classes = [MasterClass(1, "Лепка", 12, 2500, 12)]
    clients = [Client(1, "Иван Петров", 19, False)]
    save_classes(classes_path, classes)
    save_clients(clients_path, clients)
    bookings = [
        Booking(1, classes[0], date(2026, 10, 12), clients[0])
    ]
    save_bookings(bookings_path, bookings)
    loaded_classes = load_classes(classes_path)
    loaded_clients = load_clients(clients_path)
    loaded = load_bookings(bookings_path, loaded_classes, loaded_clients)
    assert len(loaded) == 1
    assert loaded[0].id == 1
    assert loaded[0].workshop.id == 1
    assert loaded[0].client.id == 1
    assert loaded[0].booking_date == date(2026, 10, 12)
    assert loaded[0].is_cancelled is False


def test_bookings_cancelled_roundtrip(tmp_path):
    path = str(tmp_path / "bookings.json")
    workshop = MasterClass(1, "Лепка", 12, 2500, 12)
    client = Client(1, "Иван Петров", 19, False)
    booking = Booking(
        1, workshop, date(2026, 10, 12), client, is_cancelled=True
    )
    save_bookings(path, [booking])
    loaded = load_bookings(path, [workshop], [client])
    assert loaded[0].is_cancelled is True


def test_load_missing_returns_empty(tmp_path):
    assert load_classes(str(tmp_path / "no.json")) == []
    assert load_clients(str(tmp_path / "no.json")) == []
    assert load_bookings(str(tmp_path / "no.json"), [], []) == []


def test_load_bookings_skips_unknown_links(tmp_path):
    path = str(tmp_path / "bookings.json")
    workshop = MasterClass(1, "Лепка", 12, 2500, 12)
    client = Client(1, "Иван Петров", 19, False)
    booking = Booking(1, workshop, date(2026, 10, 12), client)
    save_bookings(path, [booking])
    loaded = load_bookings(path, [], [])
    assert loaded == []
