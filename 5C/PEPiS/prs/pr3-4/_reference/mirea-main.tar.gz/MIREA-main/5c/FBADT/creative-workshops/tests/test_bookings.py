"""Tests for bookings module, PR1 functions kept."""

from datetime import date

from bookings import (
    Booking,
    calculate_price,
    cancel_booking,
    check_age_limit,
    create_booking,
    format_booking,
    get_availability_status,
    get_booking_stats,
    get_booking_status,
    is_slot_available,
)
from clients import Client
from workshops import MasterClass


def make_workshop():
    return MasterClass(1, "Лепка кружки", 12, 2500, 12)


def make_client():
    return Client(1, "Иван Петров", 19, False)


def test_get_availability_status():
    assert get_availability_status(4, True) == "Запись открыта"
    assert get_availability_status(0, True) == (
        "Мест нет, запись в лист ожидания"
    )
    assert get_availability_status(4, False) == "Запись закрыта"


def test_calculate_price():
    assert calculate_price("2500", True, True) == 2550.0
    assert calculate_price("2500", False, False) == 2500.0
    assert calculate_price("2000", True, False) == 2400.0


def test_check_age_limit():
    assert check_age_limit("19") == "Допущен"
    assert check_age_limit("10") == "Не допущен: мастер-класс 12+"
    assert check_age_limit("10", 8) == "Допущен"


def test_format_booking():
    text = format_booking(
        "Гончарная мастерская «Терра»",
        "Лепка кружки своими руками",
        date(2026, 10, 12),
        "Запись открыта",
        2550.0,
        "Допущен",
    )
    assert text == (
        "Мастерская: Гончарная мастерская «Терра»\n"
        "Мастер-класс: Лепка кружки своими руками\n"
        "Дата: 2026-10-12\n"
        "Статус записи: Запись открыта\n"
        "Возраст: Допущен\n"
        "Итого: 2550 руб.\n"
        "Бронирование подтверждено"
    )


def test_booking_creation():
    workshop = make_workshop()
    client = make_client()
    booking = Booking(1, workshop, date(2026, 10, 12), client)
    assert booking.id == 1
    assert booking.workshop is workshop
    assert booking.client is client
    assert booking.booking_date == date(2026, 10, 12)
    assert booking.is_cancelled is False


def test_booking_str():
    workshop = make_workshop()
    client = make_client()
    booking = Booking(1, workshop, date(2026, 10, 12), client)
    text = str(booking)
    assert "Лепка кружки" in text
    assert "Иван Петров" in text


def test_booking_cancel():
    workshop = make_workshop()
    client = make_client()
    booking = Booking(1, workshop, date(2026, 10, 12), client)
    booking.cancel()
    assert booking.is_cancelled is True
    assert "отменено" in str(booking).lower()


def test_is_slot_available():
    workshop = make_workshop()
    client = make_client()
    bookings = []
    day = date(2026, 10, 12)
    assert is_slot_available(bookings, workshop, day) is True
    create_booking(bookings, workshop, day, client)
    assert is_slot_available(bookings, workshop, day) is False
    other = date(2026, 10, 13)
    assert is_slot_available(bookings, workshop, other) is True


def test_cancelled_does_not_block():
    workshop = make_workshop()
    client = make_client()
    bookings = []
    day = date(2026, 10, 12)
    booking = create_booking(bookings, workshop, day, client)
    assert booking is not None
    assert cancel_booking(bookings, booking.id) is True
    assert is_slot_available(bookings, workshop, day) is True


def test_create_booking():
    workshop = make_workshop()
    client = make_client()
    bookings = []
    day = date(2026, 10, 12)
    record = create_booking(bookings, workshop, day, client)
    assert record is not None
    assert record.workshop is workshop
    assert record.client is client
    assert bookings == [record]


def test_create_booking_duplicate_returns_none():
    workshop = make_workshop()
    client = make_client()
    other = Client(2, "Анна Смирнова", 20, True)
    bookings = []
    day = date(2026, 10, 12)
    first = create_booking(bookings, workshop, day, client)
    assert first is not None
    second = create_booking(bookings, workshop, day, other)
    assert second is None
    assert len(bookings) == 1


def test_cancel_booking():
    workshop = make_workshop()
    client = make_client()
    bookings = []
    create_booking(bookings, workshop, date(2026, 10, 12), client)
    assert cancel_booking(bookings, 1) is True
    assert len(bookings) == 1
    assert bookings[0].is_cancelled is True
    assert cancel_booking(bookings, 99) is False


def test_get_booking_status():
    workshop = make_workshop()
    client = make_client()
    bookings = []
    day = date(2026, 10, 12)
    assert get_booking_status(bookings, workshop, day) == "Запись открыта"
    create_booking(bookings, workshop, day, client)
    assert get_booking_status(bookings, workshop, day) == (
        "Мест нет, запись в лист ожидания"
    )


def test_get_booking_stats():
    workshop = make_workshop()
    client = make_client()
    bookings = []
    create_booking(bookings, workshop, date(2026, 10, 12), client)
    create_booking(bookings, workshop, date(2026, 10, 13), client)
    stats = get_booking_stats(bookings, [workshop])
    assert stats == {"total": 2, "per_class": {"Лепка кружки": 2}}
